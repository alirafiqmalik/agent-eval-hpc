A. Chips Moving
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given $$$n$$$ chips on a number line. The $$$i$$$-th chip is placed at the integer coordinate $$$x_i$$$. Some chips
can have equal coordinates
.
You can perform each of the two following types of moves any (possibly, zero) number of times on any chip:

 Move the chip $$$i$$$ by $$$2$$$ to the left or $$$2$$$ to the right
for free
 (i.e. replace the current coordinate $$$x_i$$$ with $$$x_i - 2$$$ or with $$$x_i + 2$$$);
 move the chip $$$i$$$ by $$$1$$$ to the left or $$$1$$$ to the right and pay
one coin
 for this move (i.e. replace the current coordinate $$$x_i$$$ with $$$x_i - 1$$$ or with $$$x_i + 1$$$).
Note that it's allowed to move chips to any integer coordinate, including negative and zero.
Your task is to find the minimum total number of coins required to move all $$$n$$$ chips to the same coordinate (i.e. all $$$x_i$$$ should be equal after some sequence of moves).
Input
The first line of the input contains one integer $$$n$$$ ($$$1 \le n \le 100$$$) — the number of chips.
The second line of the input contains $$$n$$$ integers $$$x_1, x_2, \dots, x_n$$$ ($$$1 \le x_i \le 10^9$$$), where $$$x_i$$$ is the coordinate of the $$$i$$$-th chip.
Output
Print one integer — the minimum total number of coins required to move all $$$n$$$ chips to the same coordinate.
Examples
Input

3
1 2 3

Output

1

Input

5
2 2 2 3 3

Output

2

Note
In the first example you need to move the first chip by $$$2$$$ to the right and the second chip by $$$1$$$ to the right or move the third chip by $$$2$$$ to the left and the second chip by $$$1$$$ to the left so the answer is $$$1$$$.
In the second example you need to move two chips with coordinate $$$3$$$ by $$$1$$$ to the left so the answer is $$$2$$$.