A. New Year Transportation
time limit per test
2 seconds
memory limit per test
256 megabytes
input
stdin
output
stdout
New Year is coming in Line World! In this world, there are
n
 cells numbered by integers from
1
 to
n
, as a
1 ×
n
 board. People live in cells. However, it was hard to move between distinct cells, because of the difficulty of escaping the cell. People wanted to meet people who live in other cells.
So, user tncks0121 has made a transportation system to move between these cells, to celebrate the New Year. First, he thought of
n
 - 1
 positive integers
a
1
,
a
2
, ...,
a
n
 - 1
. For every integer
i
 where
1 ≤
i
 ≤
n
 - 1
 the condition
1 ≤
a
i
 ≤
n
 -
i
 holds. Next, he made
n
 - 1
 portals, numbered by integers from 1 to
n
 - 1
. The
i
-th (
1 ≤
i
 ≤
n
 - 1
) portal connects cell
i
 and cell
(
i
 +
a
i
)
, and one can travel from cell
i
 to cell
(
i
 +
a
i
)
 using the
i
-th portal. Unfortunately, one cannot use the portal backwards, which means one cannot move from cell
(
i
 +
a
i
)
 to cell
i
 using the
i
-th portal. It is easy to see that because of condition
1 ≤
a
i
 ≤
n
 -
i
 one can't leave the Line World using portals.
Currently, I am standing at cell
1
, and I want to go to cell
t
. However, I don't know whether it is possible to go there. Please determine whether I can go to cell
t
 by only using the construted transportation system.
Input
The first line contains two space-separated integers
n
 (
3 ≤
n
 ≤ 3 × 10
4
) and
t
 (
2 ≤
t
 ≤
n
) — the number of cells, and the index of the cell which I want to go to.
The second line contains
n
 - 1
 space-separated integers
a
1
,
a
2
, ...,
a
n
 - 1
 (
1 ≤
a
i
 ≤
n
 -
i
). It is guaranteed, that using the given transportation system, one cannot leave the Line World.
Output
If I can go to cell
t
 using the transportation system, print "
YES
". Otherwise, print "
NO
".
Examples
Input
8 4
1 2 1 2 1 2 1
Output
YES
Input
8 5
1 2 1 2 1 1 1
Output
NO
Note
In the first sample, the visited cells are:
1, 2, 4
; so we can successfully visit the cell
4
.
In the second sample, the possible cells to visit are:
1, 2, 4, 6, 7, 8
; so we can't visit the cell
5
, which we want to visit.