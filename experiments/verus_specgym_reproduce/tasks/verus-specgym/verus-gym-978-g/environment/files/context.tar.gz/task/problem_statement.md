G. Petya's Exams
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Petya studies at university. The current academic year finishes with $$$n$$$ special days. Petya needs to pass $$$m$$$ exams in those special days. The special days in this problem are numbered from $$$1$$$ to $$$n$$$.
There are three values about each exam:

 $$$s_i$$$ — the day, when questions for the $$$i$$$-th exam will be published,
 $$$d_i$$$ — the day of the $$$i$$$-th exam ($$$s_i < d_i$$$),
 $$$c_i$$$ — number of days Petya needs to prepare for the $$$i$$$-th exam. For the $$$i$$$-th exam Petya should prepare in days between $$$s_i$$$ and $$$d_i-1$$$, inclusive.
There are three types of activities for Petya in each day: to spend a day doing nothing (taking a rest), to spend a day passing exactly one exam or to spend a day preparing for exactly one exam. So he can't pass/prepare for multiple exams in a day. He can't mix his activities in a day. If he is preparing for the $$$i$$$-th exam in day $$$j$$$, then $$$s_i \le j < d_i$$$.
It is allowed to have breaks in a preparation to an exam and to alternate preparations for different exams in consecutive days. So preparation for an exam is not required to be done in consecutive days.
Find the schedule for Petya to prepare for all exams and pass them, or report that it is impossible.
Input
The first line contains two integers $$$n$$$ and $$$m$$$ $$$(2 \le n \le 100, 1 \le m \le n)$$$ — the number of days and the number of exams.
Each of the following $$$m$$$ lines contains three integers $$$s_i$$$, $$$d_i$$$, $$$c_i$$$ $$$(1 \le s_i < d_i \le n, 1 \le c_i \le n)$$$ — the day, when questions for the $$$i$$$-th exam will be given, the day of the $$$i$$$-th exam, number of days Petya needs to prepare for the $$$i$$$-th exam.
Guaranteed, that all the exams will be in different days. Questions for different exams can be given in the same day. It is possible that, in the day of some exam, the questions for other exams are given.
Output
If Petya can not prepare and pass all the exams, print
-1
. In case of positive answer, print $$$n$$$ integers, where the $$$j$$$-th number is:

 $$$(m + 1)$$$, if the $$$j$$$-th day is a day of some exam (recall that in each day no more than one exam is conducted),
 zero, if in the $$$j$$$-th day Petya will have a rest,
 $$$i$$$ ($$$1 \le i \le m$$$), if Petya will prepare for the $$$i$$$-th exam in the day $$$j$$$ (the total number of days Petya prepares for each exam should be
strictly
 equal to the number of days needed to prepare for it).
Assume that the exams are numbered in order of appearing in the input, starting from $$$1$$$.
If there are multiple schedules, print any of them.
Examples
Input
5 2
1 3 1
1 5 1
Output
1 2 3 0 3
Input
3 2
1 3 1
1 2 1
Output
-1
Input
10 3
4 7 2
1 10 3
8 9 1
Output
2 2 2 1 1 0 4 3 4 4
Note
In the first example Petya can, for example, prepare for exam $$$1$$$ in the first day, prepare for exam $$$2$$$ in the second day, pass exam $$$1$$$ in the third day, relax in the fourth day, and pass exam $$$2$$$ in the fifth day. So, he can prepare and pass all exams.
In the second example, there are three days and two exams. So, Petya can prepare in only one day (because in two other days he should pass exams). Then Petya can not prepare and pass all exams.