E. Vasya's Function
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Vasya is studying number theory. He has denoted a function
f
(
a
,
b
)
 such that:

f
(
a
, 0) = 0
;

f
(
a
,
b
) = 1 +
f
(
a
,
b
 -
gcd
(
a
,
b
))
, where
gcd
(
a
,
b
)
 is the greatest common divisor of
a
 and
b
.
Vasya has two numbers
x
 and
y
, and he wants to calculate
f
(
x
,
y
)
. He tried to do it by himself, but found out that calculating this function the way he wants to do that might take very long time. So he decided to ask you to implement a program that will calculate this function swiftly.
Input
The first line contains two integer numbers
x
 and
y
 (
1 ≤
x
,
y
 ≤ 10
12
).
Output
Print
f
(
x
,
y
)
.
Examples
Input
3 5
Output
3
Input
6 3
Output
1