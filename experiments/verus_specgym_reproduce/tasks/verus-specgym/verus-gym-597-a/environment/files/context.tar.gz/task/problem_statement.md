A. Divisibility
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Find the number of
k
-divisible numbers on the segment
[
a
,
b
]
. In other words you need to find the number of such integer values
x
 that
a
 ≤
x
 ≤
b
 and
x
 is divisible by
k
.
Input
The only line contains three space-separated integers
k
,
a
 and
b
 (
1 ≤
k
 ≤ 10
18
; - 10
18
 ≤
a
 ≤
b
 ≤ 10
18
).
Output
Print the required number.
Examples
Input
1 1 10
Output
10
Input
2 -4 4
Output
5