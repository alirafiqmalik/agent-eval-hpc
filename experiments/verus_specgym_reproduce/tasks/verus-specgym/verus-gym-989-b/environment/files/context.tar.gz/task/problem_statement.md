B. A Tide of Riverscape
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
 Walking along a riverside, Mino silently takes a note of something.
"Time," Mino thinks aloud.
"What?"
"Time and tide wait for no man," explains Mino. "My name, taken from the river, always reminds me of this."
"And what are you recording?"
"You see it, tide. Everything has its own period, and I think I've figured out this one," says Mino with confidence.
Doubtfully, Kanno peeks at Mino's records.
The records are expressed as a string $$$s$$$ of characters '
0
', '
1
' and '
.
', where '
0
' denotes a low tide, '
1
' denotes a high tide, and '
.
' denotes an unknown one (either high or low).
You are to help Mino determine whether it's possible that after replacing each '
.
' independently with '
0
' or '
1
', a given integer $$$p$$$ is
not
 a period of the resulting string. In case the answer is yes, please also show such a replacement to Mino.
In this problem, a positive integer $$$p$$$ is considered a period of string $$$s$$$, if for all $$$1 \leq i \leq \lvert s \rvert - p$$$, the $$$i$$$-th and $$$(i + p)$$$-th characters of $$$s$$$ are the same. Here $$$\lvert s \rvert$$$ is the length of $$$s$$$.
Input
The first line contains two space-separated integers $$$n$$$ and $$$p$$$ ($$$1 \leq p \leq n \leq 2000$$$) — the length of the given string and the supposed period, respectively.
The second line contains a string $$$s$$$ of $$$n$$$ characters — Mino's records. $$$s$$$ only contains characters '
0
', '
1
' and '
.
', and contains at least one '
.
' character.
Output
Output one line — if it's possible that $$$p$$$ is
not
 a period of the resulting string, output any one of such strings; otherwise output "
No
" (without quotes, you can print letters in any case (upper or lower)).
Examples
Input
10 7
1.0.1.0.1.
Output
1000100010
Input
10 6
1.0.1.1000
Output
1001101000
Input
10 9
1........1
Output
No
Note
In the first example, $$$7$$$ is not a period of the resulting string because the $$$1$$$-st and $$$8$$$-th characters of it are different.
In the second example, $$$6$$$ is not a period of the resulting string because the $$$4$$$-th and $$$10$$$-th characters of it are different.
In the third example, $$$9$$$ is always a period because the only constraint that the first and last characters are the same is already satisfied.
Note that there are multiple acceptable answers for the first two examples, you can print any of them.