A. Search for Pretty Integers
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given two lists of non-zero digits.
Let's call an integer pretty if its (base
10
) representation has at least one digit from the first list and at least one digit from the second list. What is the smallest positive pretty integer?
Input
The first line contains two integers
n
 and
m
 (
1 ≤
n
,
m
 ≤ 9
) — the lengths of the first and the second lists, respectively.
The second line contains
n
 distinct digits
a
1
,
a
2
, ...,
a
n
 (
1 ≤
a
i
 ≤ 9
) — the elements of the first list.
The third line contains
m
 distinct digits
b
1
,
b
2
, ...,
b
m
 (
1 ≤
b
i
 ≤ 9
) — the elements of the second list.
Output
Print the smallest pretty integer.
Examples
Input
2 3
4 2
5 7 6
Output
25
Input
8 8
1 2 3 4 5 6 7 8
8 7 6 5 4 3 2 1
Output
1
Note
In the first example
25
,
46
,
24567
 are pretty, as well as many other integers. The smallest among them is
25
.
42
 and
24
 are not pretty because they don't have digits from the second list.
In the second example all integers that have at least one digit different from
9
 are pretty. It's obvious that the smallest among them is
1
, because it's the smallest positive integer.