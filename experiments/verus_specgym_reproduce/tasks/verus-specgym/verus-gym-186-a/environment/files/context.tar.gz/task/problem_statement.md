A. Comparing Strings
time limit per test
2 seconds
memory limit per test
256 megabytes
input
stdin
output
stdout
Some dwarves that are finishing the StUDY (State University for Dwarven Youngsters) Bachelor courses, have been told "no genome, no degree". That means that all dwarves should write a thesis on genome. Dwarven genome is far from simple. It is represented by a string that consists of lowercase Latin letters.
Dwarf Misha has already chosen the subject for his thesis: determining by two dwarven genomes, whether they belong to the same race. Two dwarves belong to the same race if we can swap two characters in the first dwarf's genome and get the second dwarf's genome as a result. Help Dwarf Misha and find out whether two gnomes belong to the same race or not.
Input
The first line contains the first dwarf's genome: a non-empty string, consisting of lowercase Latin letters.
The second line contains the second dwarf's genome: a non-empty string, consisting of lowercase Latin letters.
The number of letters in each genome doesn't exceed
10
5
. It is guaranteed that the strings that correspond to the genomes are different. The given genomes may have different length.
Output
Print "YES", if the dwarves belong to the same race. Otherwise, print "NO".
Examples
Input
ab
ba
Output
YES
Input
aa
ab
Output
NO
Note

 First example: you can simply swap two letters in string "ab". So we get "ba".
 Second example: we can't change string "aa" into string "ab", because "aa" does not contain letter "b".