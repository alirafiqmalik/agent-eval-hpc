B. Little Dima and Equation
time limit per test
1 second
memory limit per test
256 megabytes
input
stdin
output
stdout
Little Dima misbehaved during a math lesson a lot and the nasty teacher Mr. Pickles gave him the following problem as a punishment.
Find all integer solutions
x

(0 <
x
 < 10
9
)
 of the equation:
x
 =
b
·
s
(
x
)
a
 +
c
,

where
a
,
b
,
c
 are some predetermined constant values and function
s
(
x
)
 determines the sum of all digits in the decimal representation of number
x
.
The teacher gives this problem to Dima for each lesson. He changes only the parameters of the equation:
a
,
b
,
c
. Dima got sick of getting bad marks and he asks you to help him solve this challenging problem.
Input
The first line contains three space-separated integers:
a
,
b
,
c

(1 ≤
a
 ≤ 5; 1 ≤
b
 ≤ 10000;  - 10000 ≤
c
 ≤ 10000)
.
Output
Print integer
n
 — the number of the solutions that you've found. Next print
n
 integers in the increasing order — the solutions of the given equation. Print only integer solutions that are larger than zero and strictly less than
10
9
.
Examples
Input
3 2 8
Output
3
10 2008 13726
Input
1 2 -18
Output
0
Input
2 2 -1
Output
4
1 31 337 967