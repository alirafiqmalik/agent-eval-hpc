A. Marketing Scheme
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
You got a job as a marketer in a pet shop, and your current task is to boost sales of cat food. One of the strategies is to sell cans of food in packs with discounts.
Suppose you decided to sell packs with $$$a$$$ cans in a pack with a discount and some customer wants to buy $$$x$$$ cans of cat food. Then he follows a greedy strategy:

 he buys $$$\left\lfloor \frac{x}{a} \right\rfloor$$$ packs with a discount;
 then he wants to buy the remaining $$$(x \bmod a)$$$ cans one by one.
$$$\left\lfloor \frac{x}{a} \right\rfloor$$$ is $$$x$$$ divided by $$$a$$$ rounded down, $$$x \bmod a$$$ is the remainer of $$$x$$$ divided by $$$a$$$.
But customers are greedy in general, so if the customer wants to buy $$$(x \bmod a)$$$ cans one by one and it happens that $$$(x \bmod a) \ge \frac{a}{2}$$$ he decides to buy the whole pack of $$$a$$$ cans (instead of buying $$$(x \bmod a)$$$ cans). It makes you, as a marketer, happy since the customer bought more than he wanted initially.
You know that each of the customers that come to your shop can buy any number of cans from $$$l$$$ to $$$r$$$ inclusive. Can you choose such size of pack $$$a$$$ that each customer buys more cans than they wanted initially?
Input
The first line contains a single integer $$$t$$$ ($$$1 \le t \le 1000$$$) — the number of test cases.
The first and only line of each test case contains two integers $$$l$$$ and $$$r$$$ ($$$1 \le l \le r \le 10^9$$$) — the range of the number of cans customers can buy.
Output
For each test case, print
YES
 if you can choose such size of pack $$$a$$$ that each customer buys more cans than they wanted initially. Otherwise, print
NO
.
You can print each character in any case.
Example
Input

3
3 4
1 2
120 150

Output

YES
NO
YES

Note
In the first test case, you can take, for example, $$$a = 5$$$ as the size of the pack. Then if a customer wants to buy $$$3$$$ cans, he'll buy $$$5$$$ instead ($$$3 \bmod 5 = 3$$$, $$$\frac{5}{2} = 2.5$$$). The one who wants $$$4$$$ cans will also buy $$$5$$$ cans.
In the second test case, there is no way to choose $$$a$$$.
In the third test case, you can take, for example, $$$a = 80$$$.