C. Ilya and Sticks
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
In the evening, after the contest Ilya was bored, and he really felt like maximizing. He remembered that he had a set of
n
 sticks and an instrument. Each stick is characterized by its length
l
i
.
Ilya decided to make a rectangle from the sticks. And due to his whim, he decided to make rectangles in such a way that maximizes their total area. Each stick is used in making at most one rectangle, it is possible that some of sticks remain unused. Bending sticks is not allowed.
Sticks with lengths
a
1
,
a
2
,
a
3
 and
a
4
 can make a rectangle if the following properties are observed:

a
1
 ≤
a
2
 ≤
a
3
 ≤
a
4

a
1
 =
a
2

a
3
 =
a
4

A rectangle can be made of sticks with lengths of, for example,
3 3 3 3
 or
2 2 4 4
. A rectangle cannot be made of, for example, sticks
5 5 5 7
.
Ilya also has an instrument which can reduce the length of the sticks. The sticks are made of a special material, so the length of each stick can be reduced by at most one. For example, a stick with length
5
 can either stay at this length or be transformed into a stick of length
4
.
You have to answer the question — what maximum total area of the rectangles can Ilya get with a file if makes rectangles from the available sticks?
Input
The first line of the input contains a positive integer
n
 (
1 ≤
n
 ≤ 10
5
) — the number of the available sticks.
The second line of the input contains
n
 positive integers
l
i
 (
2 ≤
l
i
 ≤ 10
6
) — the lengths of the sticks.
Output
The first line of the output must contain a single non-negative integer — the maximum total area of the rectangles that Ilya can make from the available sticks.
Examples
Input
4
2 4 4 2
Output
8
Input
4
2 2 3 5
Output
0
Input
4
100003 100004 100005 100006
Output
10000800015