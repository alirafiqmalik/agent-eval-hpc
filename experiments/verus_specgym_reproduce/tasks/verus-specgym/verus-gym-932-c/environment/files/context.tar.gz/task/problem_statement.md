C. Permutation Cycle
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
For a permutation
P
[1...
N
]
 of integers from
1
 to
N
, function
f
 is defined as follows:

Let
g
(
i
)
 be the minimum positive integer
j
 such that
f
(
i
,
j
) =
i
. We can show such
j
 always exists.
For given
N
,
A
,
B
, find a permutation
P
 of integers from
1
 to
N
 such that for
1 ≤
i
 ≤
N
,
g
(
i
)
 equals either
A
 or
B
.
Input
The only line contains three integers
N
,
A
,
B
 (
1 ≤
N
 ≤ 10
6
, 1 ≤
A
,
B
 ≤
N
).
Output
If no such permutation exists, output
-1
. Otherwise, output a permutation of integers from
1
 to
N
.
Examples
Input
9 2 5
Output
6 5 8 3 4 1 9 2 7
Input
3 2 1
Output
1 2 3
Note
In the first example,
g
(1) =
g
(6) =
g
(7) =
g
(9) = 2
 and
g
(2) =
g
(3) =
g
(4) =
g
(5) =
g
(8) = 5

In the second example,
g
(1) =
g
(2) =
g
(3) = 1