B. Distances to Zero
time limit per test
2 seconds
memory limit per test
256 megabytes
input
stdin
output
stdout
You are given the array of integer numbers
a
0
,
a
1
, ...,
a
n
 - 1
. For each element find the distance to the nearest zero (to the element which equals to zero). There is at least one zero element in the given array.
Input
The first line contains integer
n
 (
1 ≤
n
 ≤ 2·10
5
) — length of the array
a
. The second line contains integer elements of the array separated by single spaces (
 - 10
9
 ≤
a
i
 ≤ 10
9
).
Output
Print the sequence
d
0
,
d
1
, ...,
d
n
 - 1
, where
d
i
 is the difference of indices between
i
 and nearest
j
 such that
a
j
 = 0
. It is possible that
i
 =
j
.
Examples
Input
9
2 1 0 3 0 0 3 2 4
Output
2 1 0 1 0 0 1 2 3
Input
5
0 1 2 3 4
Output
0 1 2 3 4
Input
7
5 6 0 1 -2 3 4
Output
2 1 0 1 2 3 4