C. New Year and Rating
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
Every Codeforces user has rating, described with one integer, possibly negative or zero. Users are divided into two divisions. The first division is for users with rating
1900
 or higher. Those with rating
1899
 or lower belong to the second division. In every contest, according to one's performance, his or her rating changes by some value, possibly negative or zero.
Limak competed in
n
 contests in the year 2016. He remembers that in the
i
-th contest he competed in the division
d
i
 (i.e. he belonged to this division
just before
 the start of this contest) and his rating changed by
c
i

just after the contest
. Note that negative
c
i
 denotes the loss of rating.
What is the maximum possible rating Limak can have right now, after all
n
 contests? If his rating may be arbitrarily big, print "
Infinity
". If there is no scenario matching the given information, print "
Impossible
".
Input
The first line of the input contains a single integer
n
 (
1 ≤
n
 ≤ 200 000
).
The
i
-th of next
n
 lines contains two integers
c
i
 and
d
i
 (
 - 100 ≤
c
i
 ≤ 100
,
1 ≤
d
i
 ≤ 2
), describing Limak's rating change after the
i
-th contest and his division during the
i
-th contest contest.
Output
If Limak's current rating can be arbitrarily big, print "
Infinity
" (without quotes). If the situation is impossible, print "
Impossible
" (without quotes). Otherwise print one integer, denoting the maximum possible value of Limak's current rating, i.e. rating after the
n
 contests.
Examples
Input
3
-7 1
5 2
8 2
Output
1907
Input
2
57 1
22 2
Output
Impossible
Input
1
-5 1
Output
Infinity
Input
4
27 2
13 1
-50 1
8 2
Output
1897
Note
In the first sample, the following scenario matches all information Limak remembers and has maximum possible final rating:

 Limak has rating
1901
 and belongs to the division
1
 in the first contest. His rating decreases by
7
.
 With rating
1894
 Limak is in the division
2
. His rating increases by
5
.
 Limak has rating
1899
 and is still in the division
2
. In the last contest of the year he gets
 + 8
 and ends the year with rating
1907
.
In the second sample, it's impossible that Limak is in the division
1
, his rating increases by
57
 and after that Limak is in the division
2
 in the second contest.