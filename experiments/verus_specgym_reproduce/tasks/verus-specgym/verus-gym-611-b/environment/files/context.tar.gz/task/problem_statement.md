B. New Year and Old Property
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
The year 2015 is almost over.
Limak is a little polar bear. He has recently learnt about the binary system. He noticed that the passing year has exactly one zero in its representation in the binary system —
2015
10
 = 11111011111
2
. Note that he doesn't care about the number of zeros in the decimal representation.
Limak chose some interval of years. He is going to count all years from this interval that have exactly one zero in the binary representation. Can you do it faster?
Assume that all positive integers are always written without leading zeros.
Input
The only line of the input contains two integers
a
 and
b
 (
1 ≤
a
 ≤
b
 ≤ 10
18
) — the first year and the last year in Limak's interval respectively.
Output
Print one integer – the number of years Limak will count in his chosen interval.
Examples
Input
5 10
Output
2
Input
2015 2015
Output
1
Input
100 105
Output
0
Input
72057594000000000 72057595000000000
Output
26
Note
In the first sample Limak's interval contains numbers
5
10
 = 101
2
,
6
10
 = 110
2
,
7
10
 = 111
2
,
8
10
 = 1000
2
,
9
10
 = 1001
2
 and
10
10
 = 1010
2
. Two of them (
101
2
 and
110
2
) have the described property.