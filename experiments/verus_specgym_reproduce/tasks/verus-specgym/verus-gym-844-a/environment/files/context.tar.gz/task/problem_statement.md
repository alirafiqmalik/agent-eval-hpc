A. Diversity
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Calculate the minimum number of characters you need to change in the string
s
, so that it contains at least
k
 different letters, or print that it is impossible.
String
s
 consists only of lowercase Latin letters, and it is allowed to change characters only to lowercase Latin letters too.
Input
First line of input contains string
s
, consisting only of lowercase Latin letters (
1 ≤ |
s
| ≤ 1000
,
|
s
|
 denotes the length of
s
).
Second line of input contains integer
k
 (
1 ≤
k
 ≤ 26
).
Output
Print single line with a minimum number of necessary changes, or the word «
impossible
» (without quotes) if it is impossible.
Examples
Input
yandex
6
Output
0
Input
yahoo
5
Output
1
Input
google
7
Output
impossible
Note
In the first test case string contains
6
 different letters, so we don't need to change anything.
In the second test case string contains
4
 different letters:
{'
a
', '
h
', '
o
', '
y
'}
. To get
5
 different letters it is necessary to change one occurrence of
'
o
'
 to some letter, which doesn't occur in the string, for example,
{'
b
'}
.
In the third test case, it is impossible to make
7
 different letters because the length of the string is
6
.