A. Remove a Progression
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You have a list of numbers from $$$1$$$ to $$$n$$$ written from left to right on the blackboard.
You perform an algorithm consisting of several steps (steps are $$$1$$$-indexed). On the $$$i$$$-th step you wipe the $$$i$$$-th number (considering only
remaining
 numbers). You wipe
the whole number
 (not one digit).

When there are less than $$$i$$$ numbers remaining, you stop your algorithm.
Now you wonder: what is the value of the $$$x$$$-th remaining number after the algorithm is stopped?
Input
The first line contains one integer $$$T$$$ ($$$1 \le T \le 100$$$) — the number of queries. The next $$$T$$$ lines contain queries — one per line. All queries are independent.
Each line contains two space-separated integers $$$n$$$ and $$$x$$$ ($$$1 \le x < n \le 10^{9}$$$) — the length of the list and the position we wonder about. It's guaranteed that after the algorithm ends, the list will still contain at least $$$x$$$ numbers.
Output
Print $$$T$$$ integers (one per query) — the values of the $$$x$$$-th number after performing the algorithm for the corresponding queries.
Example
Input

3
3 1
4 2
69 6

Output

2
4
12