A. Buying A House
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
Zane the wizard had never loved anyone before, until he fell in love with a girl, whose name remains unknown to us.

The girl lives in house
m
 of a village. There are
n
 houses in that village, lining in a straight line from left to right: house
1
, house
2
, ..., house
n
. The village is also well-structured: house
i
 and house
i
 + 1
 (
1 ≤
i
 <
n
) are exactly
10
 meters away. In this village, some houses are occupied, and some are not. Indeed, unoccupied houses can be purchased.
You will be given
n
 integers
a
1
,
a
2
, ...,
a
n
 that denote the availability and the prices of the houses. If house
i
 is occupied, and therefore cannot be bought, then
a
i
 equals
0
. Otherwise, house
i
 can be bought, and
a
i
 represents the money required to buy it, in dollars.
As Zane has only
k
 dollars to spare, it becomes a challenge for him to choose the house to purchase, so that he could live as near as possible to his crush. Help Zane determine the minimum distance from his crush's house to some house he can afford, to help him succeed in his love.
Input
The first line contains three integers
n
,
m
, and
k
 (
2 ≤
n
 ≤ 100
,
1 ≤
m
 ≤
n
,
1 ≤
k
 ≤ 100
) — the number of houses in the village, the house where the girl lives, and the amount of money Zane has (in dollars), respectively.
The second line contains
n
 integers
a
1
,
a
2
, ...,
a
n
 (
0 ≤
a
i
 ≤ 100
) — denoting the availability and the prices of the houses.
It is guaranteed that
a
m
 = 0
 and that it is possible to purchase some house with no more than
k
 dollars.
Output
Print one integer — the minimum distance, in meters, from the house where the girl Zane likes lives to the house Zane can buy.
Examples
Input
5 1 20
0 27 32 21 19
Output
40
Input
7 3 50
62 0 0 0 99 33 22
Output
30
Input
10 5 100
1 0 1 0 0 0 0 0 1 1
Output
20
Note
In the first sample, with
k
 = 20
 dollars, Zane can buy only house
5
. The distance from house
m
 = 1
 to house
5
 is
10 + 10 + 10 + 10 = 40
 meters.
In the second sample, Zane can buy houses
6
 and
7
. It is better to buy house
6
 than house
7
, since house
m
 = 3
 and house
6
 are only
30
 meters away, while house
m
 = 3
 and house
7
 are
40
 meters away.