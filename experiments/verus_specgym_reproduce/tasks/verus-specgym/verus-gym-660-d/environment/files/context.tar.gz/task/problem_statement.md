D. Number of Parallelograms
time limit per test
4 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given
n
 points on a plane. All the points are distinct, and no three of them lie on the same line. Find the number of parallelograms with vertices at the given points.
Input
The first line of the input contains an integer
n
 (
1 ≤
n
 ≤ 2000
) — the number of points.
Each of the next
n
 lines contains two integers
(
x
i
,
y
i
)
 (
0 ≤
x
i
,
y
i
 ≤ 10
9
) — the coordinates of the
i
-th point.
Output
Print the only integer
c
 — the number of parallelograms with vertices at the given points.
Example
Input
4
0 1
1 0
1 1
2 0
Output
1