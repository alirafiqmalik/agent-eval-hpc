C. Bug in Code
time limit per test
1 second
memory limit per test
256 megabytes
input
stdin
output
stdout
Recently a serious bug has been found in the FOS code. The head of the F company wants to find the culprit and punish him. For that, he set up an organizational meeting, the issue is: who's bugged the code? Each of the
n
 coders on the meeting said: 'I know for sure that either
x
 or
y
 did it!'
The head of the company decided to choose two suspects and invite them to his office. Naturally, he should consider the coders' opinions. That's why the head wants to make such a choice that at least
p
 of
n
 coders agreed with it. A coder agrees with the choice of two suspects if at least one of the two people that he named at the meeting was chosen as a suspect. In how many ways can the head of F choose two suspects?
Note that even if some coder was chosen as a suspect, he can agree with the head's choice if he named the other chosen coder at the meeting.
Input
The first line contains integers
n
 and
p

(3 ≤
n
 ≤ 3·10
5
; 0 ≤
p
 ≤
n
)
 — the number of coders in the F company and the minimum number of agreed people.
Each of the next
n
 lines contains two integers
x
i
,
y
i

(1 ≤
x
i
,
y
i
 ≤
n
)
 — the numbers of coders named by the
i
-th coder. It is guaranteed that
x
i
 ≠
i
,
y
i
 ≠
i
,
x
i
 ≠
y
i
.
Output
Print a single integer –– the number of possible two-suspect sets. Note that the order of the suspects doesn't matter, that is, sets
(1, 2)
 и
(2, 1)
 are considered identical.
Examples
Input
4 2
2 3
1 4
1 4
2 1
Output
6
Input
8 6
5 6
5 7
5 8
6 2
2 1
7 3
1 3
1 4
Output
1