B. Queries about less or equal elements
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given two arrays of integers
a
 and
b
. For each element of the second array
b
j
 you should find the number of elements in array
a
 that are less than or equal to the value
b
j
.
Input
The first line contains two integers
n
,
m
 (
1 ≤
n
,
m
 ≤ 2·10
5
) — the sizes of arrays
a
 and
b
.
The second line contains
n
 integers — the elements of array
a
 (
 - 10
9
 ≤
a
i
 ≤ 10
9
).
The third line contains
m
 integers — the elements of array
b
 (
 - 10
9
 ≤
b
j
 ≤ 10
9
).
Output
Print
m
 integers, separated by spaces: the
j
-th of which is equal to the number of such elements in array
a
 that are less than or equal to the value
b
j
.
Examples
Input
5 4
1 3 5 7 9
6 4 2 8
Output
3 2 1 4
Input
5 5
1 2 1 2 5
3 1 4 1 5
Output
4 2 4 2 5