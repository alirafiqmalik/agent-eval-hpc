A. The Contest
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
Pasha is participating in a contest on one well-known website. This time he wants to win the contest and will do anything to get to the first place!
This contest consists of
n
 problems, and Pasha solves
i
th problem in
a
i
 time units (his solutions are always correct). At any moment of time he can be thinking about a solution to only one of the problems (that is, he cannot be solving two problems at the same time). The time Pasha spends to send his solutions is negligible.
Pasha can send any number of solutions at the same moment.
Unfortunately, there are too many participants, and the website is not always working. Pasha received the information that the website will be working only during
m
 time periods,
j
th period is represented by its starting moment
l
j
 and ending moment
r
j
. Of course, Pasha can send his solution only when the website is working. In other words, Pasha can send his solution at some moment
T
 iff there exists a period
x
 such that
l
x
 ≤
T
 ≤
r
x
.
Pasha wants to know his best possible result. We need to tell him the minimal moment of time by which he is able to have
solutions to all problems submitted
, if he acts optimally, or say that it's impossible no matter how Pasha solves the problems.
Input
The first line contains one integer
n
 (1 ≤
n
 ≤ 1000)
 — the number of problems. The second line contains
n
 integers
a
i
 (1 ≤
a
i
 ≤ 10
5
)
 — the time Pasha needs to solve
i
th problem.
The third line contains one integer
m
 (0 ≤
m
 ≤ 1000)
 — the number of periods of time when the website is working. Next
m
 lines represent these periods.
j
th line contains two numbers
l
j
 and
r
j
 (1 ≤
l
j
 <
r
j
 ≤ 10
5
)
 — the starting and the ending moment of
j
th period.
It is guaranteed that the periods are not intersecting and are given in chronological order, so for every
j
 > 1
 the condition
l
j
 >
r
j
 - 1
 is met.
Output
If Pasha can solve and submit all the problems before the end of the contest, print the minimal moment of time by which he can have all the solutions submitted.
Otherwise print "-1" (without brackets).
Examples
Input
2
3 4
2
1 4
7 9
Output
7
Input
1
5
1
1 4
Output
-1
Input
1
5
1
1 5
Output
5
Note
In the first example Pasha can act like this: he solves the second problem in 4 units of time and sends it immediately. Then he spends 3 time units to solve the first problem and sends it 7 time units after the contest starts, because at this moment the website starts working again.
In the second example Pasha invents the solution only after the website stops working for the last time.
In the third example Pasha sends the solution exactly at the end of the first period.