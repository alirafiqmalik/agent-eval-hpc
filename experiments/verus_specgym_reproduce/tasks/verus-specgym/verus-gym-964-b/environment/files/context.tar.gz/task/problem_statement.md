B. Messages
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
There are
n
 incoming messages for Vasya. The
i
-th message is going to be received after
t
i
 minutes. Each message has a cost, which equals to
A
 initially. After being received, the cost of a message decreases by
B
 each minute (it can become negative). Vasya can read any message after receiving it at any moment of time. After reading the message, Vasya's bank account receives the current cost of this message. Initially, Vasya's bank account is at
0
.
Also, each minute Vasya's bank account receives
C
·
k
, where
k
 is the amount of received but unread messages.
Vasya's messages are very important to him, and because of that he wants to have all messages read after
T
 minutes.
Determine the maximum amount of money Vasya's bank account can hold after
T
 minutes.
Input
The first line contains five integers
n
,
A
,
B
,
C
 and
T
 (
1 ≤
n
,
A
,
B
,
C
,
T
 ≤ 1000
).
The second string contains
n
 integers
t
i
 (
1 ≤
t
i
 ≤
T
).
Output
Output one integer  — the answer to the problem.
Examples
Input
4 5 5 3 5
1 5 5 4
Output
20
Input
5 3 1 1 3
2 2 2 1 1
Output
15
Input
5 5 3 4 5
1 2 3 4 5
Output
35
Note
In the first sample the messages must be read immediately after receiving, Vasya receives
A
 points for each message,
n
·
A
 = 20
 in total.
In the second sample the messages can be read at any integer moment.
In the third sample messages must be read at the moment T. This way Vasya has
1
,
2
,
3
,
4
 and
0
 unread messages at the corresponding minutes, he gets
40
 points for them. When reading messages, he receives
(5 - 4·3) + (5 - 3·3) + (5 - 2·3) + (5 - 1·3) + 5 =  - 5
 points. This is
35
 in total.