B. Codeforces World Finals
time limit per test
2 seconds
memory limit per test
256 megabytes
input
stdin
output
stdout
The king Copa often has been reported about the Codeforces site, which is rapidly getting more and more popular among the brightest minds of the humanity, who are using it for training and competing. Recently Copa understood that to conquer the world he needs to organize the world Codeforces tournament. He hopes that after it the brightest minds will become his subordinates, and the toughest part of conquering the world will be completed.
The final round of the Codeforces World Finals 20YY is scheduled for
DD
.
MM
.
YY
, where
DD
 is the day of the round,
MM
 is the month and
YY
 are the last two digits of the year. Bob is lucky to be the first finalist form Berland. But there is one problem: according to the rules of the competition, all participants must be at least 18 years old at the moment of the finals. Bob was born on
BD
.
BM
.
BY
. This date is recorded in his passport, the copy of which he has already mailed to the organizers. But Bob learned that in different countries the way, in which the dates are written, differs. For example, in the US the month is written first, then the day and finally the year. Bob wonders if it is possible to rearrange the numbers in his date of birth so that he will be at least 18 years old on the day
DD
.
MM
.
YY
. He can always tell that in his motherland dates are written differently. Help him.
According to another strange rule, eligible participant must be born in the same century as the date of the finals. If the day of the finals is participant's 18-th birthday, he is allowed to participate.
As we are considering only the years from
2001
 to
2099
 for the year of the finals, use the following rule: the year is leap if it's number is divisible by four.
Input
The first line contains the date
DD
.
MM
.
YY
, the second line contains the date
BD
.
BM
.
BY
. It is guaranteed that both dates are correct, and
YY
 and
BY
 are always in
[01;99]
.
It could be that by passport Bob was born after the finals. In this case, he can still change the order of numbers in date.
Output
If it is possible to rearrange the numbers in the date of birth so that Bob will be at least 18 years old on the
DD
.
MM
.
YY
, output
YES
. In the other case, output
NO
.
Each number contains exactly two digits and stands for day, month or year in a date. Note that it is permitted to rearrange only numbers, not digits.
Examples
Input
01.01.98
01.01.80
Output
YES
Input
20.10.20
10.02.30
Output
NO
Input
28.02.74
28.02.64
Output
NO