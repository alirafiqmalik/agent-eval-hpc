A. k-th divisor
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given two integers
n
 and
k
. Find
k
-th smallest divisor of
n
, or report that it doesn't exist.
Divisor of
n
 is any such natural number, that
n
 can be divided by it without remainder.
Input
The first line contains two integers
n
 and
k
 (
1 ≤
n
 ≤ 10
15
,
1 ≤
k
 ≤ 10
9
).
Output
If
n
 has less than
k
 divisors, output
-1
.
Otherwise, output the
k
-th smallest divisor of
n
.
Examples
Input
4 2
Output
2
Input
5 3
Output
-1
Input
12 5
Output
6
Note
In the first example, number
4
 has three divisors:
1
,
2
 and
4
. The second one is
2
.
In the second example, number
5
 has only two divisors:
1
 and
5
. The third divisor doesn't exist, so the answer is
-1
.