C. Prefixes and Suffixes
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Ivan wants to play a game with you. He picked some string $$$s$$$ of length $$$n$$$ consisting only of lowercase Latin letters.
You don't know this string. Ivan has informed you about all its improper prefixes and suffixes (i.e. prefixes and suffixes of lengths from $$$1$$$ to $$$n-1$$$), but he didn't tell you which strings are prefixes and which are suffixes.
Ivan wants you to guess which of the given $$$2n-2$$$ strings are prefixes of the given string and which are suffixes. It may be impossible to guess the string Ivan picked (since multiple strings may give the same set of suffixes and prefixes), but Ivan will accept your answer if there is at least one string that is consistent with it. Let the game begin!
Input
The first line of the input contains one integer number $$$n$$$ ($$$2 \le n \le 100$$$) — the length of the guessed string $$$s$$$.
The next $$$2n-2$$$ lines are contain prefixes and suffixes, one per line. Each of them is the string of length from $$$1$$$ to $$$n-1$$$ consisting only of lowercase Latin letters. They can be given in arbitrary order.
It is guaranteed that there are exactly $$$2$$$ strings of each length from $$$1$$$ to $$$n-1$$$. It is also guaranteed that these strings are prefixes and suffixes of some existing string of length $$$n$$$.
Output
Print one string of length $$$2n-2$$$ — the string consisting only of characters '
P
' and '
S
'. The number of characters '
P
' should be equal to the number of characters '
S
'. The $$$i$$$-th character of this string should be '
P
' if the $$$i$$$-th of the input strings is the prefix and '
S
' otherwise.
If there are several possible answers, you can print
any
.
Examples
Input

5
ba
a
abab
a
aba
baba
ab
aba

Output

SPPSPSPS

Input

3
a
aa
aa
a

Output

PPSS

Input

2
a
c

Output

PS

Note
The only string which Ivan can guess in the first example is "
ababa
".
The only string which Ivan can guess in the second example is "
aaa
". Answers "
SPSP
", "
SSPP
" and "
PSPS
" are also acceptable.
In the third example Ivan can guess the string "
ac
" or the string "
ca
". The answer "
SP
" is also acceptable.