E. Correcting Mistakes
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
Analyzing the mistakes people make while typing search queries is a complex and an interesting work. As there is no guaranteed way to determine what the user originally meant by typing some query, we have to use different sorts of heuristics.
Polycarp needed to write a code that could, given two words, check whether they could have been obtained from the same word as a result of typos. Polycarpus suggested that the most common typo is skipping exactly one letter as you type a word.
Implement a program that can, given two distinct words
S
 and
T
 of the same length
n
 determine how many words
W
 of length
n
 + 1
 are there with such property that you can transform
W
 into both
S
, and
T
 by deleting exactly one character. Words
S
 and
T
 consist of lowercase English letters. Word
W
 also should consist of lowercase English letters.
Input
The first line contains integer
n
 (
1 ≤
n
 ≤ 100 000
) — the length of words
S
 and
T
.
The second line contains word
S
.
The third line contains word
T
.
Words
S
 and
T
 consist of lowercase English letters. It is guaranteed that
S
 and
T
 are distinct words.
Output
Print a single integer — the number of distinct words
W
 that can be transformed to
S
 and
T
 due to a typo.
Examples
Input
7
reading
trading
Output
1
Input
5
sweet
sheep
Output
0
Input
3
toy
try
Output
2
Note
In the first sample test the two given words could be obtained only from word "
t
r
e
ading
" (the deleted letters are marked in bold).
In the second sample test the two given words couldn't be obtained from the same word by removing one letter.
In the third sample test the two given words could be obtained from either word "
t
or
y
" or word "
t
ro
y
".