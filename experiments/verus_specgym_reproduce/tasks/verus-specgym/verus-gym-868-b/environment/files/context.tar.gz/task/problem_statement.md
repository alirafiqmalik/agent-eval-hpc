B. Race Against Time
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
Have you ever tried to explain to the coordinator, why it is eight hours to the contest and not a single problem has been prepared yet? Misha had. And this time he has a
really
 strong excuse: he faced a space-time paradox! Space and time replaced each other.
The entire universe turned into an enormous clock face with three hands — hour, minute, and second. Time froze, and clocks now show the time
h
 hours,
m
 minutes,
s
 seconds.
Last time Misha talked with the coordinator at
t
1
 o'clock, so now he stands on the number
t
1
 on the clock face. The contest should be ready by
t
2
 o'clock. In the terms of paradox it means that Misha has to go to number
t
2
 somehow. Note that he doesn't have to move forward only: in these circumstances time has no direction.
Clock hands are very long, and Misha cannot get round them. He also cannot step over as it leads to the collapse of space-time. That is, if hour clock points 12 and Misha stands at 11 then he cannot move to 1 along the top arc. He has to follow all the way round the clock center (of course, if there are no other hands on his way).
Given the hands' positions,
t
1
, and
t
2
, find if Misha can prepare the contest on time (or should we say
on space
?). That is, find if he can move from
t
1
 to
t
2
 by the clock face.
Input
Five integers
h
,
m
,
s
,
t
1
,
t
2
 (
1 ≤
h
 ≤ 12
,
0 ≤
m
,
s
 ≤ 59
,
1 ≤
t
1
,
t
2
 ≤ 12
,
t
1
 ≠
t
2
).
Misha's position and the target time do not coincide with the position of any hand.
Output
Print "
YES
" (quotes for clarity), if Misha can prepare the contest on time, and "
NO
" otherwise.
You can print each character either upper- or lowercase ("
YeS
" and "
yes
" are valid when the answer is "
YES
").
Examples
Input
12 30 45 3 11
Output
NO
Input
12 0 1 12 1
Output
YES
Input
3 47 0 4 9
Output
YES
Note
The three examples are shown on the pictures below from left to right. The starting position of Misha is shown with green, the ending position is shown with pink. Note that the positions of the hands on the pictures are not exact, but are close to the exact and the answer is the same.