A. Pineapple Incident
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Ted has a pineapple. This pineapple is able to bark like a bulldog! At time
t
 (in seconds) it barks for the first time. Then every
s
 seconds after it, it barks twice with
1
 second interval. Thus it barks at times
t
,
t
 +
s
,
t
 +
s
 + 1
,
t
 + 2
s
,
t
 + 2
s
 + 1
, etc.

Barney woke up in the morning and wants to eat the pineapple, but he can't eat it when it's barking. Barney plans to eat it at time
x
 (in seconds), so he asked you to tell him if it's gonna bark at that time.
Input
The first and only line of input contains three integers
t
,
s
 and
x
 (
0 ≤
t
,
x
 ≤ 10
9
,
2 ≤
s
 ≤ 10
9
) — the time the pineapple barks for the first time, the pineapple barking interval, and the time Barney wants to eat the pineapple respectively.
Output
Print a single "YES" (without quotes) if the pineapple will bark at time
x
 or a single "NO" (without quotes) otherwise in the only line of output.
Examples
Input
3 10 4
Output
NO
Input
3 10 3
Output
YES
Input
3 8 51
Output
YES
Input
3 8 52
Output
YES
Note
In the first and the second sample cases pineapple will bark at moments
3
,
13
,
14
, ..., so it won't bark at the moment
4
 and will bark at the moment
3
.
In the third and fourth sample cases pineapple will bark at moments
3
,
11
,
12
,
19
,
20
,
27
,
28
,
35
,
36
,
43
,
44
,
51
,
52
,
59
, ..., so it will bark at both moments
51
 and
52
.