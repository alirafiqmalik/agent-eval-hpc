C. Nested Segments
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given a sequence
a
1
,
a
2
, ...,
a
n
 of one-dimensional segments numbered
1
 through
n
. Your task is to find two distinct indices
i
 and
j
 such that segment
a
i
 lies within segment
a
j
.
Segment
[
l
1
,
r
1
]
 lies within segment
[
l
2
,
r
2
]
 iff
l
1
 ≥
l
2
 and
r
1
 ≤
r
2
.
Print indices
i
 and
j
. If there are multiple answers, print any of them. If no answer exists, print
-1 -1
.
Input
The first line contains one integer
n
 (
1 ≤
n
 ≤ 3·10
5
) — the number of segments.
Each of the next
n
 lines contains two integers
l
i
 and
r
i
 (
1 ≤
l
i
 ≤
r
i
 ≤ 10
9
) — the
i
-th segment.
Output
Print two distinct indices
i
 and
j
 such that segment
a
i
 lies within segment
a
j
. If there are multiple answers, print any of them. If no answer exists, print
-1 -1
.
Examples
Input
5
1 10
2 9
3 9
2 3
2 9
Output
2 1
Input
3
1 5
2 6
6 20
Output
-1 -1
Note
In the first example the following pairs are considered correct:

(2, 1), (3, 1), (4, 1), (5, 1)
 — not even touching borders;

(3, 2), (4, 2), (3, 5), (4, 5)
 — touch one border;

(5, 2), (2, 5)
 — match exactly.