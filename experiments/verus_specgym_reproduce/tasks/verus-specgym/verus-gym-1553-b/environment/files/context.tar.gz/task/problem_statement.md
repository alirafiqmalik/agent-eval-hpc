B. Reverse String
time limit per test
3 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You have a string $$$s$$$ and a chip, which you can place onto any character of this string.
After placing the chip, you move it to the right several (maybe zero) times, i. e. you perform the following operation several times: if the current position of the chip is $$$i$$$, you move it to the position $$$i + 1$$$. Of course, moving the chip to the right is impossible if it is already in the last position.
After moving the chip to the right, you move it to the left several (maybe zero) times, i. e. you perform the following operation several times: if the current position of the chip is $$$i$$$, you move it to the position $$$i - 1$$$. Of course, moving the chip to the left is impossible if it is already in the first position.
When you place a chip or move it, you write down the character where the chip ends up after your action. For example, if $$$s$$$ is
abcdef
, you place the chip onto the $$$3$$$-rd character, move it to the right $$$2$$$ times and then move it to the left $$$3$$$ times, you write down the string
cdedcb
.
You are given two strings $$$s$$$ and $$$t$$$. Your task is to determine whether it's possible to perform the described operations with $$$s$$$ so that you write down the string $$$t$$$ as a result.
Input
The first line contains one integer $$$q$$$ ($$$1 \le q \le 500$$$) — the number of test cases.
Each test case consists of two lines. The first line contains the string $$$s$$$ ($$$1 \le |s| \le 500$$$), the second line contains the string $$$t$$$ ($$$1 \le |t| \le 2 \cdot |s| - 1$$$). Both strings consist of lowercase English characters.
It is guaranteed that the sum of $$$|s|$$$ over all test cases does not exceed $$$500$$$.
Output
For each test case, print "
YES
" if you can obtain the string $$$t$$$ by performing the process mentioned in the statement with the string $$$s$$$, or "
NO
" if you cannot.
You may print each letter in any case (
YES
,
yes
,
Yes
 will all be recognized as positive answer,
NO
,
no
 and
nO
 will all be recognized as negative answer).
Example
Input

6
abcdef
cdedcb
aaa
aaaaa
aab
baaa
ab
b
abcdef
abcdef
ba
baa

Output

YES
YES
NO
YES
YES
NO

Note
Consider the examples.
The first test case is described in the statement.
In the second test case, you can place the chip on the $$$1$$$-st position, move it twice to the right, and then move it twice to the left.
In the fourth test case, you can place the chip on the $$$2$$$-nd position, and then don't move it at all.
In the fifth test case, you can place the chip on the $$$1$$$-st position, move it $$$5$$$ times to the right, and then finish the process.