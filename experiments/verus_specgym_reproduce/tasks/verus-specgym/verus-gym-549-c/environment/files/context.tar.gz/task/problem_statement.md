C. The Game Of Parity
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
There are
n
 cities in Westeros. The
i
-th city is inhabited by
a
i
 people. Daenerys and Stannis play the following game: in one single move, a player chooses a certain town and burns it to the ground. Thus all its residents, sadly, die. Stannis starts the game. The game ends when Westeros has exactly
k
 cities left.
The prophecy says that if the total number of surviving residents is even, then Daenerys wins: Stannis gets beheaded, and Daenerys rises on the Iron Throne. If the total number of surviving residents is odd, Stannis wins and everything goes in the completely opposite way.
Lord Petyr Baelish wants to know which candidates to the throne he should support, and therefore he wonders, which one of them has a winning strategy. Answer to this question of Lord Baelish and maybe you will become the next Lord of Harrenholl.
Input
The first line contains two positive space-separated integers,
n
 and
k
 (
1 ≤
k
 ≤
n
 ≤ 2·10
5
) — the initial number of cities in Westeros and the number of cities at which the game ends.
The second line contains
n
 space-separated positive integers
a
i
 (
1 ≤
a
i
 ≤ 10
6
), which represent the population of each city in Westeros.
Output
Print string "
Daenerys
" (without the quotes), if Daenerys wins and "
Stannis
" (without the quotes), if Stannis wins.
Examples
Input
3 1
1 2 1
Output
Stannis
Input
3 1
2 2 1
Output
Daenerys
Input
6 3
5 20 12 7 14 101
Output
Stannis
Note
In the first sample Stannis will use his move to burn a city with two people and Daenerys will be forced to burn a city with one resident. The only survivor city will have one resident left, that is, the total sum is odd, and thus Stannis wins.
In the second sample, if Stannis burns a city with two people, Daenerys burns the city with one resident, or vice versa. In any case, the last remaining city will be inhabited by two people, that is, the total sum is even, and hence Daenerys wins.