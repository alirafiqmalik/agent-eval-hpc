A. k-Factorization
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
Given a positive integer
n
, find
k
 integers (not necessary distinct) such that all these integers are strictly greater than
1
, and their product is equal to
n
.
Input
The first line contains two integers
n
 and
k
 (
2 ≤
n
 ≤ 100000
,
1 ≤
k
 ≤ 20
).
Output
If it's impossible to find the representation of
n
 as a product of
k
 numbers, print
-1
.
Otherwise, print
k
 integers in any order. Their product must be equal to
n
. If there are multiple answers, print any of them.
Examples
Input
100000 2
Output
2 50000
Input
100000 20
Output
-1
Input
1024 5
Output
2 64 2 2 2