B. New Year's Eve
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Since Grisha behaved well last year, at New Year's Eve he was visited by Ded Moroz who brought an enormous bag of gifts with him! The bag contains
n
 sweet candies from
the good ol' bakery
, each labeled from
1
 to
n
 corresponding to its tastiness. No two candies have the same tastiness.
The choice of candies has a direct effect on Grisha's happiness. One can assume that he should take the tastiest ones — but no, the holiday magic turns things upside down. It is the xor-sum of tastinesses that matters, not the ordinary sum!
A xor-sum of a sequence of integers
a
1
,
a
2
, ...,
a
m
 is defined as the bitwise XOR of all its elements:
, here
 denotes the bitwise XOR operation; more about bitwise XOR can be found
here.
Ded Moroz warned Grisha he has more houses to visit, so Grisha can take
no more than
k
 candies from the bag. Help Grisha determine the largest xor-sum (largest xor-sum means maximum happiness!) he can obtain.
Input
The sole string contains two integers
n
 and
k
 (
1 ≤
k
 ≤
n
 ≤ 10
18
).
Output
Output one number — the largest possible xor-sum.
Examples
Input
4 3
Output
7
Input
6 6
Output
7
Note
In the first sample case, one optimal answer is
1
,
2
 and
4
, giving the xor-sum of
7
.
In the second sample case, one can, for example, take all six candies and obtain the xor-sum of
7
.