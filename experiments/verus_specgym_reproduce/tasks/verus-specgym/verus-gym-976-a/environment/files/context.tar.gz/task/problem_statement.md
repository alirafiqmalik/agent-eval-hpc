A. Minimum Binary Number
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
String can be called
correct
 if it consists of characters "
0
" and "
1
" and there are no redundant leading zeroes. Here are some examples: "
0
", "
10
", "
1001
".
You are given a
correct
 string
s
.
You can perform two different operations on this string:

 swap any pair of adjacent characters (for example, "
1
01
"
 "
1
10
");
 replace "
11
" with "
1
" (for example, "
11
0
"
 "
1
0
").
Let
val
(
s
)
 be such a number that
s
 is its binary representation.
Correct
 string
a
 is less than some other
correct
 string
b
 iff
val
(
a
) <
val
(
b
)
.
Your task is to find the minimum
correct
 string that you can obtain from the given one using the operations described above. You can use these operations any number of times in any order (or even use no operations at all).
Input
The first line contains integer number
n
 (
1 ≤
n
 ≤ 100
) — the length of string
s
.
The second line contains the string
s
 consisting of characters "
0
" and "
1
". It is guaranteed that the string
s
 is
correct
.
Output
Print one string — the minimum
correct
 string that you can obtain from the given one.
Examples
Input
4
1001
Output
100
Input
1
1
Output
1
Note
In the first example you can obtain the answer by the following sequence of operations: "
1001
"
 "
1010
"
 "
1100
"
 "
100
".
In the second example you can't obtain smaller answer no matter what operations you use.