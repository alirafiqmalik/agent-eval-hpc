E. Tetrahedron
time limit per test
2 seconds
memory limit per test
256 megabytes
input
stdin
output
stdout
You are given a tetrahedron. Let's mark its vertices with letters
A
,
B
,
C
 and
D
 correspondingly.

An ant is standing in the vertex
D
 of the tetrahedron. The ant is quite active and he wouldn't stay idle. At each moment of time he makes a step from one vertex to another one along some edge of the tetrahedron. The ant just can't stand on one place.
You do not have to do much to solve the problem: your task is to count the number of ways in which the ant can go from the initial vertex
D
 to itself in exactly
n
 steps. In other words, you are asked to find out the number of different cyclic paths with the length of
n
 from vertex
D
 to itself. As the number can be quite large, you should print it modulo
1000000007
 (
10
9
 + 7
).
Input
The first line contains the only integer
n
 (
1 ≤
n
 ≤ 10
7
) — the required length of the cyclic path.
Output
Print the only integer — the required number of ways modulo
1000000007
 (
10
9
 + 7
).
Examples
Input
2
Output
3
Input
4
Output
21
Note
The required paths in the first sample are:

D
 -
A
 -
D

D
 -
B
 -
D

D
 -
C
 -
D