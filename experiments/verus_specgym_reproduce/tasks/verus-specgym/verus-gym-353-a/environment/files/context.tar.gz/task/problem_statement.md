A. Domino
time limit per test
1 second
memory limit per test
256 megabytes
input
stdin
output
stdout
Valera has got
n
 domino pieces in a row. Each piece consists of two halves — the upper one and the lower one. Each of the halves contains a number from
1
 to
6
. Valera loves even integers very much, so he wants the sum of the numbers on the upper halves and the sum of the numbers on the lower halves to be even.
To do that, Valera can rotate the dominoes by
180
 degrees. After the rotation the upper and the lower halves swap places. This action takes one second. Help Valera find out the minimum time he must spend rotating dominoes to make his wish come true.
Input
The first line contains integer
n

(1 ≤
n
 ≤ 100)
, denoting the number of dominoes Valera has. Next
n
 lines contain two space-separated integers
x
i
,
y
i

(1 ≤
x
i
,
y
i
 ≤ 6)
. Number
x
i
 is initially written on the upper half of the
i
-th domino,
y
i
 is initially written on the lower half.
Output
Print a single number — the minimum required number of seconds. If Valera can't do the task in any time, print
 - 1
.
Examples
Input
2
4 2
6 4
Output
0
Input
1
2 3
Output
-1
Input
3
1 4
2 3
4 4
Output
1
Note
In the first test case the sum of the numbers on the upper halves equals
10
 and the sum of the numbers on the lower halves equals
6
. Both numbers are even, so Valera doesn't required to do anything.
In the second sample Valera has only one piece of domino. It is written
3
 on the one of its halves, therefore one of the sums will always be odd.
In the third case Valera can rotate the first piece, and after that the sum on the upper halves will be equal to
10
, and the sum on the lower halves will be equal to
8
.