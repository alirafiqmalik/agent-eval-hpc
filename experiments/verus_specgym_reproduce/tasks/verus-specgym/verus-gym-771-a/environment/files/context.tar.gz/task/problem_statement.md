A. Bear and Friendship Condition
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Bear Limak examines a social network. Its main functionality is that two members can become friends (then they can talk with each other and share funny pictures).
There are
n
 members, numbered
1
 through
n
.
m
 pairs of members are friends. Of course, a member can't be a friend with themselves.
Let
A-B
 denote that members
A
 and
B
 are friends. Limak thinks that a network is
reasonable
 if and only if the following condition is satisfied: For every three
distinct
 members (
X
,
Y
,
Z
), if
X-Y
 and
Y-Z
 then also
X-Z
.
For example: if Alan and Bob are friends, and Bob and Ciri are friends, then Alan and Ciri should be friends as well.
Can you help Limak and check if the network is reasonable? Print "
YES
" or "
NO
" accordingly, without the quotes.
Input
The first line of the input contain two integers
n
 and
m
 (
3 ≤
n
 ≤ 150 000
,
) — the number of members and the number of pairs of members that are friends.
The
i
-th of the next
m
 lines contains two distinct integers
a
i
 and
b
i
 (
1 ≤
a
i
,
b
i
 ≤
n
,
a
i
 ≠
b
i
). Members
a
i
 and
b
i
 are friends with each other. No pair of members will appear more than once in the input.
Output
If the given network is reasonable, print "
YES
" in a single line (without the quotes). Otherwise, print "
NO
" in a single line (without the quotes).
Examples
Input
4 3
1 3
3 4
1 4
Output
YES
Input
4 4
3 1
2 3
3 4
1 2
Output
NO
Input
10 4
4 3
5 10
8 9
1 2
Output
YES
Input
3 2
1 2
2 3
Output
NO
Note
The drawings below show the situation in the first sample (on the left) and in the second sample (on the right). Each edge represents two members that are friends. The answer is "
NO
" in the second sample because members
(2, 3)
 are friends and members
(3, 4)
 are friends, while members
(2, 4)
 are not.