A. Alyona and copybooks
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Little girl Alyona is in a shop to buy some copybooks for school. She study four subjects so she wants to have equal number of copybooks for each of the subjects. There are three types of copybook's packs in the shop: it is possible to buy one copybook for
a
 rubles, a pack of two copybooks for
b
 rubles, and a pack of three copybooks for
c
 rubles. Alyona already has
n
 copybooks.
What is the minimum amount of rubles she should pay to buy such number of copybooks
k
 that
n
 +
k
 is divisible by
4
? There are infinitely many packs of any type in the shop. Alyona can buy packs of different type in the same purchase.
Input
The only line contains
4
 integers
n
,
a
,
b
,
c
 (
1 ≤
n
,
a
,
b
,
c
 ≤ 10
9
).
Output
Print the minimum amount of rubles she should pay to buy such number of copybooks
k
 that
n
 +
k
 is divisible by
4
.
Examples
Input
1 1 3 4
Output
3
Input
6 2 1 1
Output
1
Input
4 4 4 4
Output
0
Input
999999999 1000000000 1000000000 1000000000
Output
1000000000
Note
In the first example Alyona can buy
3
 packs of
1
 copybook for
3
a
 = 3
 rubles in total. After that she will have
4
 copybooks which she can split between the subjects equally.
In the second example Alyuna can buy a pack of
2
 copybooks for
b
 = 1
 ruble. She will have
8
 copybooks in total.
In the third example Alyona can split the copybooks she already has between the
4
 subject equally, so she doesn't need to buy anything.
In the fourth example Alyona should buy one pack of one copybook.