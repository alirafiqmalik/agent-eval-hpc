A. Find Extra One
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
You have
n
 distinct points on a plane, none of them lie on
OY
 axis. Check that there is a point after removal of which the remaining points are located on one side of the
OY
 axis.
Input
The first line contains a single positive integer
n
 (
2 ≤
n
 ≤ 10
5
).
The following
n
 lines contain coordinates of the points. The
i
-th of these lines contains two single integers
x
i
 and
y
i
 (
|
x
i
|, |
y
i
| ≤ 10
9
,
x
i
 ≠ 0
). No two points coincide.
Output
Print "
Yes
" if there is such a point, "
No
" — otherwise.
You can print every letter in any case (upper or lower).
Examples
Input
3
1 1
-1 -1
2 -1
Output
Yes
Input
4
1 1
2 2
-1 1
-2 2
Output
No
Input
3
1 2
2 1
4 60
Output
Yes
Note
In the first example the second point can be removed.
In the second example there is no suitable for the condition point.
In the third example any point can be removed.