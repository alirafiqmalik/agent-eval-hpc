A. PawnChess
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Galois is one of the strongest chess players of Byteforces. He has even invented a new variant of chess, which he named «PawnChess».
This new game is played on a board consisting of 8 rows and 8 columns. At the beginning of every game some black and white pawns are placed on the board. The number of black pawns placed is not necessarily equal to the number of white pawns placed.

Lets enumerate rows and columns with integers from 1 to 8. Rows are numbered from top to bottom, while columns are numbered from left to right. Now we denote as
(
r
,
c
)
 the cell located at the row
r
 and at the column
c
.
There are always two players A and B playing the game. Player A plays with white pawns, while player B plays with black ones. The goal of player A is to put any of his pawns to the row
1
, while player B tries to put any of his pawns to the row
8
. As soon as any of the players completes his goal the game finishes immediately and the succeeded player is declared a winner.
Player A moves first and then they alternate turns. On his move player A must choose exactly one white pawn and move it one step upward and player B (at his turn) must choose exactly one black pawn and move it one step down. Any move is possible only if the targeted cell is empty. It's guaranteed that for any scenario of the game there will always be at least one move available for any of the players.
Moving upward means that the pawn located in
(
r
,
c
)
 will go to the cell
(
r
 - 1,
c
)
, while moving down means the pawn located in
(
r
,
c
)
 will go to the cell
(
r
 + 1,
c
)
. Again, the corresponding cell must be empty, i.e. not occupied by any other pawn of any color.
Given the initial disposition of the board, determine who wins the game if both players play optimally. Note that there will always be a winner due to the restriction that for any game scenario both players will have some moves available.
Input
The input consists of the board description given in eight lines, each line contains eight characters. Character '
B
' is used to denote a black pawn, and character '
W
' represents a white pawn. Empty cell is marked with '
.
'.
It's guaranteed that there will not be white pawns on the first row neither black pawns on the last row.
Output
Print '
A
' if player A wins the game on the given board, and '
B
' if player B will claim the victory. Again, it's guaranteed that there will always be a winner on the given board.
Examples
Input
........
........
.B....B.
....W...
........
..W.....
........
........
Output
A
Input
..B.....
..W.....
......B.
........
.....W..
......B.
........
........
Output
B
Note
In the first sample player A is able to complete his goal in 3 steps by always moving a pawn initially located at
(4, 5)
. Player B needs at least 5 steps for any of his pawns to reach the row
8
. Hence, player A will be the winner.