D. Pair Of Lines
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given
n
 points on Cartesian plane. Every point is a lattice point (i. e. both of its coordinates are integers), and all points are distinct.
You may draw two straight lines (not necessarily distinct). Is it possible to do this in such a way that every point lies on at least one of these lines?
Input
The first line contains one integer
n

(1 ≤
n
 ≤ 10
5
)
 — the number of points you are given.
Then
n
 lines follow, each line containing two integers
x
i
 and
y
i

(|
x
i
|, |
y
i
| ≤ 10
9
)
— coordinates of
i
-th point. All
n
 points are distinct.
Output
If it is possible to draw two straight lines in such a way that each of given points belongs to at least one of these lines, print
YES
. Otherwise, print
NO
.
Examples
Input
5
0 0
0 1
1 1
1 -1
2 2
Output
YES
Input
5
0 0
1 0
2 1
1 1
2 3
Output
NO
Note
In the first example it is possible to draw two lines, the one containing the points
1
,
3
 and
5
, and another one containing two remaining points.