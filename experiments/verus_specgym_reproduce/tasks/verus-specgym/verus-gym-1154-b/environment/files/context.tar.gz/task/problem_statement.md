B. Make Them Equal
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given a sequence $$$a_1, a_2, \dots, a_n$$$ consisting of $$$n$$$ integers.
You can choose any non-negative integer $$$D$$$ (i.e. $$$D \ge 0$$$), and for each $$$a_i$$$ you can:

 add $$$D$$$ (only once), i. e. perform $$$a_i := a_i + D$$$, or
 subtract $$$D$$$ (only once), i. e. perform $$$a_i := a_i - D$$$, or
 leave the value of $$$a_i$$$ unchanged.
It is possible that after an operation the value $$$a_i$$$ becomes negative.
Your goal is to choose such
minimum non-negative integer
 $$$D$$$ and perform changes in such a way, that all $$$a_i$$$ are equal (i.e. $$$a_1=a_2=\dots=a_n$$$).
Print the required $$$D$$$ or, if it is impossible to choose such value $$$D$$$, print
-1
.
For example, for array $$$[2, 8]$$$ the value $$$D=3$$$ is minimum possible because you can obtain the array $$$[5, 5]$$$ if you will add $$$D$$$ to $$$2$$$ and subtract $$$D$$$ from $$$8$$$. And for array $$$[1, 4, 7, 7]$$$ the value $$$D=3$$$ is also minimum possible. You can add it to $$$1$$$ and subtract it from $$$7$$$ and obtain the array $$$[4, 4, 4, 4]$$$.
Input
The first line of the input contains one integer $$$n$$$ ($$$1 \le n \le 100$$$) — the number of elements in $$$a$$$.
The second line of the input contains $$$n$$$ integers $$$a_1, a_2, \dots, a_n$$$ ($$$1 \le a_i \le 100$$$) — the sequence $$$a$$$.
Output
Print one integer — the
minimum non-negative integer
 value $$$D$$$ such that if you add this value to some $$$a_i$$$, subtract this value from some $$$a_i$$$ and leave some $$$a_i$$$ without changes, all obtained values become equal.
If it is impossible to choose such value $$$D$$$, print
-1
.
Examples
Input

6
1 4 4 7 4 1

Output

3

Input

5
2 2 5 2 5

Output

3

Input

4
1 3 3 7

Output

-1

Input

2
2 8

Output

3