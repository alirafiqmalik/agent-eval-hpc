A. Treasure Hunt
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Captain Bill the Hummingbird and his crew recieved an interesting challenge offer. Some stranger gave them a map, potion of teleportation and said that only this potion might help them to reach the treasure.
Bottle with potion has two values
x
 and
y
 written on it. These values define four moves which can be performed using the potion:

Map shows that the position of Captain Bill the Hummingbird is
(
x
1
,
y
1
)
 and the position of the treasure is
(
x
2
,
y
2
)
.
You task is to tell Captain Bill the Hummingbird whether he should accept this challenge or decline. If it is possible for Captain to reach the treasure using the potion then output
"YES"
, otherwise
"NO"
 (without quotes).
The potion can be used infinite amount of times.
Input
The first line contains four integer numbers
x
1
,
y
1
,
x
2
,
y
2
 (
 - 10
5
 ≤
x
1
,
y
1
,
x
2
,
y
2
 ≤ 10
5
) — positions of Captain Bill the Hummingbird and treasure respectively.
The second line contains two integer numbers
x
,
y
 (
1 ≤
x
,
y
 ≤ 10
5
) — values on the potion bottle.
Output
Print
"YES"
 if it is possible for Captain to reach the treasure using the potion, otherwise print
"NO"
 (without quotes).
Examples
Input
0 0 0 6
2 3
Output
YES
Input
1 1 3 6
1 5
Output
NO
Note
In the first example there exists such sequence of moves:

 — the first type of move

 — the third type of move