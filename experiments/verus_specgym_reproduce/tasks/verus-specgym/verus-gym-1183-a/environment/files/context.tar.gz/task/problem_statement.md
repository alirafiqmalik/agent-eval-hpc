A. Nearest Interesting Number
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
Polycarp knows that if the sum of the digits of a number is divisible by $$$3$$$, then the number itself is divisible by $$$3$$$. He assumes that the numbers, the sum of the digits of which is divisible by $$$4$$$, are also somewhat interesting. Thus, he considers a positive integer $$$n$$$ interesting if its sum of digits is divisible by $$$4$$$.
Help Polycarp find the nearest larger or equal interesting number for the given number $$$a$$$. That is, find the interesting number $$$n$$$ such that $$$n \ge a$$$ and $$$n$$$ is minimal.
Input
The only line in the input contains an integer $$$a$$$ ($$$1 \le a \le 1000$$$).
Output
Print the nearest greater or equal interesting number for the given number $$$a$$$. In other words, print the interesting number $$$n$$$ such that $$$n \ge a$$$ and $$$n$$$ is minimal.
Examples
Input

432

Output

435

Input

99

Output

103

Input

237

Output

237

Input

42

Output

44