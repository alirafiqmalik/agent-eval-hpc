D. Two Arithmetic Progressions
time limit per test
1 second
memory limit per test
256 megabytes
input
standard input
output
standard output
You are given two arithmetic progressions:
a
1
k
 +
b
1
 and
a
2
l
 +
b
2
. Find the number of integers
x
 such that
L
 ≤
x
 ≤
R
 and
x
 =
a
1
k
' +
b
1
 =
a
2
l
' +
b
2
, for some integers
k
',
l
' ≥ 0
.
Input
The only line contains six integers
a
1
,
b
1
,
a
2
,
b
2
,
L
,
R
 (
0 <
a
1
,
a
2
 ≤ 2·10
9
,  - 2·10
9
 ≤
b
1
,
b
2
,
L
,
R
 ≤ 2·10
9
,
L
 ≤
R
).
Output
Print the desired number of integers
x
.
Examples
Input
2 0 3 3 5 21
Output
3
Input
2 4 3 0 6 17
Output
2