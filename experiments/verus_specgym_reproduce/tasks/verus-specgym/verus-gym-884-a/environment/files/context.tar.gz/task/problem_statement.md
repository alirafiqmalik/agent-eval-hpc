A. Book Reading
time limit per test
2 seconds
memory limit per test
256 megabytes
input
standard input
output
standard output
Recently Luba bought a very interesting book. She knows that it will take
t
 seconds to read the book. Luba wants to finish reading as fast as she can.
But she has some work to do in each of
n
 next days. The number of seconds that Luba has to spend working during
i
-th day is
a
i
. If some free time remains, she can spend it on reading.
Help Luba to determine the minimum number of day when she finishes reading.
It is guaranteed that the answer doesn't exceed
n
.
Remember that there are 86400 seconds in a day.
Input
The first line contains two integers
n
 and
t
 (
1 ≤
n
 ≤ 100
,
1 ≤
t
 ≤ 10
6
) — the number of days and the time required to read the book.
The second line contains
n
 integers
a
i
 (
0 ≤
a
i
 ≤ 86400
) — the time Luba has to spend on her work during
i
-th day.
Output
Print the minimum day Luba can finish reading the book.
It is guaranteed that answer doesn't exceed
n
.
Examples
Input
2 2
86400 86398
Output
2
Input
2 86400
0 86400
Output
1