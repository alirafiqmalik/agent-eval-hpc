A. Transmigration
time limit per test
2 seconds
memory limit per test
256 megabytes
input
stdin
output
stdout
In Disgaea as in most role-playing games, characters have skills that determine the character's ability to use certain weapons or spells. If the character does not have the necessary skill, he cannot use it. The skill level is represented as an integer that increases when you use this skill. Different character classes are characterized by different skills.
Unfortunately, the skills that are uncommon for the given character's class are quite difficult to obtain. To avoid this limitation, there is the so-called transmigration.
Transmigration is reincarnation of the character in a new creature. His soul shifts to a new body and retains part of his experience from the previous life.
As a result of transmigration the new character gets all the skills of the old character and the skill levels are reduced according to the
k
 coefficient (if the skill level was equal to
x
, then after transmigration it becomes equal to
[
kx
]
, where
[
y
]
 is the integral part of
y
). If some skill's levels are
strictly less
 than
100
, these skills are forgotten (the character does not have them any more). After that the new character also gains the skills that are specific for his class, but are new to him. The levels of those additional skills are set to
0
.
Thus, one can create a character with skills specific for completely different character classes via transmigrations. For example, creating a mage archer or a thief warrior is possible.
You are suggested to solve the following problem: what skills will the character have after transmigration and what will the levels of those skills be?
Input
The first line contains three numbers
n
,
m
 and
k
 — the number of skills the current character has, the number of skills specific for the class into which the character is going to transmigrate and the reducing coefficient respectively;
n
 and
m
 are integers, and
k
 is a real number with exactly two digits after decimal point (
1 ≤
n
,
m
 ≤ 20
,
0.01 ≤
k
 ≤ 0.99
).
Then follow
n
 lines, each of which describes a character's skill in the form "
name

exp
" — the skill's name and the character's skill level:
name
 is a string and
exp
 is an integer in range from
0
 to
9999
, inclusive.
Then follow
m
 lines each of which contains names of skills specific for the class, into which the character transmigrates.
All names consist of lowercase Latin letters and their lengths can range from
1
 to
20
 characters, inclusive. All character's skills have distinct names. Besides the skills specific for the class into which the player transmigrates also have distinct names.
Output
Print on the first line number
z
 — the number of skills the character will have after the transmigration. Then print
z
 lines, on each of which print a skill's name and level, separated by a single space. The skills should be given in the lexicographical order.
Examples
Input
5 4 0.75
axe 350
impaler 300
ionize 80
megafire 120
magicboost 220
heal
megafire
shield
magicboost
Output
6
axe 262
heal 0
impaler 225
magicboost 165
megafire 0
shield 0