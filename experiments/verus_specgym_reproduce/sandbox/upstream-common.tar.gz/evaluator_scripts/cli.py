from __future__ import annotations

from pathlib import Path

from jsonargparse import auto_cli

from verus_gym_evals.specgen_evaluator.models.initial_args import EvalRequest
from verus_gym_evals.specgen_evaluator.runner.evaluate_specgen import (
    run_evaluation,
)


def evaluate_specgen_cli(
    path_to_solve_rs_submitted: Path = EvalRequest.DEFAULT_PATH_TO_SOLVE_RS_SUBMITTED,
    evaluate_sample_only: bool = EvalRequest.DEFAULT_EVALUATE_SAMPLE_ONLY,
    PARENT_OF_DETAILED_SAVE_DIR: Path = EvalRequest.DEFAULT_PARENT_OF_DETAILED_SAVE_DIR,
    PARENT_OF_COMPRESSED_SAVE_DIR: Path = EvalRequest.DEFAULT_PARENT_OF_COMPRESSED_SAVE_DIR,
    PATH_TO_DATA_FROM_CONSTRUCTION: Path = EvalRequest.DEFAULT_PATH_TO_DATA_FROM_CONSTRUCTION,
    evaluate_all_password: str | None = None,
    sample_num: int | None = None,
    run_id: str | None = None,
) -> None:
    eval_request = EvalRequest(
        path_to_solve_rs_submitted=path_to_solve_rs_submitted,
        evaluate_sample_only=evaluate_sample_only,
        evaluate_all_password=evaluate_all_password,
        sample_num=sample_num,
        PARENT_OF_DETAILED_SAVE_DIR=PARENT_OF_DETAILED_SAVE_DIR,
        PARENT_OF_COMPRESSED_SAVE_DIR=PARENT_OF_COMPRESSED_SAVE_DIR,
        run_id=run_id,
        PATH_TO_DATA_FROM_CONSTRUCTION=PATH_TO_DATA_FROM_CONSTRUCTION,
    )
    run_evaluation(eval_request)


def main() -> None:
    auto_cli(evaluate_specgen_cli, as_positional=False)


if __name__ == "__main__":
    main()
