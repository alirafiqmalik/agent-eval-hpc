def hello() -> str:
    return "Hello from verus_gym_evals!"
