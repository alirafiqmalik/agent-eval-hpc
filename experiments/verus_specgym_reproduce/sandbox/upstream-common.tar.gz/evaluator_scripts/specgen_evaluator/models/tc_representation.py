from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, model_validator

BucketCategory = Literal["pre_sound", "pre_complete", "post_sound", "post_complete"]


class TestcaseRepresentation(BaseModel):
    within_bucket_id: str
    category: BucketCategory # literal within pre_sound, pre_complete, post_sound, post_complete
    input_defn: str
    assert_pre_spec: str
    assert_post_spec_gt: str | None = None
    pre_spec_print_call: str
    post_spec_print_call: str | None = None
    gt_output_defn: str | None = None

    # global ID is: category::testcase_id
    @property
    def global_id(self) -> str:
        return f"{self.category}::{self.within_bucket_id}"

    @model_validator(mode="after")
    def _validate_category_specific_required_fields(self) -> TestcaseRepresentation:
        if self.category in {"post_sound", "post_complete"}:
            assert self.assert_post_spec_gt is not None
            assert self.post_spec_print_call is not None
            assert self.gt_output_defn is not None

        return self


class AllTestCases(BaseModel):
    pre_sound: list[TestcaseRepresentation]
    pre_complete: list[TestcaseRepresentation]
    post_sound: list[TestcaseRepresentation]
    post_complete: list[TestcaseRepresentation]

    ## post init 
    #TODO: make sure all the testcases are unique and have different testcase_ids!
    @model_validator(mode="after")
    def _validate_unique_ids(self) -> AllTestCases:
        """We make sure that the testcases are unique and have different testcase_ids!"""
        bucket_names: list[BucketCategory] = [
            "pre_sound",
            "pre_complete",
            "post_sound",
            "post_complete",
        ]

        # 1) within_bucket_id must be unique within each bucket.
        for bucket_name in bucket_names:
            tc_list = getattr(self, bucket_name)
            within_ids = [tc.within_bucket_id for tc in tc_list]
            assert len(within_ids) == len(set(within_ids))

        # 2) global_id must be unique across all buckets.
        all_global_ids: list[str] = []
        for bucket_name in bucket_names:
            tc_list = getattr(self, bucket_name)
            all_global_ids.extend([tc.global_id for tc in tc_list])

        assert len(all_global_ids) == len(set(all_global_ids))

        return self

class Manifest(BaseModel):
    pre_sound_passed_test_ids: list[str]
    pre_complete_passed_test_ids: list[str]
    post_sound_passed_test_ids: list[str]
    post_complete_passed_test_ids: list[str]

    @classmethod
    def from_json(cls, json_data: dict, sample_or_all: Literal["sample", "all"]) -> Manifest:
        """This function is to load which testcase IDs to use for evaluation!"""
        # load from jsons like  data/special_data_needed/911__C/manifest.json
        # make sure that all test IDs within each bucket is unique!
        # FIXME: if sample, then use the IDs in unprivileged_sample_test_ids_by_bucket!
        # else, use the IDs in passed_test_ids
        category_names: list[BucketCategory] = [
            "pre_sound",
            "pre_complete",
            "post_sound",
            "post_complete",
        ]

        def _normalized_unique_ids(raw_ids: object, category: str) -> list[str]:
            assert isinstance(raw_ids, list)
            normalized = [str(x) for x in raw_ids]
            if len(normalized) != len(set(normalized)):
                raise ValueError(f"Duplicate testcase IDs found in category={category}: {normalized}")
            return normalized

        if sample_or_all == "sample":
            sample_payload = json_data["unprivileged_sample_test_ids_by_bucket"]
            assert isinstance(sample_payload, dict)
            source_map = sample_payload
            
        else:
            snippets_payload = json_data["snippets"]
            assert isinstance(snippets_payload, dict)
            source_map = {}
            for category in category_names:
                per_cat = snippets_payload[category]
                if not isinstance(per_cat, dict):
                    raise KeyError(f"Missing/invalid snippets entry for category={category}")
                source_map[category] = per_cat["passed_test_ids"]

        return cls(
            pre_sound_passed_test_ids=_normalized_unique_ids(source_map["pre_sound"], "pre_sound"),
            pre_complete_passed_test_ids=_normalized_unique_ids(source_map["pre_complete"], "pre_complete"),
            post_sound_passed_test_ids=_normalized_unique_ids(source_map["post_sound"], "post_sound"),
            post_complete_passed_test_ids=_normalized_unique_ids(source_map["post_complete"], "post_complete"),
        )

    def category_to_test_ids(self) -> dict[BucketCategory, list[str]]:
        return {
            "pre_sound": list(self.pre_sound_passed_test_ids),
            "pre_complete": list(self.pre_complete_passed_test_ids),
            "post_sound": list(self.post_sound_passed_test_ids),
            "post_complete": list(self.post_complete_passed_test_ids),
        }    
