from pathlib import Path

from pydantic import BaseModel

from verus_gym_evals.specgen_evaluator.models.testcase_execution_models import TestcaseEvaluation
from verus_gym_evals.specgen_evaluator.phases.types import ValidationSyntaxChecksFeedback

class TestSuiteFeedback(BaseModel):
    # from testcase_id to TestcaseEvaluation
    pre_sound: dict[str, TestcaseEvaluation]
    pre_complete: dict[str, TestcaseEvaluation]
    post_sound: dict[str, TestcaseEvaluation]
    post_complete: dict[str, TestcaseEvaluation]

    def to_natural_language_feedback(self) -> str:
        categories = ["pre_sound", "pre_complete", "post_sound", "post_complete"]

        category_map: dict[str, dict[str, TestcaseEvaluation]] = {
            "pre_sound": self.pre_sound,
            "pre_complete": self.pre_complete,
            "post_sound": self.post_sound,
            "post_complete": self.post_complete,
        }

        category_stats: dict[str, dict[str, list[str]]] = {
            category: {"passed": [], "failed": [], "skipped": []} for category in categories
        }
        category_failures: dict[str, dict[str, TestcaseEvaluation]] = {
            category: {} for category in categories
        }

        for category in categories:
            verdicts_by_test = category_map[category]
            for testcase_id, testcase_verdict in verdicts_by_test.items():
                if testcase_verdict.does_testcase_have_expected_verdict:
                    category_stats[category]["passed"].append(testcase_id)
                else:
                    category_stats[category]["failed"].append(testcase_id)
                    category_failures[category][testcase_id] = testcase_verdict

        def _format_ids(ids: list[str]) -> str:
            return ", ".join(ids) if ids else "None"

        summary_lines = [
            "Summary for run unknown",
            "Below is a per-category summary of passed/failed/skipped tests:",
        ]
        for category in categories:
            stats = category_stats[category]
            summary_lines.append(
                f"- {category}: "
                f"passed={len(stats['passed'])} [{_format_ids(stats['passed'])}], "
                f"failed={len(stats['failed'])} [{_format_ids(stats['failed'])}], "
                f"skipped={len(stats['skipped'])} [{_format_ids(stats['skipped'])}]"
            )

        summary_lines.append("=" * 30)
        failure_sections: list[str] = []
        for category in categories:
            for testcase_id, testcase_verdict in category_failures[category].items():
                section_lines = [
                    f"Failures for {testcase_id} ({category}):",
                    *(f"* {line}" for line in testcase_verdict.to_nl_feedback().splitlines()),
                ]
                failure_sections.append("\n".join(section_lines))

        if failure_sections:
            separator = "\n" + "-" * 10 + "\n"
            summary_lines.append(
                "Next is a more detailed per-test summary:\n" + separator.join(failure_sections)
            )
        else:
            summary_lines.append("No failing testcases.")

        return "\n".join(summary_lines)

class EvaluationFeedback(BaseModel):
    solve_rs_submitted_path: Path
    solve_rs_post_canonical_path: Path | None
    syntax_check_feedback: ValidationSyntaxChecksFeedback
    execution_feedback: TestSuiteFeedback | None = None
