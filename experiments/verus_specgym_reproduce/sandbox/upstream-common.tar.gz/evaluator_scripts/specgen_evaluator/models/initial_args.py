from pathlib import Path
from typing import ClassVar, Literal

from pydantic import BaseModel, computed_field, model_validator


class ResolvedInputPaths(BaseModel):
    # LOOKS LIKE THIS IS STORING paths to the code submitted + the pre-computed artifacts needed for evaluation!
    # NOTE: full-mode only for now.
    solve_rs_submitted: Path  # this is the original path to the solve.rs file we used during submission!
    manifest_json: Path
    snippets_dir: Path
    canonicalization_template_solve_rs: Path # this is the solve.rs template used to canonicalize the submitted solve.rs!


class EvalRequest(BaseModel):
    DEFAULT_PATH_TO_SOLVE_RS_SUBMITTED: ClassVar[Path] = Path("/home/dev/solve.rs")
    DEFAULT_EVALUATE_SAMPLE_ONLY: ClassVar[bool] = True
    DEFAULT_SAMPLE_NUM: ClassVar[int] = 3
    DEFAULT_PARENT_OF_DETAILED_SAVE_DIR: ClassVar[Path] = Path("/home/attempts")
    DEFAULT_PARENT_OF_COMPRESSED_SAVE_DIR: ClassVar[Path] = Path("/logs/agent/compressed_verdicts")
    DEFAULT_PATH_TO_DATA_FROM_CONSTRUCTION: ClassVar[Path] = Path("/home/task_specific_artifacts")
    DEFAULT_RUN_ID_FOR_ALL_TESTS: ClassVar[str] = "run_on_all_samples"

    path_to_solve_rs_submitted: Path = DEFAULT_PATH_TO_SOLVE_RS_SUBMITTED # path to solve.rs file
    evaluate_sample_only: bool = DEFAULT_EVALUATE_SAMPLE_ONLY # whether to evaluate only a sample of the tests or all the tests
    evaluate_all_password: str | None = None # if we want to evaluate on all the tests, then we need to provide a password to decypt the main all testcases file somewhere!
    sample_num: None | int = None # if we want to evaluate only a sample of the tests, then we need to provide the number of tests to evaluate
    PARENT_OF_DETAILED_SAVE_DIR: Path = DEFAULT_PARENT_OF_DETAILED_SAVE_DIR
    PARENT_OF_COMPRESSED_SAVE_DIR: Path = DEFAULT_PARENT_OF_COMPRESSED_SAVE_DIR
    run_id: str | None = None # this will be None, or depend on attempt ID where we will find the attempt ID dynamically


    #### where is the manifest and eveyrthing stored??
    PATH_TO_DATA_FROM_CONSTRUCTION: Path = DEFAULT_PATH_TO_DATA_FROM_CONSTRUCTION # (see README_DATASET_STRUCTURE.md for context)

    @staticmethod
    def _next_generation_run_id(parent_of_detailed_save_dir: Path) -> str:
        candidate = 1
        while (parent_of_detailed_save_dir / str(candidate)).exists():
            candidate += 1
        return str(candidate)

    @model_validator(mode="before")
    @classmethod
    def _set_defaults_and_run_id_policy(cls, raw_data: object) -> object:
        if not isinstance(raw_data, dict):
            return raw_data

        data = dict(raw_data)

        evaluate_sample_only = data.get("evaluate_sample_only")
        if evaluate_sample_only is None:
            evaluate_sample_only = cls.DEFAULT_EVALUATE_SAMPLE_ONLY
            data["evaluate_sample_only"] = evaluate_sample_only

        if "sample_num" not in data or data["sample_num"] is None:
            data["sample_num"] = cls.DEFAULT_SAMPLE_NUM if evaluate_sample_only else None

        if "path_to_solve_rs_submitted" not in data or data["path_to_solve_rs_submitted"] is None:
            data["path_to_solve_rs_submitted"] = cls.DEFAULT_PATH_TO_SOLVE_RS_SUBMITTED

        if "PARENT_OF_DETAILED_SAVE_DIR" not in data or data["PARENT_OF_DETAILED_SAVE_DIR"] is None:
            data["PARENT_OF_DETAILED_SAVE_DIR"] = cls.DEFAULT_PARENT_OF_DETAILED_SAVE_DIR

        if (
            "PARENT_OF_COMPRESSED_SAVE_DIR" not in data
            or data["PARENT_OF_COMPRESSED_SAVE_DIR"] is None
        ):
            data["PARENT_OF_COMPRESSED_SAVE_DIR"] = cls.DEFAULT_PARENT_OF_COMPRESSED_SAVE_DIR

        if (
            "PATH_TO_DATA_FROM_CONSTRUCTION" not in data
            or data["PATH_TO_DATA_FROM_CONSTRUCTION"] is None
        ):
            data["PATH_TO_DATA_FROM_CONSTRUCTION"] = cls.DEFAULT_PATH_TO_DATA_FROM_CONSTRUCTION

        # run_id policy:
        # - generation/sample mode: assign the next available numeric id (1,2,3,...) using PARENT_OF_DETAILED_SAVE_DIR.
        # - all-tests mode: use a fixed run id.
        # So, during generation, I want run_id to be calculated dynamically ie it should go from 1, 2, ...
        # In order to find out which run_id, I want to listdir(PARENT_OF_DETAILED_SAVE_DIR) and see if 1 exists, if not, then run_id is 1, if it exists, then see if 2 exists, if not, then run_id is 2, and so on.
        if data.get("run_id") is None:
            if evaluate_sample_only:
                detailed_parent = Path(data["PARENT_OF_DETAILED_SAVE_DIR"])
                data["run_id"] = cls._next_generation_run_id(detailed_parent)
            else:
                data["run_id"] = cls.DEFAULT_RUN_ID_FOR_ALL_TESTS

        return data


    # post init
    #TODO: make sure path_to_solve_rs_submitted exists
    #TODO: make sure sample_num is a positive integer when evaluate_sample_only is True
    # make sure evaluate_all_password is None if evaluate_sample_only is True and else, it is a string!
    # make sure PARENT_OF_DETAILED_SAVE_DIR and PARENT_OF_COMPRESSED_SAVE_DIR already exist!
    # if run_id is not None, make sure that PARENT_OF_DETAILED_SAVE_DIR/run_id and PARENT_OF_COMPRESSED_SAVE_DIR/run_id DO NOT already exist!
    # for PATH_TO_DATA_FROM_CONSTRUCTION, nmake sure it exists and also, PATH_TO_DATA_FROM_CONSTRUCTION/snippets and PATH_TO_DATA_FROM_CONSTRUCTION/manifest.json exist and PATH_TO_DATA_FROM_CONSTRUCTION/eval_verdict.json exist and PATH_TO_DATA_FROM_CONSTRUCTION/solve.rs exists!
    @model_validator(mode="after")
    def _post_init_checks(self) -> "EvalRequest":
        assert self.path_to_solve_rs_submitted.exists()

        if self.evaluate_sample_only:
            assert self.sample_num is not None
            assert isinstance(self.sample_num, int)
            assert self.sample_num > 0
            assert self.evaluate_all_password is None
        else:
            assert self.sample_num is None
            if self.evaluate_all_password is not None:
                assert isinstance(self.evaluate_all_password, str)

        self.PARENT_OF_DETAILED_SAVE_DIR.mkdir(parents=True, exist_ok=True)
        self.PARENT_OF_COMPRESSED_SAVE_DIR.mkdir(parents=True, exist_ok=True)
        assert self.PARENT_OF_DETAILED_SAVE_DIR.is_dir()
        assert self.PARENT_OF_COMPRESSED_SAVE_DIR.is_dir()

        if self.run_id is not None:
            assert not (self.PARENT_OF_DETAILED_SAVE_DIR / self.run_id).exists()
            assert not (self.PARENT_OF_COMPRESSED_SAVE_DIR / self.run_id).exists()

        assert self.PATH_TO_DATA_FROM_CONSTRUCTION.exists()
        assert self.PATH_TO_DATA_FROM_CONSTRUCTION.is_dir()
        assert self.PATH_TO_SNIPPETS_DIR.exists()
        assert self.PATH_TO_MANIFEST_JSON.exists()
        # assert self.PATH_TO_EVAL_VERDICT_JSON.exists()
        assert self.PATH_TO_CANONICALIZATION_TEMPLATE_SOLVE_RS.exists()
        return self

    @computed_field(return_type=Literal["sample", "all"])
    @property
    def SAMPLE_OR_ALL(self) -> Literal["sample", "all"]:
        return "sample" if self.evaluate_sample_only else "all"

    @property
    def PATH_TO_MANIFEST_JSON(self) -> Path:
        return self.PATH_TO_DATA_FROM_CONSTRUCTION / "manifest.json"

    @property
    def PATH_TO_SNIPPETS_DIR(self) -> Path:
        return self.PATH_TO_DATA_FROM_CONSTRUCTION / "snippets"

    # @property
    # def PATH_TO_EVAL_VERDICT_JSON(self) -> Path:
    #     return self.PATH_TO_DATA_FROM_CONSTRUCTION / "eval_verdict.json"

    @property
    def PATH_TO_CANONICALIZATION_TEMPLATE_SOLVE_RS(self) -> Path:
        # Prefer solve_template.rs when present;
        template_path = self.PATH_TO_DATA_FROM_CONSTRUCTION / "solve_template.rs"
        assert template_path.exists()
        return template_path

    @property
    def PATH_TO_DETAILED_SAVE_DIR(self) -> Path:
        assert self.run_id is not None
        return self.PARENT_OF_DETAILED_SAVE_DIR / self.run_id

    @property
    def PATH_TO_COMPRESSED_SAVE_DIR(self) -> Path:
        assert self.run_id is not None
        return self.PARENT_OF_COMPRESSED_SAVE_DIR / self.run_id

    def resolve_inputs(self) -> ResolvedInputPaths:
        # LATER: implement path resolution + invariants here.
        solve_rs_submitted = self.path_to_solve_rs_submitted.resolve()
        manifest_json = self.PATH_TO_MANIFEST_JSON.resolve()
        snippets_dir = self.PATH_TO_SNIPPETS_DIR.resolve()
        canonicalization_template_solve_rs = self.PATH_TO_CANONICALIZATION_TEMPLATE_SOLVE_RS.resolve()

        if not solve_rs_submitted.is_file():
            raise FileNotFoundError(f"Submitted solve.rs not found: {solve_rs_submitted}")
        if not manifest_json.is_file():
            raise FileNotFoundError(f"manifest.json not found: {manifest_json}")
        if not snippets_dir.is_dir():
            raise FileNotFoundError(f"snippets directory not found: {snippets_dir}")
        if not canonicalization_template_solve_rs.is_file():
            raise FileNotFoundError(
                f"canonical template solve.rs not found: {canonicalization_template_solve_rs}"
            )

        return ResolvedInputPaths(
            solve_rs_submitted=solve_rs_submitted,
            manifest_json=manifest_json,
            snippets_dir=snippets_dir,
            canonicalization_template_solve_rs=canonicalization_template_solve_rs,
        )

    def build_output_logs_tree(self) -> "EvaluationLogsTree":
        # LATER: centralize output path policy here.
        if self.run_id is None:
            raise ValueError("run_id must be set before building output log paths")

        detailed_save_dir = self.PATH_TO_DETAILED_SAVE_DIR.resolve()
        compressed_save_dir = self.PATH_TO_COMPRESSED_SAVE_DIR.resolve()

        detailed_save_dir.mkdir(parents=True, exist_ok=True)
        compressed_save_dir.mkdir(parents=True, exist_ok=True)

        logs_tree = EvaluationLogsTree(
            root_directory=detailed_save_dir,
            compressed_root_directory=compressed_save_dir,
        )
        logs_tree.snippets_path.mkdir(parents=True, exist_ok=True)
        logs_tree.derived_files_dir.mkdir(parents=True, exist_ok=True)
        return logs_tree


class EvaluationLogsTree(BaseModel):
    root_directory: Path
    compressed_root_directory: Path

    @property
    def run_root(self) -> Path:
        return self.root_directory

    @property
    def compressed_run_root(self) -> Path:
        return self.compressed_root_directory

    @property
    def results_zip_path(self) -> Path:
        return self.compressed_run_root / "results.zip"

    # define global properties
    @property
    def solve_rs_submitted_path(self) -> Path:
        return self.root_directory / "solve_rs_submitted.rs"

    @property
    def solve_rs_post_canonical_path(self) -> Path:
        return self.root_directory / "solve_rs_post_canonical.rs"

    @property
    def natural_language_feedback_path(self) -> Path:
        return self.root_directory / "natural_language_feedback.txt"

    @property
    def structured_feedback_path(self) -> Path:
        return self.root_directory / "EvaluationFeedback.json"

    @property
    def snippets_path(self) -> Path:
        return self.root_directory / "snippets"

    @property
    def derived_files_dir(self) -> Path:
        return self.root_directory / "derived_files"

    @property
    def derived_check_pre_spec_completeness_path(self) -> Path:
        return self.derived_files_dir / "check_pre_spec_completeness.rs"

    @property
    def derived_check_pre_spec_soundness_path(self) -> Path:
        return self.derived_files_dir / "check_pre_spec_soundness.rs"

    @property
    def derived_check_post_spec_completeness_path(self) -> Path:
        return self.derived_files_dir / "check_post_spec_completeness.rs"

    @property
    def derived_check_post_spec_soundness_path(self) -> Path:
        return self.derived_files_dir / "check_post_spec_soundness.rs"

    @property
    def derived_pre_exec_spec_complete_path(self) -> Path:
        return self.derived_files_dir / "pre_exec_spec_complete.rs"

    @property
    def derived_pre_exec_spec_sound_path(self) -> Path:
        return self.derived_files_dir / "pre_exec_spec_sound.rs"

    @property
    def derived_post_exec_spec_complete_path(self) -> Path:
        return self.derived_files_dir / "post_exec_spec_complete.rs"

    @property
    def derived_post_exec_spec_sound_path(self) -> Path:
        return self.derived_files_dir / "post_exec_spec_sound.rs"

    #TODO: add each path of derived file as properties as well!
