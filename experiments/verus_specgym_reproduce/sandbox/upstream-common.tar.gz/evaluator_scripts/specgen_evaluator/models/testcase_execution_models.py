from __future__ import annotations

from enum import Enum
from pathlib import Path

from pydantic import BaseModel, computed_field, model_validator

from verus_gym_evals.specgen_evaluator.models.tc_representation import TestcaseRepresentation


class TestcaseTruthVerdict(str, Enum):
    SOUND = "sound"
    COMPLETE = "complete"
    INDETERMINATE = "indeterminate"


class VerusCompileVerdict(BaseModel):
    "This is for compiling a Verus program to a binary"
    exit_code: int
    time_elapsed: float | None = None
    stdout: str | None = None
    stderr: str | None = None
    compile_command: str | None = None

    # persisted outputs
    path_to_stderr: Path | None = None
    path_to_stdout: Path | None = None
    path_to_binary: Path | None = None


class VerusVerificationVerdict(BaseModel):
    "This is for verifying a Verus program"
    exit_code: int
    time_elapsed: float | None = None
    stdout: str | None = None
    stderr: str | None = None
    output_json: dict | None = None

    # persisted outputs
    path_to_stderr: Path | None = None
    path_to_stdout: Path | None = None
    path_to_output_json: Path | None = None


class VerusExecutionVerdict(BaseModel):
    "This is for executing a Verus program"
    exit_code: int
    time_elapsed: float | None = None
    stdout: str | None = None
    stderr: str | None = None
    run_command: str | None = None

    # persisted outputs
    path_to_stderr: Path | None = None
    path_to_stdout: Path | None = None
    path_to_binary: Path | None = None


class SymbolicArtifactVerdict(BaseModel):
    path_to_code: str
    verification_verdict: VerusVerificationVerdict

    @computed_field(return_type=bool)
    @property
    def did_succeed(self) -> bool:
        # Symbolic artifact succeeds iff the verification run succeeded.
        return self.verification_verdict.exit_code == 0


class RuntimeArtifactVerdict(BaseModel):
    "This is for executing a Verus program. It is mostly for exec_spec based execution!"
    path_to_code: str
    compile_verdict: VerusCompileVerdict
    path_to_compiled_binary: str | None = None
    execution_verdict: VerusExecutionVerdict | None = None

    @computed_field(return_type=bool)
    @property
    def did_succeed(self) -> bool:
        # Runtime artifact succeeds iff compilation succeeded and execution succeeded.
        if self.compile_verdict.exit_code != 0:
            return False
        if self.execution_verdict is None:
            # Defensive check: in the current pipeline we do not expect
            # self.execution_verdict to be None here.
            raise ValueError(
                "Unexpected RuntimeArtifactVerdict state: execution_verdict is None "
                "despite successful compilation."
            )
        return self.execution_verdict.exit_code == 0


class TestcaseEvaluation(BaseModel):
    testcase_representation: TestcaseRepresentation
    expected_verdict: TestcaseTruthVerdict # this is the expected verdict for the testcase, and it is either SOUND or COMPLETE

    symbolic_soundness_verdict: SymbolicArtifactVerdict
    symbolic_completeness_verdict: SymbolicArtifactVerdict

    execution_soundness_verdict: RuntimeArtifactVerdict | None = None
    execution_completeness_verdict: RuntimeArtifactVerdict | None = None

    @model_validator(mode="after")
    def _validate_expected_verdict(self) -> "TestcaseEvaluation":
        # Expected verdict cannot be INDETERMINATE!
        assert self.expected_verdict != TestcaseTruthVerdict.INDETERMINATE
        return self

    @computed_field(return_type=TestcaseTruthVerdict)
    @property
    def symbolic_verdict(self) -> TestcaseTruthVerdict:
        sound_ok = self.symbolic_soundness_verdict.did_succeed
        complete_ok = self.symbolic_completeness_verdict.did_succeed

        if (complete_ok) and (not sound_ok):
            return TestcaseTruthVerdict.COMPLETE
        if (sound_ok) and (not complete_ok):
            return TestcaseTruthVerdict.SOUND
        if (not sound_ok) and (not complete_ok):
            return TestcaseTruthVerdict.INDETERMINATE

        raise ValueError(
            "Invalid symbolic state: both symbolic_soundness_verdict and "
            "symbolic_completeness_verdict succeeded."
        )

    @computed_field(return_type=TestcaseTruthVerdict | None)
    @property
    def execution_verdict(self) -> TestcaseTruthVerdict | None:
        # Execution verdict is optional because runtime fallback may not run in cases where symbolic verdict is not INDETERMINATE
        if (self.execution_soundness_verdict is None) or (self.execution_completeness_verdict is None):
            return None

        sound_ok = self.execution_soundness_verdict.did_succeed
        complete_ok = self.execution_completeness_verdict.did_succeed

        
        if (complete_ok) and (not sound_ok):
            return TestcaseTruthVerdict.COMPLETE
        if (sound_ok) and (not complete_ok):
            return TestcaseTruthVerdict.SOUND
        if (not sound_ok) and (not complete_ok):
            return TestcaseTruthVerdict.INDETERMINATE

        raise ValueError(
            "Invalid execution state: both execution_soundness_verdict and "
            "execution_completeness_verdict succeeded."
        )

    @computed_field(return_type=TestcaseTruthVerdict)
    @property
    def overall_verdict(self) -> TestcaseTruthVerdict:
        symbolic = self.symbolic_verdict
        execution = self.execution_verdict

        # If execution was not run or did not resolve the case, defer to symbolic.
        if execution is None or execution == TestcaseTruthVerdict.INDETERMINATE:
            return symbolic

        if execution == TestcaseTruthVerdict.SOUND:
            if symbolic not in (TestcaseTruthVerdict.INDETERMINATE, TestcaseTruthVerdict.SOUND):
                raise ValueError(
                    "Contradiction: execution says SOUND but symbolic says COMPLETE."
                )
            return TestcaseTruthVerdict.SOUND

        if execution == TestcaseTruthVerdict.COMPLETE:
            if symbolic not in (TestcaseTruthVerdict.INDETERMINATE, TestcaseTruthVerdict.COMPLETE):
                raise ValueError(
                    "Contradiction: execution says COMPLETE but symbolic says SOUND."
                )
            return TestcaseTruthVerdict.COMPLETE

        raise ValueError(f"Unexpected execution verdict value: {execution}")

    @computed_field(return_type=bool)
    @property
    def does_testcase_have_expected_verdict(self) -> bool:
        return self.overall_verdict == self.expected_verdict

    def to_nl_feedback(self) -> str:
        """
        Build human-readable feedback for a *failed* testcase evaluation.

        Contract:
        - This method is intended to be called only when the testcase does NOT
          match the expected verdict for its bucket/category.
        - If the testcase passed (`does_testcase_have_expected_verdict == True`),
          this method raises ValueError.

        Output structure:
        1) Header line with testcase identity and expected vs observed verdict:
           - within_bucket_id
           - bucket/category
           - expected verdict
           - observed overall verdict
        2) A short expected-behavior line:
           - COMPLETE bucket expects: completeness pass + soundness fail
           - SOUND bucket expects: soundness pass + completeness fail
        3) Symbolic artifact lines (always present):
           - completeness_file, succeeded
           - soundness_file, succeeded
           - if symbolic check failed, include verification log paths:
             * <label>_verif_stdout
             * <label>_verif_stderr
        4) Runtime artifact lines (only if runtime fallback was executed):
           - completeness_file, succeeded
           - soundness_file, succeeded
           - if runtime failed due to compile failure, include:
             * <label>_compile_stdout
             * <label>_compile_stderr
           - if runtime failed after successful compile (execution failure), include:
             * <label>_exec_stdout
             * <label>_exec_stderr

        Notes:
        - All log references are paths (not content dumps).
        - Verdict string formatting is defensive: if a computed verdict raises
          due to a contradiction state, the error text is embedded instead of
          crashing feedback generation.
        """
        if self.does_testcase_have_expected_verdict:
            raise ValueError(
                "to_nl_feedback() should be called only when testcase verdict mismatches expected verdict."
            )

        # Keep this robust so feedback still prints even when a contradiction raises.
        try:
            symbolic_verdict_str = self.symbolic_verdict.value
        except Exception as exc:  # noqa: BLE001
            symbolic_verdict_str = f"error({exc})"

        try:
            execution_verdict_value = self.execution_verdict
            execution_verdict_str = (
                execution_verdict_value.value if execution_verdict_value is not None else "not_run"
            )
        except Exception as exc:  # noqa: BLE001
            execution_verdict_str = f"error({exc})"

        try:
            overall_verdict_str = self.overall_verdict.value
        except Exception as exc:  # noqa: BLE001
            overall_verdict_str = f"error({exc})"

        bucket = self.testcase_representation.category
        within_bucket_id = self.testcase_representation.within_bucket_id
        expected = self.expected_verdict.value

        if self.expected_verdict == TestcaseTruthVerdict.COMPLETE:
            expected_behavior_line = (
                "Expected behavior: completeness should succeed and soundness should fail."
            )
        else:
            expected_behavior_line = (
                "Expected behavior: soundness should succeed and completeness should fail."
            )

        def _path_or_none(path: Path | None) -> str:
            return str(path) if path is not None else "None"

        def _symbolic_line(label: str, artifact: SymbolicArtifactVerdict) -> str:
            base = (
                f"{label}_file=`{artifact.path_to_code}`, "
                f"succeeded={artifact.did_succeed}"
            )
            if artifact.did_succeed:
                return base
            # For symbolic checks, failure diagnostics come from verification artifacts.
            return (
                f"{base}, "
                f"{label}_verif_stdout=`{_path_or_none(artifact.verification_verdict.path_to_stdout)}`, "
                f"{label}_verif_stderr=`{_path_or_none(artifact.verification_verdict.path_to_stderr)}`"
            )

        def _runtime_line(label: str, artifact: RuntimeArtifactVerdict) -> str:
            base = (
                f"{label}_file=`{artifact.path_to_code}`, "
                f"succeeded={artifact.did_succeed}"
            )
            if artifact.did_succeed:
                return base

            # Runtime failure taxonomy:
            # 1) Compile failed -> surface compile stdout/stderr paths.
            if artifact.compile_verdict.exit_code != 0:
                return (
                    f"{base}, "
                    f"{label}_compile_stdout=`{_path_or_none(artifact.compile_verdict.path_to_stdout)}`, "
                    f"{label}_compile_stderr=`{_path_or_none(artifact.compile_verdict.path_to_stderr)}`"
                )

            # 2) Compile passed but execute failed/missing -> surface runtime stdout/stderr paths.
            if artifact.execution_verdict is None:
                return (
                    f"{base}, "
                    f"{label}_exec_stdout=`None`, "
                    f"{label}_exec_stderr=`None`"
                )
            if artifact.execution_verdict.exit_code != 0:
                return (
                    f"{base}, "
                    f"{label}_exec_stdout=`{_path_or_none(artifact.execution_verdict.path_to_stdout)}`, "
                    f"{label}_exec_stderr=`{_path_or_none(artifact.execution_verdict.path_to_stderr)}`"
                )

            return base

        lines = [
            (
                f"For within_bucket_id `{within_bucket_id}` in bucket `{bucket}`, "
                f"we expected verdict `{expected}` but observed `{overall_verdict_str}`."
            ),
            expected_behavior_line,
            (
                "Symbolic files and outcomes: "
                f"{_symbolic_line('completeness', self.symbolic_completeness_verdict)}; "
                f"{_symbolic_line('soundness', self.symbolic_soundness_verdict)}; "
                f"symbolic_verdict={symbolic_verdict_str}."
            ),
        ]

        if self.execution_completeness_verdict is None or self.execution_soundness_verdict is None:
            lines.append(
                "Runtime fallback files were not executed because symbolic verdict was not marked indeterminate."
            )
        else:
            lines.append(
                "Runtime files and outcomes: "
                f"{_runtime_line('completeness', self.execution_completeness_verdict)}; "
                f"{_runtime_line('soundness', self.execution_soundness_verdict)}; "
                f"execution_verdict={execution_verdict_str}."
            )

        return "\n".join(lines)

    
