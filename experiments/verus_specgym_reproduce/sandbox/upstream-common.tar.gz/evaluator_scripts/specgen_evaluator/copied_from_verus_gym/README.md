# Copied Upstream Files (Not Connected Yet)

These files were copied for incremental refactoring reference only.
They are intentionally **not wired into** the current `verus_gym_evals` pipeline yet.

## Source paths (absolute)

- `/Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/reward_server/syntax_checks.py`
- `/Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/proj_utils/tree_sitter_utils/tree_sitter_related.py`
- `/Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/proj_utils/tree_sitter_utils/utils.py`
- `/Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/evaluator_scripts/snippet_validation.py`
- `/Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/evaluator_scripts/evaluate_specgen.py`
