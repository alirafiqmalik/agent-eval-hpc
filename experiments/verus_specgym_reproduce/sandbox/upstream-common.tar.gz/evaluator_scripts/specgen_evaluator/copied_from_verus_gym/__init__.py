"""Copied upstream helpers used during incremental specgen refactor."""

