"""Local reward-server style helpers copied for specgen refactor."""

