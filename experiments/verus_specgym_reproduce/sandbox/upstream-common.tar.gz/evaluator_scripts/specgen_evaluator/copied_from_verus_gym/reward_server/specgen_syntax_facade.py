from __future__ import annotations

from typing import Mapping

from verus_gym_evals.specgen_evaluator.copied_from_verus_gym.proj_utils.tree_sitter_utils.tree_sitter_related import (
    fetch_verus_tree,
)
from verus_gym_evals.specgen_evaluator.copied_from_verus_gym.proj_utils.tree_sitter_utils.utils import (
    fetch_all_function_nodes,
)

# NOTE: Validation logic in this module is influenced by the following upstream files:
# - /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/reward_server/syntax_checks.py
# - /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/revised_task_runner.py
# The implementation is intentionally narrow for ValidateSubmissionPhase wiring.

FULL_MODE_REQUIRED_FUNCTIONS: tuple[str, ...] = (
    "pre_spec",
    "post_spec",
    "pre_spec_soundness_proof",
    "post_spec_soundness_proof",
    "pre_spec_completeness_proof",
    "post_spec_completeness_proof",
    "check_pre_spec_soundness",
    "check_post_spec_soundness",
    "check_pre_spec_completeness",
    "check_post_spec_completeness",
    "main_exec_pre_spec_check",
    "main_exec_post_spec_check",
    "main",
)


def parse_function_map(code_snippet: str) -> Mapping[str, dict]:
    """Parse Verus code and return fn-name -> function-details mapping."""
    tree = fetch_verus_tree(code_snippet)
    root = tree.root_node
    if root is None:
        raise ValueError("tree-sitter returned no root node for solve.rs.")
    if getattr(root, "has_error", False):
        raise ValueError("tree-sitter detected parse errors in solve.rs.")
    return fetch_all_function_nodes(root)


def validate_required_functions(
    code_snippet: str,
    required_function_names: tuple[str, ...] = FULL_MODE_REQUIRED_FUNCTIONS,
) -> list[str]:
    """
    Validate that all required function names are present in parsed solve.rs.

    Returns a list of diagnostics; empty means validation success.
    """
    diagnostics: list[str] = []

    try:
        fn_map = parse_function_map(code_snippet)
    except Exception as exc:  # noqa: BLE001
        diagnostics.append(f"Failed to parse submitted solve.rs with tree-sitter: {exc}")
        return diagnostics

    missing = [fn_name for fn_name in required_function_names if fn_name not in fn_map]
    if missing:
        diagnostics.append(
            "The following functions were expected to be present in solve.rs "
            f"but were missing or deleted: {', '.join(missing)}."
        )

    return diagnostics
