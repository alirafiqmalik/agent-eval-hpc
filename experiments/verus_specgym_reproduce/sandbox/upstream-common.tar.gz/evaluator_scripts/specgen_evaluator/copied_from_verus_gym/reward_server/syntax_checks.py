from __future__ import annotations

from copy import deepcopy

import verus_gym_evals.specgen_evaluator.copied_from_verus_gym.proj_utils.tree_sitter_utils.tree_sitter_related as tree_sitter_related
from verus_gym_evals.specgen_evaluator.copied_from_verus_gym.proj_utils.tree_sitter_utils.utils import (
    fetch_all_function_nodes,
)

# REVISIT: TODO: EXISTENTIAL: This module keeps only the minimal subset
# required by current specgen_evaluator runtime flow.
#
# Copied/influenced from:
# - /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/reward_server/syntax_checks.py
#   function get_specgen_check_files(...) (~line 1105) and helpers used by it.


def _parse_fn_map(code: str) -> dict[str, dict]:
    tree = tree_sitter_related.fetch_verus_tree(code)
    return fetch_all_function_nodes(tree.root_node)


def _strip_all_attribute_items(code: str) -> str:
    """
    Remove all `attribute_item` nodes (`#[...]`) from the snippet.

    This is AST-based and also strips attributes inside
    exec_spec_verified!/exec_spec_unverified! token trees.
    """
    code_bytes = code.encode("utf-8")

    # Step 1: Strip attributes inside exec_spec_verified / exec_spec_unverified
    # token trees.
    tree = tree_sitter_related.fetch_verus_tree(code)
    macro_nodes = tree_sitter_related.fetch_type_nodes(tree.root_node, ["macro_invocation"])
    token_tree_replacements: list[tuple[int, int, bytes]] = []

    for macro_node in macro_nodes:
        macro_ident_node = macro_node.child_by_field_name("macro")
        if macro_ident_node is None:
            continue
        macro_name = (macro_ident_node.text.decode("utf-8") or "").strip()
        if not macro_name:
            continue
        macro_basename = macro_name.split("::")[-1]
        if macro_basename not in (
            "exec_spec_verified",
            "exec_spec_unverified",
        ):
            continue

        token_tree_node = next((child for child in macro_node.children if child.type == "token_tree"), None)
        if token_tree_node is None:
            continue

        token_tree_bytes = token_tree_node.text
        if len(token_tree_bytes) < 2:
            continue
        opening = token_tree_bytes[:1]
        closing = token_tree_bytes[-1:]
        matching = {b"{": b"}", b"(": b")", b"[": b"]"}
        has_delims = opening in matching and matching[opening] == closing
        inner_bytes = token_tree_bytes[1:-1] if has_delims else token_tree_bytes

        try:
            inner_tree = tree_sitter_related.fetch_verus_tree(inner_bytes.decode("utf-8"))
        except Exception:
            continue
        inner_attr_nodes = tree_sitter_related.fetch_type_nodes(inner_tree.root_node, ["attribute_item"])
        if not inner_attr_nodes:
            continue

        spans = sorted([(n.start_byte, n.end_byte) for n in inner_attr_nodes], reverse=True)
        stripped_inner = inner_bytes
        for start_byte, end_byte in spans:
            stripped_inner = stripped_inner[:start_byte] + stripped_inner[end_byte:]

        updated_token_tree = (opening + stripped_inner + closing) if has_delims else stripped_inner
        token_tree_replacements.append((token_tree_node.start_byte, token_tree_node.end_byte, updated_token_tree))

    updated_bytes = code_bytes
    for start_byte, end_byte, replacement in sorted(token_tree_replacements, reverse=True):
        updated_bytes = updated_bytes[:start_byte] + replacement + updated_bytes[end_byte:]

    # Step 2: Strip attribute nodes in the outer snippet.
    updated = updated_bytes.decode("utf-8")
    outer_tree = tree_sitter_related.fetch_verus_tree(updated)
    outer_attr_nodes = tree_sitter_related.fetch_type_nodes(outer_tree.root_node, ["attribute_item"])
    spans = sorted([(n.start_byte, n.end_byte) for n in outer_attr_nodes], reverse=True)
    stripped = updated_bytes
    for start_byte, end_byte in spans:
        stripped = stripped[:start_byte] + stripped[end_byte:]
    return stripped.decode("utf-8")


def get_specgen_check_files(solve_code_content: str, pre_only: bool = False) -> dict[str, str]:
    """
    Build derived specgen files from canonicalized solve.rs.

    Behavior is aligned with old pipeline get_specgen_check_files:
    - selective keep/drop by bucket
    - AST-based #[...] stripping
    - runtime exec fallback files
    """
    if pre_only:
        fn_list = [
            "pre_spec",
            "pre_spec_soundness_proof",
            "pre_spec_completeness_proof",
            "check_pre_spec_soundness",
            "check_pre_spec_completeness",
            "main_exec_pre_spec_check",
            "main",
        ]
        selective_functions: dict[str, list[str]] = {
            "check_pre_spec_soundness": [
                "pre_spec",
                "pre_spec_soundness_proof",
                "check_pre_spec_soundness",
            ],
            "check_pre_spec_completeness": [
                "pre_spec",
                "pre_spec_completeness_proof",
                "check_pre_spec_completeness",
            ],
        }
    else:
        fn_list = [
            "pre_spec",
            "post_spec",
            "pre_spec_soundness_proof",
            "post_spec_soundness_proof",
            "pre_spec_completeness_proof",
            "post_spec_completeness_proof",
            "check_pre_spec_soundness",
            "check_post_spec_soundness",
            "check_pre_spec_completeness",
            "check_post_spec_completeness",
            "main_exec_pre_spec_check",
            "main_exec_post_spec_check",
            "main",
        ]
        selective_functions = {
            "check_pre_spec_soundness": [
                "pre_spec",
                "pre_spec_soundness_proof",
                "check_pre_spec_soundness",
            ],
            "check_pre_spec_completeness": [
                "pre_spec",
                "pre_spec_completeness_proof",
                "check_pre_spec_completeness",
            ],
            "check_post_spec_soundness": [
                "pre_spec",
                "post_spec",
                "post_spec_soundness_proof",
                "check_post_spec_soundness",
            ],
            "check_post_spec_completeness": [
                "pre_spec",
                "post_spec",
                "post_spec_completeness_proof",
                "check_post_spec_completeness",
            ],
        }

    original_solve_code = _strip_all_attribute_items(deepcopy(solve_code_content))
    fn_details = _parse_fn_map(original_solve_code)
    all_function_names = list(fn_details.keys())

    model_added_functions = [fn for fn in all_function_names if fn not in fn_list]

    function_bodies: dict[str, str] = {
        fn_name: fn_details[fn_name]["fn_entire_body"] for fn_name in all_function_names
    }
    if not all(original_solve_code.count(body) == 1 for body in function_bodies.values()):
        raise ValueError("Expected all function bodies to appear uniquely in solve.rs.")

    derived_files: dict[str, str] = {}

    def _drop_fn_entire_body(code_variant: str, *, fn_name: str, fn_body: str, file_stem: str) -> str:
        if code_variant.count(fn_body) != 1:
            raise ValueError(
                f"Function body for {fn_name} not found uniquely when building {file_stem}."
            )
        return code_variant.replace(fn_body, "")

    for new_file_stem, core_keep_list in selective_functions.items():
        keep_set = set(core_keep_list + model_added_functions)
        code_variant = deepcopy(original_solve_code)

        for fn_name, fn_body in function_bodies.items():
            if fn_name in keep_set:
                continue
            code_variant = _drop_fn_entire_body(
                code_variant,
                fn_name=fn_name,
                fn_body=fn_body,
                file_stem=new_file_stem,
            )

        derived_files[new_file_stem] = code_variant

    # Runtime exec_spec fallback templates
    spec_function_names = [
        name for name, details in fn_details.items() if details.get("function_mode") == "spec"
    ]

    main_details = fn_details.get("main")
    if main_details is None:
        raise ValueError("Expected `fn main()` to exist in specgen solve.rs when building derived files.")
    main_entire_body = main_details.get("fn_entire_body")
    main_block_body = main_details.get("fn_block_body")
    if not isinstance(main_entire_body, str) or not isinstance(main_block_body, str):
        raise ValueError("Failed to extract `fn main()` text from specgen solve.rs for runtime templates.")

    def _rewrite_main_block(code_variant: str, *, new_block_body: str, file_stem: str) -> str:
        if code_variant.count(main_entire_body) != 1:
            raise ValueError(f"Could not uniquely locate `fn main()` in code when building {file_stem}.")
        if main_block_body not in main_entire_body:
            raise ValueError(f"Unexpected main() structure while building {file_stem}.")
        new_main_entire = "#[verifier::external_body]\n" + main_entire_body.replace(
            main_block_body, new_block_body, 1
        )
        return code_variant.replace(main_entire_body, new_main_entire, 1)

    runtime_keep_set_post = set(spec_function_names + ["main"])
    runtime_keep_set_pre = set(spec_function_names + ["main"])
    runtime_keep_set_pre.discard("post_spec")

    def _build_runtime_base(*, keep_set: set[str], file_stem: str) -> str:
        runtime_base = deepcopy(original_solve_code)
        for fn_name, fn_body in function_bodies.items():
            if fn_name in keep_set:
                continue
            runtime_base = _drop_fn_entire_body(
                runtime_base,
                fn_name=fn_name,
                fn_body=fn_body,
                file_stem=file_stem,
            )
        return runtime_base

    runtime_base_pre = _build_runtime_base(
        keep_set=runtime_keep_set_pre,
        file_stem="exec_spec_runtime_base_pre",
    )
    runtime_base_post = _build_runtime_base(
        keep_set=runtime_keep_set_post,
        file_stem="exec_spec_runtime_base_post",
    )

    pre_exec_complete_block = """{
        // __PASTE_out.input_defn__
        let result = exec_pre_spec(&exec_in1);
        assert_eq!(result, true);
    }"""
    pre_exec_sound_block = """{
        // __PASTE_out.input_defn__
        let result = exec_pre_spec(&exec_in1);
        assert_eq!(result, false);
    }"""

    pre_exec_complete_code = _rewrite_main_block(
        deepcopy(runtime_base_pre),
        new_block_body=pre_exec_complete_block,
        file_stem="pre_exec_spec_complete",
    )
    pre_exec_sound_code = _rewrite_main_block(
        deepcopy(runtime_base_pre),
        new_block_body=pre_exec_sound_block,
        file_stem="pre_exec_spec_sound",
    )

    assert pre_exec_complete_code.count("// __PASTE_out.input_defn__") == 1
    assert pre_exec_sound_code.count("// __PASTE_out.input_defn__") == 1

    derived_files["pre_exec_spec_complete"] = pre_exec_complete_code
    derived_files["pre_exec_spec_sound"] = pre_exec_sound_code

    if not pre_only:
        if "post_spec" not in fn_details:
            raise ValueError(
                "Expected `post_spec` to exist in full specgen mode when building exec_spec runtime templates."
            )

        post_exec_complete_block = """{
        // __PASTE_out.input_defn__
        // __PASTE_out.gt_output_defn__
        let result = exec_post_spec(&exec_in1, &exec_out);
        assert_eq!(result, true);
    }"""
        post_exec_sound_block = """{
        // __PASTE_out.input_defn__
        // __PASTE_out.gt_output_defn__
        let result = exec_post_spec(&exec_in1, &exec_out);
        assert_eq!(result, false);
    }"""

        post_exec_complete_code = _rewrite_main_block(
            deepcopy(runtime_base_post),
            new_block_body=post_exec_complete_block,
            file_stem="post_exec_spec_complete",
        )
        post_exec_sound_code = _rewrite_main_block(
            deepcopy(runtime_base_post),
            new_block_body=post_exec_sound_block,
            file_stem="post_exec_spec_sound",
        )

        assert post_exec_complete_code.count("// __PASTE_out.input_defn__") == 1
        assert post_exec_complete_code.count("// __PASTE_out.gt_output_defn__") == 1
        assert post_exec_sound_code.count("// __PASTE_out.input_defn__") == 1
        assert post_exec_sound_code.count("// __PASTE_out.gt_output_defn__") == 1

        derived_files["post_exec_spec_complete"] = post_exec_complete_code
        derived_files["post_exec_spec_sound"] = post_exec_sound_code

    return derived_files


__all__ = ["get_specgen_check_files"]
