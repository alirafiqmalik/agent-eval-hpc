"""Copied tree-sitter utilities namespace."""

