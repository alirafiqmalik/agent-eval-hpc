"""Local tree-sitter helper entrypoints."""

__all__: list[str] = []
