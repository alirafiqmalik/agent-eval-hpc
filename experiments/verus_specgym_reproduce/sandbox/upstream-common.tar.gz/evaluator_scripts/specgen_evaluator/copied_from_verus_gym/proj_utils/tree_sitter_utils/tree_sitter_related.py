# Importing necessary modules from tree_sitter
# NOTE: Copied and lightly adapted from:
# /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/proj_utils/tree_sitter_utils/tree_sitter_related.py
# We intentionally keep this local to verus_gym_evals so it can be imported
# without depending on the full verus_gym package.
import tree_sitter_verus as tsverus
from tree_sitter import Language, Parser

# PY_LANGUAGE = Language(tspython.language())
VERUS_LANGUAGE = Language(tsverus.language())



def fetch_verus_parser():
    """Fetches and returns a Verus parser using tree-sitter"""
    return Parser(VERUS_LANGUAGE)


class SpanRelated:
    """Class containing static methods for span-related operations"""

    @staticmethod
    def convert_to_tuple_format(original_span):
        """Converts the span to a tuple format"""
        assert len(original_span) == 2  # Ensure the span has 2 elements
        assert len(original_span[0]) == 2
        assert len(original_span[1]) == 2
        return (
            (original_span[0][0], original_span[0][1]),
            (original_span[1][0], original_span[1][1]),
        )  # Convert to tuple format

    @staticmethod
    def has_span_overlap(span1, span2):
        """Returns True if the spans overlap, else False"""
        # When do 2 ranges not overlap? They don't overlap when one of them
        # starts after the other one ends
        span1, span2 = (
            SpanRelated.convert_to_tuple_format(span1),
            SpanRelated.convert_to_tuple_format(span2),
        )
        dont_overlap = (span1[1] < span2[0]) or (
            span1[0] > span2[1]
        )  # Check for non-overlapping condition
        return not dont_overlap

    @staticmethod
    def does_span_contain(parent_span, child_span):
        """Returns True if span1 contains span2, else False"""
        parent_span, child_span = (
            SpanRelated.convert_to_tuple_format(parent_span),
            SpanRelated.convert_to_tuple_format(child_span),
        )
        return (parent_span[0] <= child_span[0]) and (
            parent_span[1] >= child_span[1]
        )  # Check if parent_span contains child_span


# def fetch_python_parser():
#     '''Fetches and returns a Python parser using tree-sitter'''
#     # PY_LANGUAGE = Language(
#     #     so_file_path, "python")  # Load the Python language from the shared object file
#     parser = get_parser(
#     "python"
#     )

#     # parser = Parser()
#     # parser.set_language(PY_LANGUAGE)
#     return parser


def fetch_tree(parser, code_use):
    """Parses the given code and returns the syntax tree"""
    tree = parser.parse(bytes(code_use, "utf8"))
    return tree

def fetch_verus_tree(code_use: str):
    """Parses Verus code and returns the syntax tree"""
    return fetch_tree(fetch_verus_parser(), code_use)


def fetch_relevant_body(node, test_code_str):
    """Fetches the relevant body of code for a given node"""
    lb, ub = node.start_point, node.end_point
    all_lines = test_code_str.split("\n")
    ans_str = ""
    if lb[0] == ub[0]:  # If the node is within a single line
        # Extract the relevant part of the line
        ans_str = all_lines[lb[0]][lb[1] : ub[1]]
    else:  # If the node spans multiple lines
        # Extract from the start point to the end of the line
        ans_str = all_lines[lb[0]][lb[1] :]
        for _line in range(lb[0] + 1, ub[0]):  # Loop through the lines in between
            ans_str += "\n"
            ans_str += all_lines[_line]  # Add each line to the result
        ans_str += "\n"
        # Add the part of the last line up to the end point
        ans_str += all_lines[ub[0]][: ub[1]]
    return ans_str


def fetch_type_nodes(s, desired_types_list: list[str]):
    """Fetches nodes of the desired types from the syntax tree"""
    relevant_nodes = []

    if s.type in desired_types_list:
        relevant_nodes.append(s)

    for curr_child in s.children:  # Recursively fetch nodes of the desired types from the children
        relevant_nodes += fetch_type_nodes(curr_child, desired_types_list)

    return relevant_nodes  # Return the list of relevant nodes


# def fetch_nodes_of_type(file_path, types_allowed, wanted_parent_span=None):
#     """Fetches the locations of type annotations in the file in the form [{"node_text", "span"}]"""
#     parser = fetch_verus_parser()  # Fetch the Verus parser
#     test_code_str = open(file_path).read()  # Read the code from the file

#     generic_type_nodes = fetch_type_nodes(
#         fetch_tree(parser, test_code_str).root_node, types_allowed
#     )  # Fetch nodes of the desired types

#     node_list = [
#         {
#             "node_obj": curr_node,
#             "node_txt": fetch_relevant_body(curr_node, test_code_str),
#             "start_point": curr_node.start_point,
#             "end_point": curr_node.end_point,
#         }
#         for curr_node in generic_type_nodes
#     ]  # Create a list of node details

#     # tree sitter has 0-based indexing whereas jedi has 1-based indexing, adjust for this
#     for curr_node in node_list:
#         curr_node["start_point"] = (
#             curr_node["start_point"][0] + 1,  # row
#             curr_node["start_point"][1],
#         )  # column
#         curr_node["end_point"] = (
#             curr_node["end_point"][0] + 1,  # row
#             curr_node["end_point"][1],
#         )  # column
#         curr_node["span"] = SpanRelated.convert_to_tuple_format(
#             (curr_node["start_point"], curr_node["end_point"])
#         )  # Convert start and end points to span
#         # Remove the start point from the dictionary
#         del curr_node["start_point"]
#         del curr_node["end_point"]  # Remove the end point from the dictionary

#     return node_list  # Return the list of nodes with their details


# def format_node_list(nodes, file_body):
#     """Formats the list of nodes with their details"""
#     formatted_identifier_nodes = []
#     for node in nodes:
#         formatted_identifier_nodes.append(
#             {
#                 "node_obj": node,
#                 "node_txt": fetch_relevant_body(node, file_body),
#                 "start_point": node.start_point,
#                 "end_point": node.end_point,
#             }
#         )  # Create a list of formatted nodes

#     for node in formatted_identifier_nodes:
#         node["start_point"] = (
#             node["start_point"][0] + 1,  # row
#             node["start_point"][1],
#         )  # Adjust the start point for 1-based indexing
#         node["end_point"] = (
#             node["end_point"][0] + 1,  # row
#             node["end_point"][1],
#         )  # Adjust the end point for 1-based indexing
#         node["span"] = SpanRelated.convert_to_tuple_format(
#             (node["start_point"], node["end_point"])
#         )  # Convert to span
#         del node["start_point"]  # Remove the start point from the dictionary
#         del node["end_point"]  # Remove the end point from the dictionary
#     formatted_identifier_nodes = sorted(
#         formatted_identifier_nodes, key=lambda x: x["span"]
#     )  # Sort nodes by span
#     return formatted_identifier_nodes  # Return the formatted list of nodes


# def fetch_class_and_function_nodes_defn_identifiers(file_path):
#     """Fetches the class and function definition identifiers from the file"""
#     wanted_definition_nodes = fetch_nodes_of_type(
#         file_path, ["function_definition", "class_definition"]
#     )  # Fetch function and class definition nodes
#     file_body = open(file_path).read()  # Read the code from the file

#     # now, in the children of these nodes, find the identifier nodes
#     identifier_nodes = []
#     for node in wanted_definition_nodes:
#         # Fetch identifier nodes from the children
#         curr_identifier_nodes = [x for x in node["node_obj"].children if x.type == "identifier"]
#         # Ensure there is exactly one identifier node
#         assert len(curr_identifier_nodes) == 1
#         # Add the identifier node to the list
#         identifier_nodes.append(curr_identifier_nodes[0])
#     formatted_identifier_nodes = format_node_list(
#         identifier_nodes, file_body
#     )  # Format the list of identifier nodes

#     return formatted_identifier_nodes  # Return the formatted list of identifier nodes


# def find_left_side_identifiers_of_assignments(file_path):
#     """Fetches the left side identifiers of assignments from the file"""
#     wanted_definition_nodes = fetch_nodes_of_type(file_path, ["assignment"])
#     file_body = open(file_path).read()

#     identifier_nodes = []
#     # now, in the children of these nodes, find the identifier nodes
#     for node in wanted_definition_nodes:
#         node_obj = node["node_obj"]
#         # first child should be the left side of the assignment and should be an identifier
#         assert len(node_obj.children) > 0
#         # assert(node_obj.children[0].type == "identifier") # this does not hold true in cases such as : `self.x  = 1`
#         if node_obj.children[0].type == "identifier":
#             identifier_nodes.append(node_obj.children[0])
#     identifier_nodes = format_node_list(identifier_nodes, file_body)
#     return identifier_nodes


# def fetch_entity_artifacts(class_body, entity_type):
#     assert entity_type in ["class", "function"]
#     parser = fetch_verus_parser()
#     tree = fetch_tree(parser, class_body)
#     entity_node = tree.root_node
#     # fetch all nodes of type `class_definition`
#     entity_defn_nodes = fetch_type_nodes(entity_node, [f"{entity_type}_definition"])
#     entity_defn_nodes = sorted(entity_defn_nodes, key=lambda x: x.start_point)
#     assert len(entity_defn_nodes) > 0
#     entity_root_node = entity_defn_nodes[0]

#     block_nodes = fetch_type_nodes(entity_root_node, ["block"])
#     assert len(block_nodes) > 0
#     block_nodes = sorted(block_nodes, key=lambda x: x.start_point)
#     entity_block_node = block_nodes[0]

#     entity_root_node_txt = fetch_relevant_body(entity_root_node, class_body)
#     entity_block_node_txt = fetch_relevant_body(entity_block_node, class_body)
#     assert entity_block_node_txt in entity_root_node_txt
#     entity_signature = entity_root_node_txt.split(entity_block_node_txt)[0]

#     ans = dict()

#     # remove extra spaces
#     ans["signature"] = entity_signature.replace("\n", " ")
#     ans["signature"] = re.sub(r"\s+", " ", ans["signature"]).strip()
#     ans["block"] = entity_block_node_txt
#     ans["docstring"] = ""
#     if len(entity_block_node.children) > 0:
#         first_child = entity_block_node.children[0]
#         if first_child.type == "expression_statement":
#             if len(first_child.children) > 0:
#                 first_child_child = first_child.children[0]
#                 if first_child_child.type == "string":
#                     ans["docstring"] = fetch_relevant_body(first_child_child, class_body)
#     ans = {k: v.strip() for k, v in ans.items()}
#     return ans

def print_tree_dfs(node, depth=0):  
    indent = "  " * depth  
    print("-"*100)
    
    print(f"{indent}{node.type}: {node.text}")  
    print("-"*100)
    for child in node.children:  
        print_tree_dfs(child, depth + 1)  
  
# Usage  
# tree = parser.parse(source_code)  
# print_tree_dfs(tree.root_node)

def print_tree_rev(source_code, parser):
    def collect_all_nodes(node, nodes_list):  
        """Recursively collect all nodes in the tree"""  
        nodes_list.append(node)  
        for child in node.children:  
            collect_all_nodes(child, nodes_list)  
    
    def get_node_size(node):  
        """Calculate node size as byte range"""  
        return node.end_byte - node.start_byte  
    
    # Parse and collect all nodes  
    tree = parser.parse(source_code.encode("utf-8"))  
    all_nodes = []  
    collect_all_nodes(tree.root_node, all_nodes)  
    
    # Sort by size (decreasing order)  
    sorted_nodes = sorted(all_nodes, key=get_node_size, reverse=True)  
    
    # Print node information  
    for node in sorted_nodes:  
        print(f"ID: {node.id}")  
        print(f"Type: {node.type}")  
        print(f"Line span: ({node.start_point.row}, {node.start_point.column}) to ({node.end_point.row}, {node.end_point.column})")  
        print(f"Character span: {node.start_byte} to {node.end_byte}")  
        print(f"Size: {get_node_size(node)} bytes")  
        print(f"Text: {node.text.decode('utf-8', errors='replace')}")  
        print("---")

if __name__ == "__main__":
    code_use = "fn main() { let x = 1; }"
    verus_file_path = "/Users/anmolagarwal/Desktop/anmol_oct/verus_gym/scratchpad_verus_programs/check_fmt.rs"
    with open(verus_file_path, "r") as f:
        code_use = f.read()
    # tree = fetch_rust_tree(code_use)
    tree = fetch_verus_tree(code_use)
    # print_tree_dfs(tree.root_node)
    # print(tree.root_node.type)
    print_tree_rev(code_use, fetch_verus_parser())
    _ = 1
