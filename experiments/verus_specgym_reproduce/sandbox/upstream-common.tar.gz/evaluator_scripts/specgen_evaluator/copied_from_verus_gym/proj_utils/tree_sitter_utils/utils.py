import json
import logging
import os
from typing import Dict, List, Optional

# NOTE: Copied and lightly adapted from:
# /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/proj_utils/tree_sitter_utils/utils.py
# so this module can be imported from verus_gym_evals without depending on
# the full verus_gym package.
import verus_gym_evals.specgen_evaluator.copied_from_verus_gym.proj_utils.tree_sitter_utils.tree_sitter_related as tree_sitter_related

logger = logging.getLogger(__name__)
# TYPE_NODE_CANDIDATES = {
#     "reference_type",
#     "type_identifier",
#     "tuple_type",
#     "array_type",
#     "scoped_identifier",
#     "primitive_type",
#     "generic_type",
#     "qualified_type",
#     "pointer_type",
# }


def _node_text(node, strip: bool = False) -> str:
    """Decode a tree-sitter node into UTF-8 text."""
    if node is None:
        return ""
    text = node.text.decode("utf-8")
    return text.strip() if strip else text


def _extract_parameter_like_entries(parent_node) -> List[Dict[str, Optional[str]]]:
    """
    Tree-sitter represents both parameters and named return types using `parameter`
    children. Convert those nodes into the {identifier, reference_type} structure.
    """
    entries: List[Dict[str, Optional[str]]] = []
    if parent_node is None:
        return entries

    for child in parent_node.children:
        if child.type != "parameter":
            continue

        identifier_node = next((c for c in child.children if c.type == "identifier"), None)
        reference_type_node = next((c for c in child.children if c.type == "reference_type"), None)

        # If no reference_type, try type_identifier (for plain types like In1, Out)
        if reference_type_node is None:
            reference_type_node = next((c for c in child.children if c.type == "type_identifier"), None)

        identifier_txt = _node_text(identifier_node, strip=True) or None
        reference_type_txt = _node_text(reference_type_node, strip=True) or None

        entries.append(
            {
                "identifier": identifier_txt,
                "reference_type": reference_type_txt,
            }
        )

    # If there were no explicit `parameter` nodes, treat the raw text (if any) as a single entry.
    # if not entries:
    #     fallback_txt = _node_text(parent_node, strip=True)
    #     if fallback_txt:
    #         entries.append(
    #             {
    #                 "identifier": None,
    #                 "reference_type": fallback_txt,
    #             }
    #         )

    return entries


# function to get arguments
def fetch_function_details(function_node) -> Dict[str, Optional[str]]:
    # get the `fn_name` (which is first child identifier node's text)
    # get the `fn_entire_body` (which is the text of the function node)
    # get the `fn_block_body` (which is the text of the first child block node)
    # fn_qualifier (which is the text of the first child fn_qualifier node if it exists, can be None)
    # parameters (which is the text of the first child `parameters`` node if it exists, can be None) # break into list of {'identifier': text, 'reference_type': text}
    # return_type (which is the text of the first child `named_return_type` node if it exists, can be None)# break into list of {'identifier': text, 'reference_type': text}
    # get `function_mode` (which is text of first child of type `function_mode` if it exists, can be None)
    identifier_node = next((child for child in function_node.children if child.type == "identifier"), None)
    block_node = next((child for child in function_node.children if child.type == "block"), None)
    qualifier_node = next((child for child in function_node.children if child.type == "fn_qualifier"), None)
    parameters_node = next((child for child in function_node.children if child.type == "parameters"), None)
    named_return_node = next((child for child in function_node.children if child.type == "named_return_type"), None)
    function_mode_node = next((child for child in function_node.children if child.type == "function_mode"), None)

    fn_entire_body = _node_text(function_node)
    fn_block_body = _node_text(block_node)
    fn_qualifier = _node_text(qualifier_node, strip=True) or None
    fn_name = _node_text(identifier_node, strip=True) or None
    function_mode = _node_text(function_mode_node, strip=True) or None

    parameters_raw = _node_text(parameters_node) or None
    return_raw = _node_text(named_return_node) or None

    parameters = _extract_parameter_like_entries(parameters_node)
    return_entries = _extract_parameter_like_entries(named_return_node)

    function_details: Dict[str, Optional[str] | List[Dict[str, Optional[str]]]] = {
        "fn_name": fn_name,
        "fn_entire_body": fn_entire_body,
        "fn_block_body": fn_block_body or None,
        "fn_qualifier": fn_qualifier,
        "function_mode": function_mode,
        "input_args": {
            "raw": parameters_raw,
            "items": parameters,
        },
        "output_args": {
            "raw": return_raw,
            "items": return_entries,
        },
        "node": function_node,
    }

    return function_details


def fetch_all_function_nodes(root_node) -> Dict[str, dict]:
    #  get all nodes of type "function_item"
    # return dict where key = function_name, value = functions_details_dict (fetched by calling fetch_function_details)
    function_nodes = tree_sitter_related.fetch_type_nodes(root_node, ["function_item"])
    fn_name_to_details_mapping: Dict[str, dict] = {}

    for fn_node in function_nodes:
        fn_details = fetch_function_details(fn_node)
        fn_name = fn_details['fn_name']
        if not fn_name:
            continue
        if fn_name in fn_name_to_details_mapping:
            # sometimes, this may happen because of the model itself
            # raise ValueError(f"Duplicate function definition detected for `{fn_name}`.")
            logger.warning(f"Duplicate function definition detected for `{fn_name}`.")
            continue
        fn_name_to_details_mapping[fn_name] = fn_details

    # NOTE:
    # Tree-sitter (including tree-sitter-verus) treats most macros as `macro_invocation`
    # nodes whose body is a `token_tree` (i.e., *not* parsed into real Rust/Verus items).
    #
    # The Verus exec-spec macros frequently contain `spec fn pre_spec(...)` /
    # `spec fn post_spec(...)` definitions, and we want to treat those as "real"
    # functions for downstream syntax checking.
    #
    # To support this, we detect exec-spec macro invocations, parse the inner
    # token_tree text as a standalone snippet, and then extract any
    # `function_item` nodes found in that inner parse.
    macro_invocation_nodes = tree_sitter_related.fetch_type_nodes(root_node, ["macro_invocation"])
    for macro_node in macro_invocation_nodes:
        macro_ident_node = macro_node.child_by_field_name("macro") # this is to get the name of the macro!
        if macro_ident_node is None:
            continue

        macro_name = _node_text(macro_ident_node, strip=True)
        if not macro_name:
            continue

        # Support the renamed exec-spec macro family, including path-qualified
        # forms like `vstd::contrib::exec_spec::exec_spec_verified!`.
        macro_basename = macro_name.split("::")[-1]
        if macro_basename not in (
            "exec_spec_verified",
            "exec_spec_unverified",
        ):
            continue

        token_tree_node = next((child for child in macro_node.children if child.type == "token_tree"), None)
        if token_tree_node is None:
            continue

        # Be slightly defensive: in principle a tree-sitter node's `.text` span
        # shouldn't include outer whitespace, but stripping avoids edge cases
        # where leading/trailing whitespace would break our delimiter detection.
        token_tree_txt = _node_text(token_tree_node, strip=True)
        if len(token_tree_txt) < 2:
            continue

        opening = token_tree_txt[0]
        closing = token_tree_txt[-1]
        matching = {"{": "}", "(": ")", "[": "]"}
        inner_txt = token_tree_txt
        if opening in matching and matching[opening] == closing:
            inner_txt = token_tree_txt[1:-1]

        try:
            inner_tree = tree_sitter_related.fetch_verus_tree(inner_txt)
        except Exception:
            # If the inner snippet fails to parse, don't fail the whole extraction.
            # Downstream checkers will surface missing functions as errors.
            continue

        inner_function_nodes = tree_sitter_related.fetch_type_nodes(inner_tree.root_node, ["function_item"])
        for fn_node in inner_function_nodes:
            fn_details = fetch_function_details(fn_node)
            fn_name = fn_details["fn_name"]
            if not fn_name:
                continue
            if fn_name in fn_name_to_details_mapping:
                logger.warning(f"Duplicate function definition detected for `{fn_name}`.")
                continue
            fn_name_to_details_mapping[fn_name] = fn_details
    
    logger.debug(f"Found {len(fn_name_to_details_mapping)} functions: {list(fn_name_to_details_mapping.keys())}")

    return fn_name_to_details_mapping


if __name__ == "__main__":
    # curr_dir
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    path_to_package_root = os.path.join(curr_dir, '..', '..')
    print(f"path_to_package_root: {path_to_package_root}")
    path_to_sample_program = os.path.abspath(os.path.join(path_to_package_root, 'verus_program_artifacts', '00_sample_program.rs'))
    print(f"path_to_sample_program: {path_to_sample_program}")
    with open(path_to_sample_program, 'r') as f:
        sample_program = f.read()
    parser = tree_sitter_related.fetch_verus_parser()
    tree = tree_sitter_related.fetch_tree(parser, sample_program)
    root_node = tree.root_node
    function_nodes = fetch_all_function_nodes(root_node)
    for fn_name, fn_details in function_nodes.items():
        logger.info("\n" + "="*30)
        logger.info(f"Function Name: {fn_name}")
        logger.info("Function Details:")
        # Create a copy without the 'node' field for JSON serialization
        loggable_details = {k: v for k, v in fn_details.items() if k != "node"}
        logger.info(json.dumps(loggable_details, indent=2))
        logger.info("="*30)
