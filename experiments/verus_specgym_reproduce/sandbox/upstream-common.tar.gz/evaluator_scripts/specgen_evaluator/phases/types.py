from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field, computed_field


class ValidationSyntaxChecksFeedback(BaseModel):
    """TODO: Explain this in broader context"""
    solve_rs_submitted_path: Path
    solve_rs_submitted_content: str
    syntax_error_msgs: list[str] = Field(default_factory=list)
    # LATER: include machine tags / structured error mapping.

    @computed_field(return_type=bool)
    @property
    def has_passed_syntax_checks(self) -> bool:
        return len(self.syntax_error_msgs) == 0

    def to_natural_language_feedback(self) -> str:
        if self.has_passed_syntax_checks:
            raise ValueError(
                "to_natural_language_feedback() should be called only when syntax checks fail."
            )
        header = (
            "We expected some syntactical requirements in the code "
            f"(path: {self.solve_rs_submitted_path}) which were NOT satisfied. There are below:"
        )
        lines = [f"- {msg}" for msg in self.syntax_error_msgs]
        return "\n".join([header, *lines])


class CanonicalizedSubmission(BaseModel):
    solve_rs_submitted_path: Path
    solve_rs_post_canonical_content: str
    # LATER: include source/target wrapper replacement audit.
    ...


class DerivedFiles(BaseModel):
    check_pre_spec_completeness_content: str
    check_pre_spec_soundness_content: str
    check_post_spec_completeness_content: str
    check_post_spec_soundness_content: str
    pre_exec_spec_complete_content: str
    pre_exec_spec_sound_content: str
    post_exec_spec_complete_content: str
    post_exec_spec_sound_content: str

    @property
    def files_by_stem(self) -> dict[str, str]:
        return {
            "check_pre_spec_completeness": self.check_pre_spec_completeness_content,
            "check_pre_spec_soundness": self.check_pre_spec_soundness_content,
            "check_post_spec_completeness": self.check_post_spec_completeness_content,
            "check_post_spec_soundness": self.check_post_spec_soundness_content,
            "pre_exec_spec_complete": self.pre_exec_spec_complete_content,
            "pre_exec_spec_sound": self.pre_exec_spec_sound_content,
            "post_exec_spec_complete": self.post_exec_spec_complete_content,
            "post_exec_spec_sound": self.post_exec_spec_sound_content,
        }
