from __future__ import annotations

from pathlib import Path

from verus_gym_evals.specgen_evaluator.copied_from_verus_gym.proj_utils.tree_sitter_utils.tree_sitter_related import (
    fetch_verus_tree,
)
from verus_gym_evals.specgen_evaluator.copied_from_verus_gym.proj_utils.tree_sitter_utils.utils import (
    fetch_all_function_nodes,
)
from verus_gym_evals.specgen_evaluator.phases.types import (
    CanonicalizedSubmission,
    ValidationSyntaxChecksFeedback,
)

# ┌──────────────────────────────────────────────┐                   │
#   │  │ 3d. ANTI-REWARD-HACKING: Overwrite check_*   │                   │
#   │  │     bodies from canonical template            │                  │
#   │  │     (Phase 4, line ~1946)                     │                  │
#   │  │                                               │                  │
#   │  │  For each canonical wrapper:                  │                  │
#   │  │    check_pre_spec_soundness                   │                  │
#   │  │    check_pre_spec_completeness                │                  │
#   │  │    check_post_spec_soundness (if full)        │                  │
#   │  │    check_post_spec_completeness (if full)     │                  │
#   │  │    main_exec_pre_spec_check                   │                  │
#   │  │    main_exec_post_spec_check (if full)        │                  │
#   │  │                                               │                  │
#   │  │  Replace agent's function body with           │                  │
#   │  │  template's fn_entire_body via tree-sitter    │                  │
#   │  │  → Prevents agent from tampering with         │                  │
#   │  │    assertion logic                            │                  │
#   │  └──────────────────┬───────────────────────────┘                   │
#   │                     ▼                                  

_CANONICAL_WRAPPER_FUNCTIONS: tuple[str, ...] = (
    "check_pre_spec_soundness",
    "check_pre_spec_completeness",
    "check_post_spec_soundness",
    "check_post_spec_completeness",
    "main_exec_pre_spec_check",
    "main_exec_post_spec_check",
)
# NOTE: Mimicked from wrapper-overwrite logic in:
# /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/revised_task_runner.py
# around evaluate_submission_specgen(), Phase 4 (roughly lines 1946-1990).



class CanonicalizePhase:
    """
    CanonicalizePhase.run(...)
      Input: validated submission
      Output: canonicalized solve.rs with harness-owned wrappers restored
    """

    def run(
        self,
        *,
        validated_submission: ValidationSyntaxChecksFeedback,
        canonicalization_template_solve_rs_path: Path,
    ) -> CanonicalizedSubmission:
        if not validated_submission.has_passed_syntax_checks:
            raise ValueError("CanonicalizePhase expects syntax-validated submission.")

        # we are making sure that the file which has the bodies which we will forcefully impose on the current submission, is present!
        if not canonicalization_template_solve_rs_path.exists() or not canonicalization_template_solve_rs_path.is_file():
            raise FileNotFoundError(f"canonical template solve.rs not found: {canonicalization_template_solve_rs_path}")

        template_content = canonicalization_template_solve_rs_path.read_text(encoding="utf-8")
        template_fn_map = fetch_all_function_nodes(fetch_verus_tree(template_content).root_node)
        submitted_fn_map = fetch_all_function_nodes(
            fetch_verus_tree(validated_submission.solve_rs_submitted_content).root_node
        )

        # Mimicked behavior: replace harness-owned wrapper function definitions
        # in submission with canonical template definitions.
        # Source of behavior:
        # /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/revised_task_runner.py
        # around canonical_fn_names loop (roughly lines 1964-1989).
        updated_solve_code = validated_submission.solve_rs_submitted_content
        for fn_name in _CANONICAL_WRAPPER_FUNCTIONS:
            assert fn_name in template_fn_map
            assert fn_name in submitted_fn_map

            submitted_body = submitted_fn_map[fn_name]["fn_entire_body"]
            template_body = template_fn_map[fn_name]["fn_entire_body"]
            if updated_solve_code.count(submitted_body) != 1:
                raise ValueError(
                    f"Expected a unique `{fn_name}` definition in submitted solve.rs for replacement."
                )
            updated_solve_code = updated_solve_code.replace(submitted_body, template_body, 1)

        return CanonicalizedSubmission(
            solve_rs_submitted_path=validated_submission.solve_rs_submitted_path,
            solve_rs_post_canonical_content=updated_solve_code,
        )
