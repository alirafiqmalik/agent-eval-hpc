from __future__ import annotations

from pathlib import Path

from verus_gym_evals.specgen_evaluator.copied_from_verus_gym.reward_server.specgen_syntax_facade import (
    FULL_MODE_REQUIRED_FUNCTIONS as _FULL_MODE_REQUIRED_FUNCTIONS_FROM_COPIED,
    validate_required_functions,
)
from verus_gym_evals.specgen_evaluator.phases.types import ValidationSyntaxChecksFeedback



# ┌──────────────────────────────────────────────┐                   │
#   │  │ 3c. AST/SYNTAX CHECKS on submitted solve.rs  │                   │
#   │  │     (Phase 3, line ~1854)                     │                  │
#   │  │                                               │                  │
#   │  │  Parse via tree-sitter (SyntaxChecker)        │                  │
#   │  │                                               │                  │
#   │  │  PRE_ONLY required functions:                 │                  │
#   │  │  ✓ pre_spec                                   │                  │
#   │  │  ✓ pre_spec_soundness_proof                   │                  │
#   │  │  ✓ pre_spec_completeness_proof                │                  │
#   │  │  ✓ check_pre_spec_soundness                   │                  │
#   │  │  ✓ check_pre_spec_completeness                │                  │
#   │  │  ✓ main_exec_pre_spec_check                   │                  │
#   │  │  ✓ main                                       │                  │
#   │  │                                               │                  │
#   │  │  FULL MODE adds:                              │                  │
#   │  │  ✓ post_spec                                  │                  │
#   │  │  ✓ post_spec_soundness_proof                  │                  │
#   │  │  ✓ post_spec_completeness_proof               │                  │
#   │  │  ✓ check_post_spec_soundness                  │                  │
#   │  │  ✓ check_post_spec_completeness               │                  │
#   │  │  ✓ main_exec_post_spec_check                  │                  │
#   │  │                                               │                  │
#   │  │  If any missing → bail with error message     │                  │
#   │  └──────────────────┬───────────────────────────┘  

# NOTE: Required function list adapted from:
# /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/revised_task_runner.py
# around evaluate_submission_specgen() required_fn_list construction
# (roughly lines 1863-1889 in current checkout).
FULL_MODE_REQUIRED_FUNCTIONS: list[str] = list(_FULL_MODE_REQUIRED_FUNCTIONS_FROM_COPIED)


class ValidateSubmissionPhase:
    """
    ValidateSubmissionPhase.run(...)
      Input: submitted solve.rs
      Output: ValidationSyntaxChecksFeedback
    """

    def run(self, solve_rs_submitted_path: Path) -> ValidationSyntaxChecksFeedback:
        if not solve_rs_submitted_path.exists() or not solve_rs_submitted_path.is_file():
            # Actually, this is NOT expected to happen in the current code, since we run this only after we have validated that a solve.rs and have then copied it to evaluation results folder.
            # so, this branch should never be hit, but let's still keep it
            raise ValueError(f"[WE DID NOT EXPECT TO REACH THIS BRANCH] Solve.rs submitted path does not exist or is not a file: {solve_rs_submitted_path}")
            return ValidationSyntaxChecksFeedback(
                solve_rs_submitted_path=solve_rs_submitted_path.resolve(),
                solve_rs_submitted_content="",
                syntax_error_msgs=[
                    f"Submitted solve.rs path does not exist or is not a file: {solve_rs_submitted_path}"
                ],
            )

        try:
            solve_rs_submitted_content = solve_rs_submitted_path.read_text(encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            return ValidationSyntaxChecksFeedback(
                solve_rs_submitted_path=solve_rs_submitted_path.resolve(),
                solve_rs_submitted_content="",
                syntax_error_msgs=[f"Failed to read submitted solve.rs: {exc}"],
            )

        diagnostics = validate_required_functions(
            solve_rs_submitted_content,
            required_function_names=tuple(FULL_MODE_REQUIRED_FUNCTIONS),
        )
        return ValidationSyntaxChecksFeedback(
            solve_rs_submitted_path=solve_rs_submitted_path.resolve(),
            solve_rs_submitted_content=solve_rs_submitted_content,
            syntax_error_msgs=diagnostics,
        )
