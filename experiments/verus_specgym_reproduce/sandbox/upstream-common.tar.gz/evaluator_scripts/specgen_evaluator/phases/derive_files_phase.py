from __future__ import annotations

from verus_gym_evals.specgen_evaluator.copied_from_verus_gym.reward_server.syntax_checks import (
    get_specgen_check_files,
)
from verus_gym_evals.specgen_evaluator.phases.types import (
    CanonicalizedSubmission,
    DerivedFiles,
)

#   ┌──────────────────────────────────────────────┐                   │
#   │  │ 3e. Build derived check_*.rs files            │                   │
#   │  │     syntax_checks.get_specgen_check_files()   │                  │
#   │  │     (syntax_checks.py:1105)                   │                  │
#   │  │     (Phase 5, line ~1992)                     │                  │
#   │  │                                               │                  │
#   │  │  For each bucket, build a .rs file keeping:   │                  │
#   │  │   - Relevant spec fn (pre_spec / post_spec)   │                  │
#   │  │   - Relevant proof helper                     │                  │
#   │  │   - Relevant check_* wrapper                  │                  │
#   │  │   - ALL model-added helper functions          │                  │
#   │  │  Drop bodies of all other functions           │                  │
#   │  │                                               │                  │
#   │  │  Also strips ALL #[...] attributes (AST-based)│                  │
#   │  │  → Anti-reward-hacking: prevents model from   │                  │
#   │  │    attaching #[verifier::external_body]       │                  │
#   │  │                                               │                  │
#   │  │  Also builds exec_spec runtime fallback files:│                  │
#   │  │    pre_exec_spec_complete.rs                  │                  │
#   │  │    pre_exec_spec_sound.rs                     │                  │
#   │  │    post_exec_spec_complete.rs (if full)       │                  │
#   │  │    post_exec_spec_sound.rs (if full)          │   

class DeriveFilesPhase:
    """
    DeriveFilesPhase.run(...)
      Input: canonicalized solve.rs
      Output: DerivedFiles map
    """

    def run(
        self,
        *,
        canonicalized_submission: CanonicalizedSubmission,
    ) -> DerivedFiles:
        # NOTE: This phase intentionally mirrors old pipeline behavior by reusing:
        # /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/reward_server/syntax_checks.py
        # get_specgen_check_files(...) (~line 1105), which handles:
        # - selective function retention per bucket
        # - AST-based stripping of #[...] attributes
        # - runtime exec_spec fallback files
        # and the invocation pattern from:
        # /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/revised_task_runner.py
        # Phase 5 (~lines 1992-2003).
        derived_by_stem = get_specgen_check_files(
            solve_code_content=canonicalized_submission.solve_rs_post_canonical_content,
            pre_only=False,  # user requirement: full mode only
        )

        return DerivedFiles(
            check_pre_spec_completeness_content=derived_by_stem["check_pre_spec_completeness"],
            check_pre_spec_soundness_content=derived_by_stem["check_pre_spec_soundness"],
            check_post_spec_completeness_content=derived_by_stem["check_post_spec_completeness"],
            check_post_spec_soundness_content=derived_by_stem["check_post_spec_soundness"],
            pre_exec_spec_complete_content=derived_by_stem["pre_exec_spec_complete"],
            pre_exec_spec_sound_content=derived_by_stem["pre_exec_spec_sound"],
            post_exec_spec_complete_content=derived_by_stem["post_exec_spec_complete"],
            post_exec_spec_sound_content=derived_by_stem["post_exec_spec_sound"],
        )
