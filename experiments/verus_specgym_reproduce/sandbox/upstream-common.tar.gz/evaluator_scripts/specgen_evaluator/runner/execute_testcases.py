# ┌──────────────────────────────────────────────────────────────┐   │
#   │  │ 4c. Per-testcase evaluation (ProcessSpecgenTestcase)          │   │
#   │  │     (evaluate_specgen.py:362)                                │   │
#   │  │                                                              │   │
#   │  │  ┌────────────────────────────────────────────┐              │   │
#   │  │  │ _evaluate_pre_spec() (line 619)            │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ 1. Load out.input_defn snippet             │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ 2. Read check_pre_spec_completeness.rs and │              │   │
#   │  │  │    check_pre_spec_soundness.rs templates   │              │   │
#   │  │  │    from DEV_DIR                            │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ 3. Inject input_defn under                 │              │   │
#   │  │  │    // __PASTE_out.input_defn__             │              │   │
#   │  │  │    in both templates                       │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ 4. Run Verus on BOTH:                      │              │   │
#   │  │  │    completeness: assert(pre_spec(input))   │              │   │
#   │  │  │    soundness:    assert(!pre_spec(input))  │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ 5. Interpret results:                      │              │   │
#   │  │  │    ┌──────────┬───────────┬─────────────┐  │              │   │
#   │  │  │    │ assert() │ !assert() │ Meaning     │  │              │   │
#   │  │  │    ├──────────┼───────────┼─────────────┤  │              │   │
#   │  │  │    │ ✓ pass   │ ✗ fail    │ clause=TRUE │  │              │   │
#   │  │  │    │ ✗ fail   │ ✓ pass    │ clause=FALSE│  │              │   │
#   │  │  │    │ ✓ pass   │ ✓ pass    │ IMPOSSIBLE  │  │              │   │
#   │  │  │    │          │           │ →RuntimeErr │  │              │   │
#   │  │  │    │ ✗ fail   │ ✗ fail    │ INTRACTABLE │  │              │   │
#   │  │  │    │          │           │ →exec_spec  │  │              │   │
#   │  │  │    │          │           │   fallback  │  │              │   │
#   │  │  │    └──────────┴───────────┴─────────────┘  │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ 6. Compare against expected:               │              │   │
#   │  │  │    pre_complete → expected TRUE             │              │   │
#   │  │  │    pre_sound    → expected FALSE            │              │   │
#   │  │  │    post_* cat   → no pre_spec expectation  │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ 7. If INTRACTABLE & assertion-style failure│              │   │
#   │  │  │    (not type/VIR error):                   │              │   │
#   │  │  │    → _exec_spec_fallback_pre() (line 471)  │              │   │
#   │  │  │    → Compile+run pre_exec_spec_complete.rs │              │   │
#   │  │  │      and pre_exec_spec_sound.rs            │              │   │
#   │  │  │    → Use exit_code to determine truth      │              │   │
#   │  │  │    → If both fail: still intractable       │              │   │
#   │  │  └────────────────────────────────────────────┘              │   │
#   │  │                       │                                      │   │
#   │  │                       ▼                                      │   │
#   │  │  ┌────────────────────────────────────────────┐              │   │
#   │  │  │ _evaluate_post_spec() (line 802)           │              │   │
#   │  │  │ (SKIPPED if PRE_ONLY or pre_* category)    │              │   │
#   │  │  │                                            │              │   │
#   │  │  │ Same structure as pre_spec, but:           │              │   │
#   │  │  │ 1. Load out.input_defn + out.gt_output_defn│              │   │
#   │  │  │ 2. Inject BOTH into templates              │              │   │
#   │  │  │ 3. Run check_post_spec_{completeness,      │              │   │
#   │  │  │    soundness}.rs through Verus             │              │   │
#   │  │  │ 4. Same interpret/fallback logic           │              │   │
#   │  │  │    post_complete → expected TRUE            │              │   │
#   │  │  │    post_sound    → expected FALSE           │              │   │
#   │  │  └────────────────────────────────────────────┘              │   │
#   │  │                       │                                      │   │
#   │  │                       ▼                                      │   │
#   │  │  Return OfficialTestVerdict with:                            │   │
#   │  │    has_passed_pre_spec: bool                                 │   │
#   │  │    has_passed_post_spec: bool                                │   │
#   │  │    has_passed_exec_pre_spec: bool | None                     │   │
#   │  │    has_passed_exec_post_spec: bool | None                    │   │
#   │  │    error_message_mapping: dict                               │   │
#   │  └──────────────────────────────────────────────────────────────┘ 

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from verus_gym_evals.specgen_evaluator.models.initial_args import EvaluationLogsTree
from verus_gym_evals.specgen_evaluator.models.tc_representation import TestcaseRepresentation
from verus_gym_evals.specgen_evaluator.models.testcase_execution_models import (
    RuntimeArtifactVerdict,
    SymbolicArtifactVerdict,
    TestcaseEvaluation,
    TestcaseTruthVerdict,
)
from verus_gym_evals.specgen_evaluator.runner.verus_exec_utils import (
    get_verus_execution_verdict,
    get_verus_verification_verdict,
)


@dataclass(frozen=True)
class _TemplatePathsForCategory:
    symbolic_completeness_template_path: Path
    symbolic_soundness_template_path: Path
    execution_completeness_template_path: Path
    execution_soundness_template_path: Path


@dataclass(frozen=True)
class MaterializedTestcaseFiles:
    symbolic_completeness_path: Path
    symbolic_soundness_path: Path
    execution_completeness_path: Path
    execution_soundness_path: Path


def _read_file(path: Path) -> str:
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"Expected file does not exist: {path}")
    return path.read_text(encoding="utf-8")


def _inject_snippet_once(code: str, marker: str, snippet: str) -> str:
    # Marker placement should be deterministic; enforce exactly one marker occurrence.
    if marker not in code:
        raise ValueError(f"Marker `{marker}` not found while materializing testcase file.")
    if code.count(marker) != 1:
        raise ValueError(f"Marker `{marker}` appears multiple times; expected exactly one.")
    snippet_body = snippet.strip("\n")
    if snippet_body == "":
        return code
    replacement = f"{marker}\n{snippet_body}"
    return code.replace(marker, replacement, 1)


def _expected_verdict_from_category(category: str) -> TestcaseTruthVerdict:
    if category in {"pre_sound", "post_sound"}:
        return TestcaseTruthVerdict.SOUND
    if category in {"pre_complete", "post_complete"}:
        return TestcaseTruthVerdict.COMPLETE
    raise ValueError(f"Unknown testcase category: {category}")


def _template_paths_for_category(
    *,
    evaluation_logs_tree: EvaluationLogsTree,
    category: str,
) -> _TemplatePathsForCategory:
    # PRE buckets use pre_* derived files; POST buckets use post_* derived files.
    if category.startswith("pre_"):
        return _TemplatePathsForCategory(
            symbolic_completeness_template_path=evaluation_logs_tree.derived_check_pre_spec_completeness_path,
            symbolic_soundness_template_path=evaluation_logs_tree.derived_check_pre_spec_soundness_path,
            execution_completeness_template_path=evaluation_logs_tree.derived_pre_exec_spec_complete_path,
            execution_soundness_template_path=evaluation_logs_tree.derived_pre_exec_spec_sound_path,
        )
    if category.startswith("post_"):
        return _TemplatePathsForCategory(
            symbolic_completeness_template_path=evaluation_logs_tree.derived_check_post_spec_completeness_path,
            symbolic_soundness_template_path=evaluation_logs_tree.derived_check_post_spec_soundness_path,
            execution_completeness_template_path=evaluation_logs_tree.derived_post_exec_spec_complete_path,
            execution_soundness_template_path=evaluation_logs_tree.derived_post_exec_spec_sound_path,
        )
    raise ValueError(f"Unknown testcase category: {category}")


class TestCaseRunner:
    """
    Evaluate a single testcase using derived templates and snippet injection.

    This is intentionally kept close to the old evaluate_specgen.py behavior,
    but returns the new TestcaseEvaluation model.
    """

    def __init__(self, testcase_rep: TestcaseRepresentation, testcase_directory: Path):
        self.testcase_rep = testcase_rep
        testcase_directory.mkdir(parents=True, exist_ok=True)
        assert testcase_directory.is_dir() and testcase_directory.exists()
        self.testcase_directory = testcase_directory

    def materialize_derived_files(
        self,
        *,
        evaluation_logs_tree: EvaluationLogsTree,
    ) -> MaterializedTestcaseFiles:
        # copy the derived files to the testcase directory after substituing the markers
        # assert relevent markers exist, and then replace them!
        template_paths = _template_paths_for_category(
            evaluation_logs_tree=evaluation_logs_tree,
            category=self.testcase_rep.category,
        )

        # Read all 4 templates (2 symbolic + 2 runtime).
        symbolic_completeness_code = _read_file(template_paths.symbolic_completeness_template_path)
        symbolic_soundness_code = _read_file(template_paths.symbolic_soundness_template_path)
        execution_completeness_code = _read_file(template_paths.execution_completeness_template_path)
        execution_soundness_code = _read_file(template_paths.execution_soundness_template_path)

        # Input definition is required in every derived testcase file.
        symbolic_completeness_code = _inject_snippet_once(
            symbolic_completeness_code, "// __PASTE_out.input_defn__", self.testcase_rep.input_defn
        )
        symbolic_soundness_code = _inject_snippet_once(
            symbolic_soundness_code, "// __PASTE_out.input_defn__", self.testcase_rep.input_defn
        )
        execution_completeness_code = _inject_snippet_once(
            execution_completeness_code, "// __PASTE_out.input_defn__", self.testcase_rep.input_defn
        )
        execution_soundness_code = _inject_snippet_once(
            execution_soundness_code, "// __PASTE_out.input_defn__", self.testcase_rep.input_defn
        )

        # Post categories also need ground-truth output snippet.
        if self.testcase_rep.category.startswith("post_"):
            assert self.testcase_rep.gt_output_defn is not None
            symbolic_completeness_code = _inject_snippet_once(
                symbolic_completeness_code,
                "// __PASTE_out.gt_output_defn__",
                self.testcase_rep.gt_output_defn,
            )
            symbolic_soundness_code = _inject_snippet_once(
                symbolic_soundness_code,
                "// __PASTE_out.gt_output_defn__",
                self.testcase_rep.gt_output_defn,
            )
            execution_completeness_code = _inject_snippet_once(
                execution_completeness_code,
                "// __PASTE_out.gt_output_defn__",
                self.testcase_rep.gt_output_defn,
            )
            execution_soundness_code = _inject_snippet_once(
                execution_soundness_code,
                "// __PASTE_out.gt_output_defn__",
                self.testcase_rep.gt_output_defn,
            )

        # Write materialized files into testcase-local directory.
        symbolic_completeness_path = self.testcase_directory / "symbolic_completeness.rs"
        symbolic_soundness_path = self.testcase_directory / "symbolic_soundness.rs"
        execution_completeness_path = self.testcase_directory / "execution_completeness.rs"
        execution_soundness_path = self.testcase_directory / "execution_soundness.rs"

        symbolic_completeness_path.write_text(symbolic_completeness_code, encoding="utf-8")
        symbolic_soundness_path.write_text(symbolic_soundness_code, encoding="utf-8")
        execution_completeness_path.write_text(execution_completeness_code, encoding="utf-8")
        execution_soundness_path.write_text(execution_soundness_code, encoding="utf-8")

        return MaterializedTestcaseFiles(
            symbolic_completeness_path=symbolic_completeness_path,
            symbolic_soundness_path=symbolic_soundness_path,
            execution_completeness_path=execution_completeness_path,
            execution_soundness_path=execution_soundness_path,
        )

    def evaluate(
        self,
        *,
        evaluation_logs_tree: EvaluationLogsTree,
        persist_results: bool = True,
    ) -> TestcaseEvaluation:
        # run symbolically
        materialized_files = self.materialize_derived_files(
            evaluation_logs_tree=evaluation_logs_tree
        )

        # Run completeness and soundness symbolic checks.
        symbolic_completeness_verification = get_verus_verification_verdict(
            materialized_files.symbolic_completeness_path,
            persist_results=persist_results,
        )
        symbolic_soundness_verification = get_verus_verification_verdict(
            materialized_files.symbolic_soundness_path,
            persist_results=persist_results,
        )

        symbolic_completeness = SymbolicArtifactVerdict(
            path_to_code=str(materialized_files.symbolic_completeness_path),
            verification_verdict=symbolic_completeness_verification,
        )
        symbolic_soundness = SymbolicArtifactVerdict(
            path_to_code=str(materialized_files.symbolic_soundness_path),
            verification_verdict=symbolic_soundness_verification,
        )

        testcase_eval = TestcaseEvaluation(
            testcase_representation=self.testcase_rep,
            expected_verdict=_expected_verdict_from_category(self.testcase_rep.category),
            symbolic_soundness_verdict=symbolic_soundness,
            symbolic_completeness_verdict=symbolic_completeness,
            execution_soundness_verdict=None,
            execution_completeness_verdict=None,
        )

        # see if symbolic verdicts are tracable,if yes, then return!
        if testcase_eval.symbolic_verdict != TestcaseTruthVerdict.INDETERMINATE:
            return testcase_eval

        # if not, then run executionally!
        execution_completeness_compile, execution_completeness_run = get_verus_execution_verdict(
            materialized_files.execution_completeness_path,
            persist_results=persist_results,
        )
        execution_soundness_compile, execution_soundness_run = get_verus_execution_verdict(
            materialized_files.execution_soundness_path,
            persist_results=persist_results,
        )

        execution_completeness = RuntimeArtifactVerdict(
            path_to_code=str(materialized_files.execution_completeness_path),
            compile_verdict=execution_completeness_compile,
            path_to_compiled_binary=(
                str(execution_completeness_compile.path_to_binary)
                if execution_completeness_compile.path_to_binary is not None
                else None
            ),
            execution_verdict=execution_completeness_run,
        )
        execution_soundness = RuntimeArtifactVerdict(
            path_to_code=str(materialized_files.execution_soundness_path),
            compile_verdict=execution_soundness_compile,
            path_to_compiled_binary=(
                str(execution_soundness_compile.path_to_binary)
                if execution_soundness_compile.path_to_binary is not None
                else None
            ),
            execution_verdict=execution_soundness_run,
        )

        # return the testcase evaluation!
        return testcase_eval.model_copy(
            update={
                "execution_soundness_verdict": execution_soundness,
                "execution_completeness_verdict": execution_completeness,
            }
        )
