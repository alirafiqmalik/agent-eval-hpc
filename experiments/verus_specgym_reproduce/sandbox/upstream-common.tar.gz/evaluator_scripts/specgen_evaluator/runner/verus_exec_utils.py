from __future__ import annotations

"""Local-only Verus compile/verify/execute helpers for specgen evaluation.

This module is intentionally container/backend agnostic at the API surface, but
currently supports only local subprocess execution (no HTTP server mode).

The public helpers return structured verdict models and optionally persist
artifacts adjacent to the input `.rs` file.
"""

import json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from verus_gym_evals.specgen_evaluator.models.testcase_execution_models import (
    VerusCompileVerdict,
    VerusExecutionVerdict,
    VerusVerificationVerdict,
)

# Copied/influenced from:
# - /Users/anmolagarwal/Desktop/anmol_oct/verus_gym/src/verus_gym/harness/evaluator_scripts/eval_models.py
#   local execution helpers:
#   * compile_rust_file_with_verus
#   * run_verus_verification
#   * verus_compile_and_run_file
#   * run_precompiled_rust_binary
#
# Intentionally local-only (no server backend support in this library module).


def _read_positive_int_from_env(env_var_name: str, default_value: int) -> int:
    """Read a positive integer timeout from env, with fallback default."""

    raw_value = os.environ.get(env_var_name)
    if raw_value is None:
        return default_value

    parsed_value = int(raw_value)
    if parsed_value <= 0:
        raise ValueError(f"{env_var_name} must be a positive integer, got: {raw_value}")
    return parsed_value


@dataclass(frozen=True)
class LocalVerusExecConfig:
    """Execution config for local Verus subprocess invocations."""

    # Timeout knobs are centralized here so they are easy to tune and monitor.
    # Environment overrides:
    # - SPECGEN_EVAL_VERUS_COMPILE_TIMEOUT_SECONDS
    # - SPECGEN_EVAL_VERUS_VERIFY_TIMEOUT_SECONDS
    # - SPECGEN_EVAL_VERUS_RUN_TIMEOUT_SECONDS
    rust_compile_timeout_seconds: int = _read_positive_int_from_env(
        "SPECGEN_EVAL_VERUS_COMPILE_TIMEOUT_SECONDS", 60
    )
    verus_verify_timeout_seconds: int = _read_positive_int_from_env(
        "SPECGEN_EVAL_VERUS_VERIFY_TIMEOUT_SECONDS", 180
    )
    rust_run_timeout_seconds: int = _read_positive_int_from_env(
        "SPECGEN_EVAL_VERUS_RUN_TIMEOUT_SECONDS", 60
    )
    verus_binary: str = os.environ.get("VERUS_BINARY") or shutil.which("verus") or "verus"


LOCAL_VERUS_EXEC_CONFIG = LocalVerusExecConfig()


def _ensure_rs_exists(path_to_rs_file: Path) -> None:
    """Raise if the given Rust/Verus source path is missing or not a file."""

    if not path_to_rs_file.exists() or not path_to_rs_file.is_file():
        raise FileNotFoundError(f"Rust/Verus file does not exist: {path_to_rs_file}")


def _save_text_if_needed(path: Path, content: str, persist_results: bool) -> Path | None:
    """Persist `content` to `path` only when `persist_results` is true."""

    if not persist_results:
        return None
    path.write_text(content, encoding="utf-8")
    return path


def _decode_or_str(raw: bytes | str | None) -> str:
    """Normalize bytes/str/None subprocess output into a UTF-8 string."""

    if raw is None:
        return ""
    if isinstance(raw, bytes):
        return raw.decode("utf-8", errors="replace")
    return raw


def get_verus_compile_verdict(
    path_to_rs_file: Path,
    *,
    persist_results: bool,
) -> VerusCompileVerdict:
    """Compile a `.rs` file with `verus --compile` and return compile verdict.

    When `persist_results=True`, writes:
    - `<stem>.compile.stdout`
    - `<stem>.compile.stderr`
    and exposes these paths in the verdict.
    """

    _ensure_rs_exists(path_to_rs_file)

    compiled_binary_path = path_to_rs_file.with_suffix("")
    compile_cmd = [
        LOCAL_VERUS_EXEC_CONFIG.verus_binary,
        "--compile",
        str(path_to_rs_file),
    ]
    started_at = time.monotonic()
    try:
        proc = subprocess.run(
            compile_cmd,
            capture_output=True,
            text=True,
            cwd=str(path_to_rs_file.parent),
            timeout=LOCAL_VERUS_EXEC_CONFIG.rust_compile_timeout_seconds,
        )
        compile_stdout = proc.stdout or ""
        compile_stderr = proc.stderr or ""
        compile_exit_code = proc.returncode
    except subprocess.TimeoutExpired as exc:
        compile_stdout = _decode_or_str(exc.stdout)
        compile_stderr = _decode_or_str(exc.stderr) + (
            f"\nProcess exceeded {LOCAL_VERUS_EXEC_CONFIG.rust_compile_timeout_seconds} seconds and was terminated."
        )
        compile_exit_code = -1
    time_elapsed = time.monotonic() - started_at

    compile_stdout_path = path_to_rs_file.with_suffix(".compile.stdout")
    compile_stderr_path = path_to_rs_file.with_suffix(".compile.stderr")

    saved_stdout = _save_text_if_needed(compile_stdout_path, compile_stdout, persist_results)
    saved_stderr = _save_text_if_needed(compile_stderr_path, compile_stderr, persist_results)

    return VerusCompileVerdict(
        exit_code=compile_exit_code,
        time_elapsed=time_elapsed,
        stdout=compile_stdout,
        stderr=compile_stderr,
        compile_command=" ".join(compile_cmd),
        path_to_stdout=saved_stdout,
        path_to_stderr=saved_stderr,
        path_to_binary=compiled_binary_path if compiled_binary_path.exists() else None,
    )


def get_verus_verification_verdict(
    path_to_rs_file: Path,
    *,
    persist_results: bool,
    max_errors: int = 10,
    rlimit: int | None = None,
) -> VerusVerificationVerdict:
    """Run local Verus verification (`--output-json`) for a source file.

    This uses `--crate-type=lib` because the intent is proof/verification,
    not binary execution.

    When `persist_results=True`, writes:
    - `<stem>.verify.stdout`
    - `<stem>.verify.stderr`
    - `<stem>.verify.output.json` (only if stdout parses as JSON)
    """

    _ensure_rs_exists(path_to_rs_file)

    verify_cmd = [
        LOCAL_VERUS_EXEC_CONFIG.verus_binary,
        str(path_to_rs_file),
        "--compile",
        "--time",
        "--expand-errors",
        "--time-expanded",
        f"--multiple-errors={max_errors}",
        "--output-json",
        "--crate-type=lib",
    ]
    if rlimit is not None:
        verify_cmd.extend(["--rlimit", str(rlimit)])

    started_at = time.monotonic()
    try:
        proc = subprocess.run(
            verify_cmd,
            capture_output=True,
            text=True,
            cwd=str(path_to_rs_file.parent),
            timeout=LOCAL_VERUS_EXEC_CONFIG.verus_verify_timeout_seconds,
        )
        verify_stdout = proc.stdout or ""
        verify_stderr = proc.stderr or ""
        verify_exit_code = proc.returncode
    except subprocess.TimeoutExpired as exc:
        verify_stdout = _decode_or_str(exc.stdout)
        verify_stderr = _decode_or_str(exc.stderr) + (
            f"\nProcess exceeded {LOCAL_VERUS_EXEC_CONFIG.verus_verify_timeout_seconds} seconds and was terminated."
        )
        verify_exit_code = -1
    time_elapsed = time.monotonic() - started_at

    parsed_output_json: dict | None = None
    try:
        parsed_output_json = json.loads(verify_stdout)
    except Exception:
        parsed_output_json = None

    verify_stdout_path = path_to_rs_file.with_suffix(".verify.stdout")
    verify_stderr_path = path_to_rs_file.with_suffix(".verify.stderr")
    verify_output_json_path = path_to_rs_file.with_suffix(".verify.output.json")

    saved_stdout = _save_text_if_needed(verify_stdout_path, verify_stdout, persist_results)
    saved_stderr = _save_text_if_needed(verify_stderr_path, verify_stderr, persist_results)
    saved_json: Path | None = None
    if persist_results and parsed_output_json is not None:
        verify_output_json_path.write_text(
            json.dumps(parsed_output_json, indent=2),
            encoding="utf-8",
        )
        saved_json = verify_output_json_path

    return VerusVerificationVerdict(
        exit_code=verify_exit_code,
        time_elapsed=time_elapsed,
        stdout=verify_stdout,
        stderr=verify_stderr,
        output_json=parsed_output_json,
        path_to_stdout=saved_stdout,
        path_to_stderr=saved_stderr,
        path_to_output_json=saved_json,
    )


def get_verus_execution_verdict_from_binary(
    path_to_binary: Path,
    *,
    persist_results: bool,
    extra_run_args: Sequence[str] | None = None,
) -> VerusExecutionVerdict:
    """Execute an already-compiled binary and return runtime verdict.

    When `persist_results=True`, writes:
    - `<binary>.run.stdout`
    - `<binary>.run.stderr`
    """

    if not path_to_binary.exists() or not path_to_binary.is_file():
        raise FileNotFoundError(f"Compiled binary does not exist: {path_to_binary}")

    run_cmd = [str(path_to_binary)]
    if extra_run_args:
        run_cmd.extend(list(extra_run_args))

    started_at = time.monotonic()
    try:
        proc = subprocess.run(
            run_cmd,
            capture_output=True,
            text=True,
            cwd=str(path_to_binary.parent),
            timeout=LOCAL_VERUS_EXEC_CONFIG.rust_run_timeout_seconds,
        )
        run_stdout = proc.stdout or ""
        run_stderr = proc.stderr or ""
        run_exit_code = proc.returncode
    except subprocess.TimeoutExpired as exc:
        run_stdout = _decode_or_str(exc.stdout)
        run_stderr = _decode_or_str(exc.stderr) + (
            f"\nProcess exceeded {LOCAL_VERUS_EXEC_CONFIG.rust_run_timeout_seconds} seconds and was terminated."
        )
        run_exit_code = -1
    time_elapsed = time.monotonic() - started_at

    run_stdout_path = path_to_binary.with_suffix(".run.stdout")
    run_stderr_path = path_to_binary.with_suffix(".run.stderr")

    saved_stdout = _save_text_if_needed(run_stdout_path, run_stdout, persist_results)
    saved_stderr = _save_text_if_needed(run_stderr_path, run_stderr, persist_results)

    return VerusExecutionVerdict(
        exit_code=run_exit_code,
        time_elapsed=time_elapsed,
        stdout=run_stdout,
        stderr=run_stderr,
        run_command=" ".join(run_cmd),
        path_to_stdout=saved_stdout,
        path_to_stderr=saved_stderr,
        path_to_binary=path_to_binary if path_to_binary.exists() else None,
    )


def get_verus_execution_verdict(
    path_to_rs_file: Path,
    *,
    persist_results: bool,
    extra_run_args: Sequence[str] | None = None,
) -> tuple[VerusCompileVerdict, VerusExecutionVerdict]:
    """Compile a source file and then execute the produced binary.

    Returns a pair:
    - compile verdict
    - execution verdict

    If compilation fails (no binary produced), execution verdict is returned in
    a failed placeholder form with `exit_code=-1`.
    """

    compile_verdict = get_verus_compile_verdict(
        path_to_rs_file=path_to_rs_file,
        persist_results=persist_results,
    )
    if compile_verdict.path_to_binary is None:
        return compile_verdict, VerusExecutionVerdict(
            exit_code=-1,
            time_elapsed=0.0,
            stdout="",
            stderr="Compilation failed; binary is unavailable for execution.",
            run_command=None,
            path_to_stdout=None,
            path_to_stderr=None,
            path_to_binary=None,
        )

    run_verdict = get_verus_execution_verdict_from_binary(
        path_to_binary=compile_verdict.path_to_binary,
        persist_results=persist_results,
        extra_run_args=extra_run_args,
    )
    return compile_verdict, run_verdict


__all__ = [
    "LOCAL_VERUS_EXEC_CONFIG",
    "get_verus_compile_verdict",
    "get_verus_verification_verdict",
    "get_verus_execution_verdict",
    "get_verus_execution_verdict_from_binary",
]
