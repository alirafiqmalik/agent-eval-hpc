from __future__ import annotations

import json
from pathlib import Path

from verus_gym_evals.specgen_evaluator.models.tc_representation import (
    AllTestCases,
    Manifest,
    TestcaseRepresentation,
)


def read_and_parse_all_testcases(manifest: Manifest | str, path_to_snippets: Path) -> AllTestCases:
    """This function is to, for each testcase in the different buckets, read the necessary artifacts for that testcase so that we can use that testcase for evaluation!
    
    We also do a sanity check to make sure that judt the right amount of information is present in the snippets directory for each testcase!
    """
    #TODO: fill
    #manifest is either a path or the manifest object itself
    if isinstance(manifest, str):
        manifest_payload = json.loads(Path(manifest).read_text(encoding="utf-8"))
        # NOTE: defaulting to "all" here; caller can pre-build a Manifest with
        # `sample` selection if needed.
        manifest = Manifest.from_json(manifest_payload, sample_or_all="all")
    else:
        manifest = manifest
    manifest: Manifest

    # make sure path to snippets exist
    # list al subdirs in pre_sound
    # make sure that set of subdirs is the same as the set of testcase_ids in manifest.pre_sound_passed_test_ids
    # do same for each bucket!
    snippets_root = Path(path_to_snippets)
    if not snippets_root.is_dir():
        raise FileNotFoundError(f"path_to_snippets does not exist or is not a directory: {snippets_root}")

    category_to_expected_ids = manifest.category_to_test_ids()

    def _read_required_text(path: Path) -> str:
        if not path.is_file():
            raise FileNotFoundError(f"Missing required snippet file: {path}")
        return path.read_text(encoding="utf-8")

    def _read_optional_text(path: Path) -> str | None:
        if not path.is_file():
            return None
        return path.read_text(encoding="utf-8")

    category_to_testcases: dict[str, list[TestcaseRepresentation]] = {}
    for category, expected_ids in category_to_expected_ids.items():
        category_dir = snippets_root / category
        assert category_dir.is_dir()

        # make sure that the exact amount of information is present in the snippets directory ie neither more (since we do not want to allow the model to cheat) nor less (since we need the data for evaluation!)
        actual_ids = sorted([p.name for p in category_dir.iterdir() if p.is_dir()])
        if set(actual_ids) != set(expected_ids):
            raise ValueError(
                f"Category={category} mismatch between manifest ids and snippets dirs. "
                f"expected={sorted(expected_ids)} actual={sorted(actual_ids)}"
            )

        testcases_for_category: list[TestcaseRepresentation] = []
        for testcase_id in expected_ids:
            testcase_dir = category_dir / testcase_id
            input_defn = _read_required_text(testcase_dir / "out.input_defn")
            assert_pre_spec = _read_required_text(testcase_dir / "out.assert_pre_spec")
            pre_spec_print_call = _read_required_text(testcase_dir / "out.pre_spec_print_call")
            testcase_repr = TestcaseRepresentation(
                within_bucket_id=testcase_id,
                category=category,
                input_defn=input_defn,
                assert_pre_spec=assert_pre_spec,
                assert_post_spec_gt=_read_optional_text(testcase_dir / "out.assert_post_spec_gt"),
                pre_spec_print_call=pre_spec_print_call,
                post_spec_print_call=_read_optional_text(testcase_dir / "out.post_spec_print_call"),
                gt_output_defn=_read_optional_text(testcase_dir / "out.gt_output_defn"),
            )
            testcases_for_category.append(testcase_repr)

        category_to_testcases[category] = testcases_for_category

    all_testcases = AllTestCases(
        pre_sound=category_to_testcases["pre_sound"],
        pre_complete=category_to_testcases["pre_complete"],
        post_sound=category_to_testcases["post_sound"],
        post_complete=category_to_testcases["post_complete"],
    )
    return all_testcases
