from __future__ import annotations

import os
import json
import shutil
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Literal

from tqdm import tqdm

from verus_gym_evals.specgen_evaluator.models.feedback import (
    EvaluationFeedback,
    TestSuiteFeedback,
)
from verus_gym_evals.specgen_evaluator.models.initial_args import (
    EvalRequest,
    EvaluationLogsTree,
    ResolvedInputPaths,
)
from verus_gym_evals.specgen_evaluator.models.tc_representation import (
    AllTestCases,
    Manifest,
    TestcaseRepresentation,
)
from verus_gym_evals.specgen_evaluator.models.testcase_execution_models import TestcaseEvaluation
from verus_gym_evals.specgen_evaluator.phases.types import (
    CanonicalizedSubmission,
    DerivedFiles,
    ValidationSyntaxChecksFeedback,
)
from verus_gym_evals.specgen_evaluator.phases.canonicalize_phase import CanonicalizePhase
from verus_gym_evals.specgen_evaluator.phases.derive_files_phase import DeriveFilesPhase
from verus_gym_evals.specgen_evaluator.phases.validate_submission_phase import (
    ValidateSubmissionPhase,
)
from verus_gym_evals.specgen_evaluator.runner.load_testcases import (
    read_and_parse_all_testcases,
)
from verus_gym_evals.specgen_evaluator.runner.execute_testcases import TestCaseRunner




def dump_feedback(
    evaluation_feedback: EvaluationFeedback,
    evaluation_logs_tree: EvaluationLogsTree,
):
    #LATER: Ensure when evereyuthing is correct, feedback says: eveeything is correct, feel free to exit!


    # check if failure was structural or something else

    # dump both structured feedback and natural language feedback to the evaluation logs tree!
    structured_feedback_payload = evaluation_feedback.model_dump(mode="json")
    evaluation_logs_tree.structured_feedback_path.write_text(
        json.dumps(structured_feedback_payload, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    syntax_feedback = evaluation_feedback.syntax_check_feedback
    if not syntax_feedback.has_passed_syntax_checks:
        natural_language_feedback = syntax_feedback.to_natural_language_feedback()
    else:
        execution_feedback = evaluation_feedback.execution_feedback
        # This branch is only reached for syntax-pass runs; in this codepath execution feedback
        # is always populated before dump_feedback() is called.
        assert execution_feedback is not None
        natural_language_feedback = execution_feedback.to_natural_language_feedback()

    staged_copy_note = (
        "The content you submitted has been written to "
        f"{evaluation_feedback.solve_rs_submitted_path}."
    )
    natural_language_feedback = f"{staged_copy_note}\n\n{natural_language_feedback}"

    evaluation_logs_tree.natural_language_feedback_path.write_text(
        natural_language_feedback,
        encoding="utf-8",
    )

    message_to_agent = (
        f"A detailed feedback is available at {evaluation_logs_tree.root_directory}. "
        f"Here is link to much more readable NL feedback: {evaluation_logs_tree.natural_language_feedback_path}. "
        f"Structured feedback can be found at: {evaluation_logs_tree.structured_feedback_path}. "
        "Try to act on the feedback."
    )  # mention evaluation_logs_tree.root_directory, see summary of feedback at evaluation_logs_tree.natural_language_feedback_path and try to act on the feedback
    print(message_to_agent)


def load_manifest(
    path_to_manifest_json: Path,
    *,
    sample_or_all: Literal["sample", "all"],
) -> Manifest:
    # LATER: replace this with the dedicated phase module.
    with open(path_to_manifest_json, "r", encoding="utf-8") as f:
        manifest_payload = json.load(f)
    return Manifest.from_json(manifest_payload, sample_or_all=sample_or_all)


def load_testcases(manifest: Manifest, snippets_dir: Path) -> AllTestCases:
    # LATER: replace this with the dedicated phase module.
    return read_and_parse_all_testcases(manifest, snippets_dir)


def validate_submission_structure(path_to_solve_rs_submitted: Path) -> ValidationSyntaxChecksFeedback:
    # LATER: implement directly via phase modules.
    return ValidateSubmissionPhase().run(solve_rs_submitted_path=path_to_solve_rs_submitted)


def copy_snippets_for_manifest(
    *,
    source_snippets_dir: Path,
    destination_snippets_dir: Path,
    manifest: Manifest,
) -> None:
    # Sanity-check category directories that manifest expects.
    for category in manifest.category_to_test_ids().keys():
        source_category_dir = source_snippets_dir / category
        if not source_category_dir.is_dir():
            raise FileNotFoundError(f"Missing snippets category directory: {source_category_dir}")

    # Copy the whole snippets tree in one shot.
    if destination_snippets_dir.exists():
        shutil.rmtree(destination_snippets_dir)
    shutil.copytree(source_snippets_dir, destination_snippets_dir)


def run_test_suite(
    *,
    all_testcases: AllTestCases,
    evaluation_logs_tree: EvaluationLogsTree,
    persist_results: bool = True,
) -> TestSuiteFeedback:
    def _bucket_max_workers(num_testcases: int) -> int:
        # Allow easy tuning via env var while keeping a safe default.
        env_value = os.environ.get("SPECGEN_EVAL_MAX_WORKERS")
        if env_value is not None:
            parsed = int(env_value)
            if parsed <= 0:
                raise ValueError(
                    f"SPECGEN_EVAL_MAX_WORKERS must be > 0, got: {env_value}"
                )
            return min(parsed, max(1, num_testcases))

        # Default is conservative because each testcase can spawn heavy Verus subprocesses.
        cpu_count = os.cpu_count() or 4
        return min(max(1, min(8, cpu_count)), max(1, num_testcases))

    def _run_bucket(
        bucket_name: str,
        testcases: list[TestcaseRepresentation],
    ) -> dict[str, TestcaseEvaluation]:
        bucket_results: dict[str, TestcaseEvaluation] = {}

        if len(testcases) == 0:
            return bucket_results

        max_workers = _bucket_max_workers(len(testcases))

        def _run_one(testcase: TestcaseRepresentation) -> tuple[str, TestcaseEvaluation]:
            testcase_dir = evaluation_logs_tree.snippets_path / bucket_name / testcase.within_bucket_id
            testcase_runner = TestCaseRunner(
                testcase_rep=testcase,
                testcase_directory=testcase_dir,
            )
            testcase_eval = testcase_runner.evaluate(
                evaluation_logs_tree=evaluation_logs_tree,
                persist_results=persist_results,
            )
            return testcase.within_bucket_id, testcase_eval

        futures = []
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for testcase in testcases:
                futures.append(executor.submit(_run_one, testcase))

            with tqdm(total=len(futures), desc=f"{bucket_name}", leave=False) as pbar:
                for future in as_completed(futures):
                    testcase_id, testcase_eval = future.result()
                    bucket_results[testcase_id] = testcase_eval
                    pbar.update(1)
        return bucket_results

    return TestSuiteFeedback(
        pre_sound=_run_bucket("pre_sound", all_testcases.pre_sound),
        pre_complete=_run_bucket("pre_complete", all_testcases.pre_complete),
        post_sound=_run_bucket("post_sound", all_testcases.post_sound),
        post_complete=_run_bucket("post_complete", all_testcases.post_complete),
    )


def _format_structural_result_for_logs(
    structural_result: ValidationSyntaxChecksFeedback,
) -> str:
    payload = structural_result.model_dump(
        mode="json",
        exclude={"solve_rs_submitted_content"},
    )
    payload["solve_rs_submitted_content_num_chars"] = len(structural_result.solve_rs_submitted_content)
    return json.dumps(payload, indent=2, sort_keys=True)


def write_derived_files(
    evaluation_logs_tree: EvaluationLogsTree,
    derived_files: DerivedFiles,
) -> None:
    evaluation_logs_tree.derived_files_dir.mkdir(parents=True, exist_ok=True)
    files_to_write: list[tuple[Path, str]] = [
        (
            evaluation_logs_tree.derived_check_pre_spec_completeness_path,
            derived_files.check_pre_spec_completeness_content,
        ),
        (
            evaluation_logs_tree.derived_check_pre_spec_soundness_path,
            derived_files.check_pre_spec_soundness_content,
        ),
        (
            evaluation_logs_tree.derived_check_post_spec_completeness_path,
            derived_files.check_post_spec_completeness_content,
        ),
        (
            evaluation_logs_tree.derived_check_post_spec_soundness_path,
            derived_files.check_post_spec_soundness_content,
        ),
        (
            evaluation_logs_tree.derived_pre_exec_spec_complete_path,
            derived_files.pre_exec_spec_complete_content,
        ),
        (
            evaluation_logs_tree.derived_pre_exec_spec_sound_path,
            derived_files.pre_exec_spec_sound_content,
        ),
        (
            evaluation_logs_tree.derived_post_exec_spec_complete_path,
            derived_files.post_exec_spec_complete_content,
        ),
        (
            evaluation_logs_tree.derived_post_exec_spec_sound_path,
            derived_files.post_exec_spec_sound_content,
        ),
    ]
    for output_path, output_content in files_to_write:
        output_path.write_text(output_content, encoding="utf-8")


def compress_detailed_results_tree(
    *,
    evaluation_logs_tree: EvaluationLogsTree,
) -> Path:
    # Save a compressed snapshot of the run logs for easier transfer/storage.
    source_root = evaluation_logs_tree.root_directory.resolve()
    results_zip_path = evaluation_logs_tree.results_zip_path.resolve()
    results_zip_path.parent.mkdir(parents=True, exist_ok=True)

    if results_zip_path.exists():
        results_zip_path.unlink()

    with zipfile.ZipFile(
        results_zip_path,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
        allowZip64=True,
    ) as archive:
        for artifact_path in sorted(source_root.rglob("*")):
            if artifact_path.is_file():
                archive.write(
                    artifact_path,
                    arcname=artifact_path.relative_to(source_root),
                )

    return results_zip_path


class SpecgenEvaluator:
    def evaluate(self, request: EvalRequest) -> EvaluationFeedback:
        # assume (A) EvalRequest is valid!
        evaluation_logs_tree: EvaluationLogsTree | None = None
        try:
            ###### MAKE SURE WE HAVE ALL THE ARTIFACTS NEEDED FOR EVALUATION ###########
            # get paths to the artifacts directory provided as input. It has details about the testcases we want to evaluate, template file to use, submitted solve_rs
            resolved_inputs: ResolvedInputPaths = request.resolve_inputs()
            print("Inputs have been resolved!")
            ###### ================================================================ ###########
            # Make a directory where we want to do all the procssing bs!
            # ensures that all directories needed for this workflow have been created!
            evaluation_logs_tree = request.build_output_logs_tree()
            print("Evaluation logs tree has been built!")
            #TODO: Copy the submitted solve.rs to the EvaluationLogsTree.solve_rs_submitted_path
            # TODO: use the staged path for all post-staging solve.rs operations in this pipeline.
            original_solve_rs_submitted_path = resolved_inputs.solve_rs_submitted
            evaluation_logs_tree.solve_rs_submitted_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(resolved_inputs.solve_rs_submitted, evaluation_logs_tree.solve_rs_submitted_path)
            solve_rs_submitted_for_eval = evaluation_logs_tree.solve_rs_submitted_path.resolve()
            print(
                "Submitted solve.rs has been staged from "
                f"{original_solve_rs_submitted_path} to {evaluation_logs_tree.solve_rs_submitted_path}"
            )
            #### ================================================================ ###########

            manifest: Manifest = load_manifest(
                resolved_inputs.manifest_json,
                sample_or_all=request.SAMPLE_OR_ALL,
            )
            # TODO: copy the testcases `snippets` to the logs directory for the current run ID!
            copy_snippets_for_manifest(
                source_snippets_dir=resolved_inputs.snippets_dir,
                destination_snippets_dir=evaluation_logs_tree.snippets_path,
                manifest=manifest,
            )
            #########
            all_testcases: AllTestCases = load_testcases(manifest, evaluation_logs_tree.snippets_path)
            print("Testcases have been loaded and their artifacts have been read!")
            #######
            # STAGE 1: DO WE PASS ALL syntax checks: eg did the model do anything illegal editing during the submission?
            print("Stage 1: Does the submitted code have all the necessary functions?")
            structural_result: ValidationSyntaxChecksFeedback = validate_submission_structure(
                solve_rs_submitted_for_eval
            )

            print("Structural result summary:")
            print(_format_structural_result_for_logs(structural_result))
            eval_feedback = EvaluationFeedback(
                solve_rs_submitted_path=solve_rs_submitted_for_eval,
                solve_rs_post_canonical_path=None,
                syntax_check_feedback=structural_result,
                execution_feedback=None
            )
            # Now, if we pass the syntax checks, we can proceed to the next stage!
            if not structural_result.has_passed_syntax_checks:
                print("DID NOT pass syntax checks, returning evaluation feedback!")
                #TODO: dump feedback json and nl versions in the eval-results directory!
                dump_feedback(eval_feedback, evaluation_logs_tree)
                return eval_feedback

            ### We reac hhere if we DID NOT find any syntax errors ###
            #### Canconcalize phase!
            # pass resolved_inputs.solve_rs_submitted to CanonicalizePhase
            canonicalized_submission: CanonicalizedSubmission = CanonicalizePhase().run(
                validated_submission=structural_result,
                canonicalization_template_solve_rs_path=resolved_inputs.canonicalization_template_solve_rs,
            )
            # TODO: write content of canoncalized submission to EvaluationLogsTree.solve_rs_post_canonical_path
            evaluation_logs_tree.solve_rs_post_canonical_path.write_text(
                canonicalized_submission.solve_rs_post_canonical_content,
                encoding="utf-8",
            )
            eval_feedback = eval_feedback.model_copy(
                update={"solve_rs_post_canonical_path": evaluation_logs_tree.solve_rs_post_canonical_path}
            )

            ###########==============
            # get derived content
            derived_files: DerivedFiles = DeriveFilesPhase().run(canonicalized_submission=canonicalized_submission)

            # write derived content to EvaluationLogsTree.derived_files_dir to derived_pre_spec_completeness_path....
            write_derived_files(evaluation_logs_tree, derived_files)
            print("Derived files have been written!")

            # TODO: write derived files to EvaluationLogsTree..... derived files

            # Now we run the different testcases!
            execution_feedback: TestSuiteFeedback = run_test_suite(
                all_testcases=all_testcases,
                evaluation_logs_tree=evaluation_logs_tree,
                persist_results=True,
            )
            eval_feedback = eval_feedback.model_copy(
                update={"execution_feedback": execution_feedback}
            )

            #TODO: prep stdout ie written feedback and also more structured feedback!
            # write stdout to a file in the save dir!
            # and then, print saying feedback is in the save dir!
            dump_feedback(
                eval_feedback,
                evaluation_logs_tree,
            )
            return eval_feedback
        finally:
            if evaluation_logs_tree is not None:
                compressed_zip_path = compress_detailed_results_tree(
                    evaluation_logs_tree=evaluation_logs_tree
                )
                print(
                    "Compressed run logs have been written to "
                    f"{compressed_zip_path}"
                )


def run_evaluation(eval_request: EvalRequest):
    return SpecgenEvaluator().evaluate(eval_request)


if __name__ == "__main__":
    # where argument to evaluate is the EvalRequest object (this can be via a config or anything as well, for now)
    raise RuntimeError("Please construct EvalRequest with required fields and call run_evaluation(eval_request).")
