use vstd::prelude::*;
use vstd::contrib::exec_spec::*;

// ============================================================================
// Spec-generation worked example (exec_spec_unverified-compatible)
// ============================================================================
//
// In the current benchmark design:
//   - The compression layer defines spec types (In1, Out, …) inside
//     exec_spec_unverified! so we also get exec types (ExecIn1, ExecOut, …)
//     plus deep_view() for bridging exec → spec.
//   - In spec-generation evaluation, the model only edits the *spec bodies*
//     (pre_spec / post_spec) and proof helpers. Everything else is fixed.
//
// The check wrappers in this file use `exec_in1.deep_view()` / `exec_out.deep_view()`
// to match the snippets produced by the compression pipeline.
//
// IMPORTANT: Everything must be inside the verus! block for type visibility.

/*
### VERUS BEGIN
*/

verus! {

    // =========================================================================
    // 1. Types + problem-specific specs (inside exec_spec_unverified!)
    // =========================================================================
    //
    // IMPORTANT:
    //   - The model is allowed EDIT: `pre_spec`, `post_spec`, and the four
    //     `*_proof` helpers.
    //   - The model is allowed to ADD: helper spec/proof functions it needs, and
    //     call them from pre_spec/post_spec/proofs.
    //   - The model MUST NOT EDIT: the `check_*` wrappers or any of the
    //     `__PASTE_out...` placeholder comments.
    //
    // NOTE: The types are defined inside exec_spec_unverified! so the benchmark
    // also gets ExecIn1/ExecOut and exec_pre_spec/exec_post_spec for runtime
    // fallback during evaluation.

    exec_spec_unverified! {
        // list of testcases, each a list of stick lengths
        pub struct In1 {
            pub testcases: Seq<Seq<i64>>,
        }

        // for each testcase, a quadruple of chosen sticks
        pub struct Quad {
            pub a: i64,
            pub b: i64,
            pub c: i64,
            pub d: i64,
        }

        pub struct Out {
            pub quads: Seq<Quad>,
        }

        /// pre_spec: semantic validity of the logical input(s).
        ///
        /// In this *spec-generation* track, the **model MUST implement this body**
        /// so that it matches the natural-language problem statement.
        ///
        /// YOU MAY EDIT THIS FUNCTION BODY in the benchmark.
        ///
        /// For the rectangle problem, this example chooses:
        ///   - At least one testcase.
        ///   - Each testcase has at least 4 sticks.
        ///   - Every stick length lies in [1, 10_000].
        ///
        /// NOTE: exec_spec_unverified! requires quantifier variables to be concrete
        /// Rust types (i64, usize, etc.), NOT int/nat.
        pub open spec fn pre_spec(in1: In1) -> bool {
            in1.testcases.len() >= 1
            && forall |i: i64|
                0 <= i < in1.testcases.len() ==>
                    in1.testcases[i as int].len() >= 4
                    && forall |j: i64|
                        0 <= j < in1.testcases[i as int].len() ==>
                            1 <= in1.testcases[i as int][j as int] && in1.testcases[i as int][j as int] <= 10_000
        }

        /// Helper spec: checks that four sticks form exactly two equal-length pairs.
        ///
        /// YOU MAY EDIT / REFACTOR THIS HELPER OR ADD MORE HELPERS in the
        /// benchmark, as long as `pre_spec` / `post_spec` continue to capture
        /// the intended semantics.
        pub open spec fn is_two_pairs(q: Quad) -> bool {
            (q.a == q.b && q.c == q.d)
            || (q.a == q.c && q.b == q.d)
            || (q.a == q.d && q.b == q.c)
        }

        /// post_spec: correctness of an output for a given input.
        ///
        /// In this track, the **model MUST implement this body** so that it
        /// captures the intended notion of a correct solution for the problem.
        ///
        /// For the rectangle problem, this example chooses:
        ///   - `out` has one quadruple for each testcase in `in1`;
        ///   - each quadruple is two equal-length pairs (a permutation allowed).
        ///
        /// YOU MAY EDIT THIS FUNCTION BODY in the benchmark.
        pub open spec fn post_spec(in1: In1, out: Out) -> bool {
            out.quads.len() == in1.testcases.len()
            && forall |i: i64|
                0 <= i < in1.testcases.len() ==> is_two_pairs(out.quads[i as int])
        }
    }

    // =========================================================================
    // 2. Proof stubs that the model edits in the real benchmark
    // =========================================================================
    //
    // In the actual spec-gen evaluation, the model is allowed to edit ONLY:
    //   - `pre_spec`, `post_spec` (above), and
    //   - the proof helpers below:
    //       * `pre_spec_soundness_proof`
    //       * `pre_spec_completeness_proof`
    //       * `post_spec_soundness_proof`
    //       * `post_spec_completeness_proof`
    //
    // YOU MAY EDIT THESE FUNCTION BODIES in the benchmark, for instance to
    // introduce lemmas or to structure your reasoning. For this example we
    // keep them simple to emphasize structure, not deep proofs.
    //
    // NOTE: These take SPEC types (In1, Out) not exec types, since they're
    // called from proof blocks with deep_view() conversions.

    proof fn pre_spec_soundness_proof(in1: In1)
    {
        // In a full development, you would show that for soundness tests
        // (invalid inputs), `pre_spec(in1)` should be false.
        //Feel free to define and call other helpers/proofs here or leave it empty as well if you don't need it.
    }

    proof fn pre_spec_completeness_proof(in1: In1)
    {
        // In a full development, you would show that for completeness tests
        // (valid inputs), `pre_spec(in1)` should be true.
        //Feel free to define and call other helpers/proofs here or leave it empty as well if you don't need it.
    }

    proof fn post_spec_soundness_proof(in1: In1, out: Out)
    {
        // In a full development, you would show that for soundness tests
        // (valid inputs with incorrect outputs), `post_spec(in1, out)` should
        // be false.
        //Feel free to define and call other helpers/proofs here or leave it empty as well if you don't need it.
    }

    proof fn post_spec_completeness_proof(in1: In1, out: Out)
    {
        // In a full development, you would show that for completeness tests
        // (valid inputs with correct outputs), `post_spec(in1, out)` should
        // be true.
        //Feel free to define and call other helpers/proofs here or leave it empty as well if you don't need it.
    }


    // =========================================================================
    // 3. check_* wrappers (what the harness will auto-generate from snippets)
    // =========================================================================
    //
    // In the *real* spec-gen benchmark, the harness will synthesize these
    // functions from the symbolic tests and snippets. Here we mirror that
    // structure exactly and ALSO show a concrete example under each
    // `__PASTE_out...` marker.
    //
    // IMPORTANT:
    //   - The model MUST NOT EDIT these `check_*` function bodies.
    //   - The Python harness will:
    //       * paste an input/output definition at `__PASTE_out.input_defn__`
    //         / `__PASTE_out.gt_output_defn__`, and
    //       * paste an assertion snippet at `__PASTE_out.assert_*__`, then
    //         optionally negate it for soundness cases.
    //   - Only `pre_spec`, `post_spec`, and the four proof helpers are
    //     considered editable.

    fn check_pre_spec_completeness() {
        // DO NOT EDIT PASTE MARKERS OR BODY STRUCTURE IN THIS FUNCTION.
        //
        // Role (completeness):
        //   - Harness pastes a valid input definition here, e.g.:
        //       let exec_in1: ExecIn1 = ...;
        //
        // __PASTE_out.input_defn__
        //
        // Example (for illustration only; harness will generate something
        // similar during evaluation):
        let exec_in1: ExecIn1 = ExecIn1 {
            testcases: vec![
                vec![7, 2, 2, 7],
                vec![2, 8, 1, 4, 8, 2, 1, 5],
                vec![5, 5, 5, 5, 5],
            ],
        };

        proof {
            // Model-written proof that `pre_spec(in1)` should hold.
            pre_spec_completeness_proof(exec_in1.deep_view());
        }

        // Harness will paste a simple `assert(pre_spec(exec_in1.deep_view()));` snippet here.
        // For soundness tests, the same position is used but the assertion
        // is syntactically negated by the Python harness.
        //
        // __PASTE_out.assert_pre_spec__
        //
        // Example assertion (for illustration only):
        assert(pre_spec(exec_in1.deep_view()));
    }

    fn check_pre_spec_soundness() {
        // DO NOT EDIT PASTE MARKERS OR BODY STRUCTURE IN THIS FUNCTION.
        //
        // Role (soundness):
        //   - Harness pastes an *invalid* input definition here.
        //
        // __PASTE_out.input_defn__
        //
        // Example (for illustration only; harness will generate something
        // similar during evaluation):
        let exec_in1: ExecIn1 = ExecIn1 {
            testcases: vec![
                vec![0, 0, 0, 0], // 0 is outside the allowed range.
            ],
        };

        proof {
            // Model-written proof that `pre_spec(in1)` should *not* hold.
            pre_spec_soundness_proof(exec_in1.deep_view());
        }

        // Harness will paste an assertion and then syntactically negate it
        // for soundness, i.e., it will take:
        //     assert(pre_spec(exec_in1.deep_view()));
        // and transform it into:
        //     assert(!pre_spec(exec_in1.deep_view()));
        //
        // __PASTE_out.assert_pre_spec__
        //
        // Example assertion (for illustration only):
        assert(!pre_spec(exec_in1.deep_view()));
    }

    fn check_post_spec_completeness() {
        // DO NOT EDIT PASTE MARKERS OR BODY STRUCTURE IN THIS FUNCTION.
        //
        // Role (completeness):
        //   - Harness pastes symbolic input definitions, ground-truth outputs,
        //     and `assert(post_spec(exec_in1.deep_view(), exec_out.deep_view()))`.
        //
        // Placeholders filled from:
        //   - `out.input_defn` and `out.gt_output_defn` and
        //     `out.assert_post_spec_gt` produced by the compression pipeline.
        // __PASTE_out.input_defn__
        // __PASTE_out.gt_output_defn__
        //
        // Example (for illustration only):
        let exec_in1: ExecIn1 = ExecIn1 {
            testcases: vec![
                vec![7, 2, 2, 7],
                vec![2, 8, 1, 4, 8, 2, 1, 5],
                vec![5, 5, 5, 5, 5],
            ],
        };
        let exec_out: ExecOut = ExecOut {
            quads: vec![
                ExecQuad { a: 2, b: 7, c: 2, d: 7 },
                ExecQuad { a: 2, b: 8, c: 2, d: 8 },
                ExecQuad { a: 5, b: 5, c: 5, d: 5 },
            ],
        };

        proof {
            // Model-written proof that `post_spec(in1, out)` should hold.
            post_spec_completeness_proof(exec_in1.deep_view(), exec_out.deep_view());
        }

        // __PASTE_out.assert_post_spec_gt__
        //
        // Example assertion (for illustration only):
        assert(post_spec(exec_in1.deep_view(), exec_out.deep_view()));
    }

    fn check_post_spec_soundness() {
        // DO NOT EDIT PASTE MARKERS OR BODY STRUCTURE IN THIS FUNCTION.
        //
        // Role (soundness):
        //   - Harness pastes symbolic input definitions, *incorrect* outputs,
        //     and a negated `post_spec` assertion.
        //
        //   For example, starting from the snippet:
        //       assert(post_spec(exec_in1.deep_view(), exec_out.deep_view()));
        //   the harness will syntactically transform this into:
        //       assert(!post_spec(exec_in1.deep_view(), exec_out.deep_view()));
        //
        // __PASTE_out.input_defn__
        // __PASTE_out.gt_output_defn__
        //
        // Example (for illustration only):
        let exec_in1: ExecIn1 = ExecIn1 {
            testcases: vec![
                vec![7, 2, 2, 7],
            ],
        };
        let exec_out: ExecOut = ExecOut {
            quads: vec![
                ExecQuad { a: 2, b: 2, c: 2, d: 7 }, // not two equal pairs
            ],
        };

        proof {
            // Model-written proof that `post_spec(in1, out)` should *not* hold.
            post_spec_soundness_proof(exec_in1.deep_view(), exec_out.deep_view());
        }

        // __PASTE_out.assert_post_spec_gt__
        //
        // Example assertion (for illustration only):
        assert(!post_spec(exec_in1.deep_view(), exec_out.deep_view()));
    }

    // =========================================================================
    // 5. Runtime exec_spec_unverified checks (exec fallback illustration)
    // =========================================================================
    //
    // In the real benchmark, the evaluator first tries to prove the relevant
    // assertions with SMT. If that is intractable, it may fall back to
    // executing the runtime versions generated by exec_spec_unverified!:
    //   - exec_pre_spec(&ExecIn1) -> bool
    //   - exec_post_spec(&ExecIn1, &ExecOut) -> bool
    //
    // The actual evaluation harness will generate derived files that call
    // these functions and assert the expected truth value. Here we show a
    // concrete illustration.

    #[verifier::external_body]
    pub fn main_exec_pre_spec_check() {
        // __PASTE_out.input_defn__
        // (In the real benchmark, this comes from a per-testcase out.input_defn
        // snippet generated by the compression pipeline.)
        let exec_in1: ExecIn1 = ExecIn1 {
            testcases: vec![
                vec![7, 2, 2, 7],
            ],
        };
        let result = exec_pre_spec(&exec_in1);
        assert!(result);
    }

    #[verifier::external_body]
    pub fn main_exec_post_spec_check() {
        // __PASTE_out.input_defn__
        // (In the real benchmark, this comes from a per-testcase out.input_defn
        // snippet generated by the compression pipeline.)
        let exec_in1: ExecIn1 = ExecIn1 {
            testcases: vec![
                vec![7, 2, 2, 7],
            ],
        };
        // __PASTE_out.gt_output_defn__
        // (In the real benchmark, this comes from a per-testcase out.gt_output_defn
        // snippet generated by the compression pipeline.)
        let exec_out: ExecOut = ExecOut {
            quads: vec![
                ExecQuad { a: 2, b: 7, c: 2, d: 7 },
            ],
        };
        let result = exec_post_spec(&exec_in1, &exec_out);
        assert!(result);
    }

    // =========================================================================
    // 6. main() placeholder (evaluator selects an entrypoint)
    // =========================================================================
    //
    // NOTE: In the actual evaluation, the harness creates derived files and
    // replaces this main() body with a direct call to one of the check_* or
    // exec-fallback functions. For example:
    //
    //   fn main() { check_pre_spec_completeness(); }
    //   fn main() { main_exec_pre_spec_check(); }
    //   fn main() { main_exec_post_spec_check(); }
    //
    // This keeps the file's surface stable and ensures the model only edits
    // what it is allowed to edit (spec/proof bodies and helper definitions).

    #[verifier::external_body]
    fn main() {
        unimplemented!("main() body is replaced by evaluator with a direct function call");
    }
}

/*
### VERUS END
*/
