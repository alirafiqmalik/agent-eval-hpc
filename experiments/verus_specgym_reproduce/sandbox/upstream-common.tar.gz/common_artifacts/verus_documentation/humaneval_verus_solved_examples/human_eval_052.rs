/*
### ID
HumanEval/52
*/
/*
### VERUS BEGIN
*/
use vstd::prelude::*;

verus! {

fn below_threshold(l: &[i32], t: i32) -> (result: bool)
    ensures
        result == forall|i: int| 0 <= i < l.len() ==> l[i] < t,
{
    for i in 0..l.len()
        invariant
            forall|j: int| 0 <= j < i ==> l[j] < t,
    {
        if l[i] >= t {
            return false;
        }
    }
    true
}

} // verus!
fn main() {}

/*
### VERUS END
*/

/*
### PROMPT


def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """

*/

/*
### ENTRY POINT
below_threshold
*/

/*
### CANONICAL SOLUTION
    for e in l:
        if e >= t:
            return False
    return True

*/

/*
### TEST


METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10], 100)
    assert not candidate([1, 20, 4, 10], 5)
    assert candidate([1, 20, 4, 10], 21)
    assert candidate([1, 20, 4, 10], 22)
    assert candidate([1, 8, 4, 10], 11)
    assert not candidate([1, 8, 4, 10], 10)


*/
